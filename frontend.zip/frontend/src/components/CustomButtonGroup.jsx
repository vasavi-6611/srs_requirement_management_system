import React from "react";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";

export default function CustomButtonGroup({
  buttons = [],
  variant = "contained",
  color = "primary",
  orientation = "horizontal",
}) {
  return (
    <ButtonGroup
      variant={variant}
      color={color}
      orientation={orientation}
      aria-label="reusable button group"
    >
      {buttons.map((button, index) => (
        <Button
          key={index}
          onClick={button.onClick}
          startIcon={button.icon}
        >
          {button.label}
        </Button>
      ))}
    </ButtonGroup>
  );
}