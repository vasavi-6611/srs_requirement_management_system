import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomTextarea from "../components/CustomTextarea";

export default function PerformanceStressTestingForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    performanceTestingTools: "",
    peakLoadTestBenchmark: "",
    regressionTestingScope: "",
    concurrentUsersTarget: 100,
    rampUpPeriodMinutes: 5,
    testDurationMinutes: 60,
    maxResponseTimeThreshold: 2000,
    errorRateTolerancePercent: 1,
    throughputTargetRps: 500,
    cpuUtilizationLimit: 80,
    memoryUtilizationLimit: 85,
    networkBandwidthCapMbps: 1000,
    databaseConnectionTimeoutMs: 5000,
    cacheHitRatioTarget: 90,
    autoScalingTriggerVerification: false,
    soakTestDurationHours: 24,
    performanceScriptArtifactName: "",
    infrastructureMetricsPlanName: ""
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/testing/performance");
      const records = Array.isArray(response.data) ? response.data : response.data.content || [];
      setRecordsList(records);
    } catch (error) {
      console.error("Error retrieving performance registry database:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing) {
        await api.put(`/api/testing/performance/${formData.id}`, formData);
        alert("Performance Benchmarks Updated Successfully!");
      } else {
        await api.post("/api/testing/performance", formData);
        alert("Performance & Stress Configurations Saved Successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Performance Requirements Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this performance testing configuration profile?")) {
      try {
        await api.delete(`/api/testing/performance/${id}`);
        alert("Performance Template Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to delete selected database register reference entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Active / Verified" : "❌ Inactive / Bypassed") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Tooling & Volumetrics",
      "2. SLA & Threshold Benchmarks",
      "3. Endurance & Capacity Artifacts",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Performance & Stress Testing
            </h2>
            <CustomButton text="+ Establish Performance Profile" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Profile Ref</th>
                <th style={{ padding: "14px" }}>Execution Runner Tool</th>
                <th style={{ padding: "14px" }}>Target Concurrency (VUs)</th>
                <th style={{ padding: "14px" }}>Target RPS Throughput</th>
                <th style={{ padding: "14px" }}>Max Response Time SLA</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No execution profiles or stress testing suites configured. Create a blueprint entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>PST-{record.id || index + 1}</td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "700" }}>{record.performanceTestingTools || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.concurrentUsersTarget?.toLocaleString() || "0"} VUs</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px", fontWeight: "600" }}>{record.throughputTargetRps || "0"} RPS</span></td>
                    <td style={{ padding: "14px", fontWeight: "500", color: "#ef4444" }}>{record.maxResponseTimeThreshold || "0"} ms</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Drop</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container performance-testing-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Performance & Stress Configuration Definition</h2>
            <CustomButton text="Cancel Blueprint" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={fullWidthItem}>
                  <CustomRadioGroup
                    label="Primary Performance & Stress Execution Engine"
                    row={true}
                    value={formData.performanceTestingTools}
                    onChange={(e) => handleChange("performanceTestingTools", e.target.value)}
                    options={[
                      { label: "k6 Modern JavaScript Automation Runner", value: "K6_ENGINE" },
                      { label: "Apache JMeter Traditional Multi-Threaded Loader", value: "JMETER" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Target Peak Concurrent Users (VUs)"
                    fullWidth={true}
                    min={1}
                    max={100000}
                    value={formData.concurrentUsersTarget}
                    onChange={(e) => handleChange("concurrentUsersTarget", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Ramp-Up Profile Duration (Minutes)"
                    fullWidth={true}
                    min={0}
                    max={60}
                    value={formData.rampUpPeriodMinutes}
                    onChange={(e) => handleChange("rampUpPeriodMinutes", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Steady-State Load Test Duration (Minutes)"
                    fullWidth={true}
                    min={1}
                    max={1440}
                    value={formData.testDurationMinutes}
                    onChange={(e) => handleChange("testDurationMinutes", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Expected Peak Throughput (Requests / Second)"
                    fullWidth={true}
                    min={1}
                    max={50000}
                    value={formData.throughputTargetRps}
                    onChange={(e) => handleChange("throughputTargetRps", e.target.value)}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea
                    label="Regression Test Execution Boundaries under Peak Stress"
                    value={formData.regressionTestingScope}
                    onChange={(e) => handleChange("regressionTestingScope", e.target.value)}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={fullWidthItem}>
                  <CustomAutocomplete
                    label="Target Peak Load Execution Test Benchmark Profile"
                    width="100%"
                    value={formData.peakLoadTestBenchmark}
                    onChange={(newValue) => handleChange("peakLoadTestBenchmark", newValue)}
                    options={["10,000 Concurrent Requests/Sec Profile", "Continuous 48-Hour System Soak Test"]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Maximum Allowable Response Time SLA (ms)"
                    fullWidth={true}
                    min={1}
                    max={30000}
                    value={formData.maxResponseTimeThreshold}
                    onChange={(e) => handleChange("maxResponseTimeThreshold", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Max Error Rate Tolerance Threshold (%)"
                    fullWidth={true}
                    min={0}
                    max={100}
                    value={formData.errorRateTolerancePercent}
                    onChange={(e) => handleChange("errorRateTolerancePercent", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Database Query Execution Connection Timeout (ms)"
                    fullWidth={true}
                    min={100}
                    max={60000}
                    value={formData.databaseConnectionTimeoutMs}
                    onChange={(e) => handleChange("databaseConnectionTimeoutMs", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Target Memory Cache Hit Ratio Baseline (%)"
                    fullWidth={true}
                    min={0}
                    max={100}
                    value={formData.cacheHitRatioTarget}
                    onChange={(e) => handleChange("cacheHitRatioTarget", e.target.value)}
                  />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Server CPU Utilization Cap Limits (%)"
                    fullWidth={true}
                    min={1}
                    max={100}
                    value={formData.cpuUtilizationLimit}
                    onChange={(e) => handleChange("cpuUtilizationLimit", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Max Infrastructure RAM Allocation Ceiling (%)"
                    fullWidth={true}
                    min={1}
                    max={100}
                    value={formData.memoryUtilizationLimit}
                    onChange={(e) => handleChange("memoryUtilizationLimit", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Network Interface Throughput Bandwidth Cap (Mbps)"
                    fullWidth={true}
                    min={10}
                    max={100000}
                    value={formData.networkBandwidthCapMbps}
                    onChange={(e) => handleChange("networkBandwidthCapMbps", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="Soak & Extended Longevity Test Duration Profile"
                    value={formData.soakTestDurationHours}
                    onChange={(e) => handleChange("soakTestDurationHours", e.target.value)}
                    options={[
                      { label: "Standard Overnight Verification (12 Hours)", value: 12 },
                      { label: "Standard Production Leak Soak (24 Hours)", value: 24 },
                      { label: "Critical High-Availability Longevity Profile (72 Hours)", value: 72 },
                    ]}
                  />
                </div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", justifyContent: "center", margin: "10px 0" }}>
                  <CustomCheckbox
                    label="Validate Real-Time Cluster Auto-Scaling Policies and Resource Provisioning Hooks"
                    checked={formData.autoScalingTriggerVerification}
                    onChange={(e) => handleChange("autoScalingTriggerVerification", e.target.checked)}
                  />
                </div>

                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Load Testing Script Payload Bundle:</label>
                  <CustomFileUpload
                    buttonText="Upload Script File"
                    fileName={formData.performanceScriptArtifactName}
                    onChange={(e) => handleFileChange("performanceScriptArtifactName", e)}
                    accept=".js,.jmx,.json,.yml"
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Infrastructure Metrics Monitoring Blueprint:</label>
                  <CustomFileUpload
                    buttonText="Upload Monitoring Plan"
                    fileName={formData.infrastructureMetricsPlanName}
                    onChange={(e) => handleFileChange("infrastructureMetricsPlanName", e)}
                    accept=".pdf,.doc,.docx,.json"
                  />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Commit Structural Updates" : "Commit Performance Benchmarks"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Performance Target Metric Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Template Verification Anchor: PST-SPEC-ID-{selectedRecord.id || "LIVE"}</p>
            </div>
            <CustomButton text="Return to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Tooling & Volumetrics</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Execution Tool Engine Engine" value={selectedRecord.performanceTestingTools} />
            <DataField label="Target Concurrent Users (VUs)" value={selectedRecord.concurrentUsersTarget} />
            <DataField label="Ramp-Up Duration Profile (Mins)" value={selectedRecord.rampUpPeriodMinutes} />
            <DataField label="Steady-State Horizon Run (Mins)" value={selectedRecord.testDurationMinutes} />
            <DataField label="Expected Peak Throughput (RPS)" value={selectedRecord.throughputTargetRps} />
          </div>
          <div style={{ marginBottom: "30px" }}>
            <DataField label="Regression Execution Boundaries & Scope" value={selectedRecord.regressionTestingScope} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. SLA & Threshold Benchmarks</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Execution Target Benchmark Profile" value={selectedRecord.peakLoadTestBenchmark} />
            <DataField label="Max Allowable Response SLA" value={`${selectedRecord.maxResponseTimeThreshold} ms`} />
            <DataField label="Max Error Rate Tolerance" value={`${selectedRecord.errorRateTolerancePercent}%`} />
            <DataField label="Database Link Timeout Baseline" value={`${selectedRecord.databaseConnectionTimeoutMs} ms`} />
            <DataField label="Memory Cache Hit Ratio target" value={`${selectedRecord.cacheHitRatioTarget}%`} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Endurance & Capacity Artifacts</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Server CPU Allocation Cap" value={`${selectedRecord.cpuUtilizationLimit}%`} />
            <DataField label="Max Infrastructure RAM Ceiling" value={`${selectedRecord.memoryUtilizationLimit}%`} />
            <DataField label="Network Throughput Bandwidth Cap" value={`${selectedRecord.networkBandwidthCapMbps} Mbps`} />
            <DataField label="Extended Longevity Soak Test Run" value={`${selectedRecord.soakTestDurationHours} Hours`} />
            <DataField label="Validate Auto-Scaling Rules Matrix" value={selectedRecord.autoScalingTriggerVerification} />
            <DataField label="Load Automation Script Run Document" value={selectedRecord.performanceScriptArtifactName} />
            <DataField label="Infrastructure Metrics Plan Map" value={selectedRecord.infrastructureMetricsPlanName} />
          </div>
        </div>
      )}
    </div>
  );
}