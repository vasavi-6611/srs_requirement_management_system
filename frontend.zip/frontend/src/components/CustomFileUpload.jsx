import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";

export default function CustomFileUpload({
  buttonText = "Upload File",
  onChange,
  fileName = "",
  accept = "*",
  color = "primary",
  variant = "contained",
}) {
  return (
    <Stack direction="column" spacing={1} sx={{ alignItems: "flex-start", width: "100%" }}>
      <Button
        component="label"
        variant={variant}
        color={color}
        startIcon={<CloudUploadIcon />}
        sx={{ width: "100%" }}
      >
        {buttonText}
        <input
          type="file"
          hidden
          accept={accept}
          onChange={onChange}
        />
      </Button>
      
      {fileName && (
        <Typography
          variant="body2"
          sx={{
            color: "#16a34a",
            fontWeight: "500",
            paddingLeft: "4px",
            wordBreak: "break-all"
          }}
        >
          ✓ Attached: {fileName}
        </Typography>
      )}
    </Stack>
  );
}