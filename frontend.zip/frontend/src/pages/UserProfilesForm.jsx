import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomButton from "../components/CustomButton";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function UserProfilesForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [profilesList, setProfilesList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState(null);

  const emptyForm = {
    id: null,
    userClassId: "", userClassName: "", userCategory: "", userDescription: "",
    technicalExpertiseLevel: "", domainKnowledgeLevel: "", experienceLevel: "",
    educationLevel: "", computerProficiency: "", preferredLanguage: "",
    primaryResponsibilities: "", secondaryResponsibilities: "", businessGoals: "",
    expectedOutcomes: "", keyActivitiesPerformed: "", usageFrequency: "",
    usageDurationPerDay: "", expectedNumberOfUsers: "", concurrentUsersExpected: "",
    peakUsageTime: "", mobileAccessRequired: false, remoteAccessRequired: false,
    internetDependency: "", accessibilityRequirements: "", trainingRequired: false,
    helpDocumentationRequired: false, securityClearanceLevel: "", dataAccessLevel: "",
    userConstraints: "", assumptionsAboutUsers: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchUserProfiles();
  }, []);

  const fetchUserProfiles = async () => {
    try {
      const response = await api.get("/api/user-profile");
      if (response.data) {
        setProfilesList(response.data);
      }
    } catch (error) {
      console.error("Error fetching User Profiles:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (profile) => {
    setFormData(profile);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (profile) => {
    setSelectedProfile(profile);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing && formData.id) {
        await api.put(`/api/user-profile/${formData.id}`, formData);
        alert("User Profile Updated Successfully!");
      } else {
        await api.post("/api/user-profile", formData);
        alert("User Profile Saved Successfully!");
      }
      await fetchUserProfiles();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission error:", error);
      alert("Failed to save user profile.");
    }
  };

  const handleDeleteClick = async (dbId) => {
    if (!dbId) {
      alert("Error: Primary database ID missing.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this User Profile?")) {
      try {
        await api.delete(`/api/user-profile/${dbId}`);
        alert("User Profile Deleted Successfully!");
        fetchUserProfiles();
      } catch (error) {
        console.error("Delete error:", error);
        alert("Failed to delete record.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value, isBoolean = false }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      {isBoolean ? (
        <span style={{ color: value ? "#16a34a" : "#991b1b", fontWeight: "700", fontSize: "14px" }}>
          {value ? "ENABLED / TRUE" : "DISABLED / FALSE"}
        </span>
      ) : (
        <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>{value ? String(value) : "—"}</span>
      )}
    </div>
  );

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>

      {/* LIST VIEW */}
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>User Profiles</h2>
            <CustomButton text="+ Add New Profile" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>User Class ID</th>
                <th style={{ padding: "14px" }}>User Class Name</th>
                <th style={{ padding: "14px" }}>Category</th>
                <th style={{ padding: "14px" }}>Experience Level</th>
                <th style={{ padding: "14px" }}>Expertise</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {profilesList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No user profiles found. Click Add button to create one.</td>
                </tr>
              ) : (
                profilesList.map((profile) => (
                  <tr key={profile.id} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0f172a" }}>{profile.userClassId || profile.id}</td>
                    <td style={{ padding: "14px" }}>{profile.userClassName}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#e0f2fe", color: "#0369a1", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{profile.userCategory || "N/A"}</span></td>
                    <td style={{ padding: "14px" }}>{profile.experienceLevel || "—"}</td>
                    <td style={{ padding: "14px" }}>{profile.technicalExpertiseLevel || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(profile)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>👁️ View</button>
                        <button onClick={() => handleEditClick(profile)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(profile.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* FORM VIEW */}
      {viewMode === "FORM" && (
        <div className="form-container user-profile-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>
              {isEditing ? `Modify User Profile [${formData.userClassId || formData.id}]` : "User Profile Entry"}
            </h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="User Class ID" fullWidth={true} value={formData.userClassId || ""} onChange={(e) => handleChange("userClassId", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="User Class Name" fullWidth={true} value={formData.userClassName || ""} onChange={(e) => handleChange("userClassName", e.target.value)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="User Category" value={formData.userCategory || ""} onChange={(e) => handleChange("userCategory", e.target.value)}
                    options={[
                      { label: "Internal Employee", value: "INTERNAL" },
                      { label: "External Client/Partner", value: "EXTERNAL" },
                      { label: "System Administrator", value: "ADMIN" },
                      { label: "Third-Party End User", value: "THIRD_PARTY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Technical Expertise Level" value={formData.technicalExpertiseLevel || ""} onChange={(e) => handleChange("technicalExpertiseLevel", e.target.value)}
                    options={[
                      { label: "Beginner", value: "BEGINNER" },
                      { label: "Intermediate", value: "INTERMEDIATE" },
                      { label: "Expert", value: "EXPERT" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Domain Knowledge Level" value={formData.domainKnowledgeLevel || ""} onChange={(e) => handleChange("domainKnowledgeLevel", e.target.value)}
                    options={[
                      { label: "Low", value: "LOW" },
                      { label: "Medium", value: "MEDIUM" },
                      { label: "High", value: "HIGH" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Experience Level" value={formData.experienceLevel || ""} onChange={(e) => handleChange("experienceLevel", e.target.value)}
                    options={[
                      { label: "Junior", value: "JUNIOR" },
                      { label: "Mid-Level", value: "MID" },
                      { label: "Senior", value: "SENIOR" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="User Description" value={formData.userDescription || ""} onChange={(e) => handleChange("userDescription", e.target.value)} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Usage Frequency" value={formData.usageFrequency || ""} onChange={(e) => handleChange("usageFrequency", e.target.value)}
                    options={[
                      { label: "Hourly", value: "HOURLY" },
                      { label: "Daily", value: "DAILY" },
                      { label: "Weekly", value: "WEEKLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}><CustomNumberField label="Expected Number of Users" fullWidth={true} value={formData.expectedNumberOfUsers || ""} onChange={(e) => handleChange("expectedNumberOfUsers", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Primary Responsibilities" value={formData.primaryResponsibilities || ""} onChange={(e) => handleChange("primaryResponsibilities", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Business Goals" value={formData.businessGoals || ""} onChange={(e) => handleChange("businessGoals", e.target.value)} /></div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Mobile Access Required" checked={formData.mobileAccessRequired || false} onChange={(e) => handleChange("mobileAccessRequired", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Remote Access Required" checked={formData.remoteAccessRequired || false} onChange={(e) => handleChange("remoteAccessRequired", e.target.checked)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="User Constraints" value={formData.userConstraints || ""} onChange={(e) => handleChange("userConstraints", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Assumptions About Users" value={formData.assumptionsAboutUsers || ""} onChange={(e) => handleChange("assumptionsAboutUsers", e.target.value)} /></div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "30px", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: 1 }} /> : <div style={{ flex: 1 }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: 1 }} /> : <CustomButton text={isEditing ? "Update Profile" : "Save Profile"} onClick={handleSubmit} variant="contained" style={{ flex: 1, backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {/* VIEW DETAILS */}
      {viewMode === "VIEW_DETAILS" && selectedProfile && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <h3 style={{ margin: 0, color: "#0f172a" }}>User Profile Specification: {selectedProfile.userClassName}</h3>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px" }}>
            <DataField label="User Class ID" value={selectedProfile.userClassId} />
            <DataField label="User Class Name" value={selectedProfile.userClassName} />
            <DataField label="Category" value={selectedProfile.userCategory} />
            <DataField label="Technical Expertise" value={selectedProfile.technicalExpertiseLevel} />
            <DataField label="Experience Level" value={selectedProfile.experienceLevel} />
            <DataField label="Mobile Access" value={selectedProfile.mobileAccessRequired} isBoolean />
            <DataField label="Remote Access" value={selectedProfile.remoteAccessRequired} isBoolean />
          </div>
        </div>
      )}

    </div>
  );
}