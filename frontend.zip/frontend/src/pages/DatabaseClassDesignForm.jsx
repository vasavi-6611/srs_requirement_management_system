import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function DatabaseClassDesignForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    tableClassId: "",
    tableClassName: "",
    entityType: "",
    description: "",
    version: "1.0",
    attributesColumns: "",
    dataTypes: "",
    columnConstraints: "",
    defaultValues: "",
    nullableFields: "",
    primaryKeyType: "IDENTITY",
    primaryKeyColumn: "",
    compositeKeyDetails: "",
    hasForeignKey: false,
    foreignKeyDetails: "",
    referencedTable: "",
    referencedColumn: "",
    relationships: "",
    relationshipDescription: "",
    cardinalityRules: "",
    entityPurpose: "",
    businessRules: "",
    validationRules: "",
    dataIntegrityRules: "",
    methods: "",
    methodDescriptions: "",
    crudSupported: false,
    indexingStrategy: "",
    uniqueConstraints: "",
    checkConstraints: "",
    databaseSchemaName: "",
    tablespaceStorageDetails: "",
    estimatedRecordVolume: 0,
    ormFramework: "",
    entityMappingStrategy: "",
    cascadeOperations: "",
    securityRequirements: "",
    auditColumnsRequired: false,
    softDeleteSupported: false,
    designNotes: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/db-class-designs");
      setRecordsList(response.data || []);
    } catch (error) {
      console.error("Error fetching database design registry:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      console.log("Sending Database Design Payload:", formData);
      if (isEditing) {
        await api.put(`/api/db-class-designs/${formData.id}`, formData);
        alert("Database Class Design Specification Updated Successfully!");
      } else {
        await api.post("/api/db-class-designs", formData);
        alert("Database Design Information Saved Successfully!");
      }
      fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this schema entity mapping register entry?")) {
      try {
        await api.delete(`/api/db-class-designs/${id}`);
        alert("Entry Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Profile & Fields Schema",
      "2. Relations & Operations",
      "3. Optimization & Governance",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Database & Class Designs Specification
            </h2>
            <CustomButton text="+ Define New Entity Architecture" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Entity ID</th>
                <th style={{ padding: "14px" }}>Table / Class Name</th>
                <th style={{ padding: "14px" }}>Classification Type</th>
                <th style={{ padding: "14px" }}>Schema Target</th>
                <th style={{ padding: "14px" }}>Repository Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active database schemas or class entity mappings configured. Create an entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>{record.tableClassId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.tableClassName || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{record.entityType || "—"}</span></td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.databaseSchemaName || "—"}</span></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.crudSupported ? "✅ CRUD Ready" : "⚠️ Custom Access"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Blueprint</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container db-class-design-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Database & Class Specification Definition</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomTextField label="Table/Class ID" fullWidth={true} value={formData.tableClassId} onChange={(e) => handleChange("tableClassId", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Table/Class Name" fullWidth={true} value={formData.tableClassName} onChange={(e) => handleChange("tableClassName", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Entity Type Classification" value={formData.entityType} onChange={(e) => handleChange("entityType", e.target.value)}
                    options={[
                      { label: "Master Persistent Table Entity", value: "MASTER_TABLE" },
                      { label: "Transactional Ledger Storage Log", value: "TRANSACTION_TABLE" },
                      { label: "Relational Mapping Association Joint", value: "JOIN_TABLE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Version ID Signature" fullWidth={true} value={formData.version} onChange={(e) => handleChange("version", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Description Summary" value={formData.description} onChange={(e) => handleChange("description", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Attributes / Columns" value={formData.attributesColumns} onChange={(e) => handleChange("attributesColumns", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Data Types Specifications" value={formData.dataTypes} onChange={(e) => handleChange("dataTypes", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Column Constraints (NOT NULL, CHECK, UNIQUE fields)" value={formData.columnConstraints} onChange={(e) => handleChange("columnConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Default Values Matrix" value={formData.defaultValues} onChange={(e) => handleChange("defaultValues", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Nullable Fields Identifiers" value={formData.nullableFields} onChange={(e) => handleChange("nullableFields", e.target.value)} />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Primary Key Type Strategy" value={formData.primaryKeyType} onChange={(e) => handleChange("primaryKeyType", e.target.value)}
                    options={[
                      { label: "Auto-Increment Generation Sequence (IDENTITY)", value: "IDENTITY" },
                      { label: "Universally Unique Token Hex Key (UUID)", value: "UUID" },
                      { label: "Composite Keys Combined Mapping Index", value: "COMPOSITE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Primary Key Column Name" fullWidth={true} value={formData.primaryKeyColumn} onChange={(e) => handleChange("primaryKeyColumn", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Composite Key Details Mapping Specifications" value={formData.compositeKeyDetails} onChange={(e) => handleChange("compositeKeyDetails", e.target.value)} />
                </div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Does this schema entity mapping possess any Foreign Key rules?" checked={formData.hasForeignKey} onChange={(e) => handleChange("hasForeignKey", e.target.checked)} />
                </div>
                {formData.hasForeignKey && (
                  <>
                    <div style={halfWidthItem}>
                      <CustomTextField label="Foreign Key Details Constraints" fullWidth={true} value={formData.foreignKeyDetails} onChange={(e) => handleChange("foreignKeyDetails", e.target.value)} />
                    </div>
                    <div style={halfWidthItem}>
                      <CustomAutocomplete label="Referenced Table Destination Target" width="100%" value={formData.referencedTable} onChange={(newValue) => handleChange("referencedTable", newValue)}
                        options={["USER_PROFILES_MASTER", "PROJECT_INFORMATION_DATA", "SYSTEM_ARCHITECTURE_SPECS"]}
                      />
                    </div>
                    <div style={halfWidthItem}>
                      <CustomTextField label="Referenced Column Name" fullWidth={true} value={formData.referencedColumn} onChange={(e) => handleChange("referencedColumn", e.target.value)} />
                    </div>
                  </>
                )}
                <div style={fullWidthItem}>
                  <CustomRadioGroup label="Object-Relational Mapping (ORM) Connectivity Status" row={true} value={formData.relationships} onChange={(e) => handleChange("relationships", e.target.value)}
                    options={[
                      { label: "One-to-One Association", value: "ONE_TO_ONE" },
                      { label: "One-to-Many Association", value: "ONE_TO_MANY" },
                      { label: "Many-to-Many Association Matrix", value: "MANY_TO_MANY" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Relationship Description Summary" value={formData.relationshipDescription} onChange={(e) => handleChange("relationshipDescription", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Cardinality Rules Constraints" value={formData.cardinalityRules} onChange={(e) => handleChange("cardinalityRules", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Entity Purpose Specification" value={formData.entityPurpose} onChange={(e) => handleChange("entityPurpose", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Business Rules Mapping" value={formData.businessRules} onChange={(e) => handleChange("businessRules", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Validation Rules" value={formData.validationRules} onChange={(e) => handleChange("validationRules", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Data Integrity Rules (ACID Isolation Boundaries)" value={formData.dataIntegrityRules} onChange={(e) => handleChange("dataIntegrityRules", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Primary Class Logical Operational Method Mapping" width="100%" value={formData.methods} onChange={(newValue) => handleChange("methods", newValue)}
                    options={["saveProfileDetails()", "fetchRelationalMappingList()", "calculateMetricsEffortHours()"]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Standard CRUD Operations Fully Supported By Repository Layer" checked={formData.crudSupported} onChange={(e) => handleChange("crudSupported", e.target.checked)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Method Descriptions Logics" value={formData.methodDescriptions} onChange={(e) => handleChange("methodDescriptions", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Indexing Strategy" value={formData.indexingStrategy} onChange={(e) => handleChange("indexingStrategy", e.target.value)}
                    options={[
                      { label: "B-Tree Standard Key Structured Index", value: "B_TREE" },
                      { label: "Unique Bitmap Clustered Index Scheme", value: "BITMAP" },
                      { label: "Hash Mapping Fast Search Keys Index", value: "HASH" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Database Schema Name (e.g., HR_SYSTEM)" fullWidth={true} value={formData.databaseSchemaName} onChange={(e) => handleChange("databaseSchemaName", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Estimated Record Storage Volume Projection" fullWidth={true} min={0} value={formData.estimatedRecordVolume} onChange={(e) => handleChange("estimatedRecordVolume", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="ORM Framework Engine" value={formData.ormFramework} onChange={(e) => handleChange("ormFramework", e.target.value)}
                    options={[
                      { label: "Hibernate JPA Core Implementation Engine", value: "HIBERNATE" },
                      { label: "MyBatis Lightweight Manual Mapper Layer", value: "MYBATIS" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Entity Inheritance Mapping Strategy" value={formData.entityMappingStrategy} onChange={(e) => handleChange("entityMappingStrategy", e.target.value)}
                    options={[
                      { label: "Table Per Class Hierarchy Strategy", value: "TABLE_PER_CLASS" },
                      { label: "Single Table Joined Subclasses Strategy", value: "SINGLE_TABLE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Cascade Operations Rules Matrix" value={formData.cascadeOperations} onChange={(e) => handleChange("cascadeOperations", e.target.value)}
                    options={[
                      { label: "CASCADE_ALL Evictions Rules", value: "ALL" },
                      { label: "CASCADE_PERSIST Restrict Rules", value: "PERSIST" },
                      { label: "No Cascade Isolation Operations", value: "NONE" },
                    ]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Append Temporal Audit Columns Metadata (created_by, updated_at tokens)" checked={formData.auditColumnsRequired} onChange={(e) => handleChange("auditColumnsRequired", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enable Logical Soft Delete Flags Architecture" checked={formData.softDeleteSupported} onChange={(e) => handleChange("softDeleteSupported", e.target.checked)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Unique Constraints" value={formData.uniqueConstraints} onChange={(e) => handleChange("uniqueConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Check Constraints Logics" value={formData.checkConstraints} onChange={(e) => handleChange("checkConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Tablespace / Storage Details Parameters" value={formData.tablespaceStorageDetails} onChange={(e) => handleChange("tablespaceStorageDetails", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Security Requirements Controls (Row Level Cryptography)" value={formData.securityRequirements} onChange={(e) => handleChange("securityRequirements", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Design Notes" value={formData.designNotes} onChange={(e) => handleChange("designNotes", e.target.value)} />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Models Blueprint" : "Save Database Entity Specifications"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Database Architecture Blueprint Deep Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Reference: ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Profile & Fields Schema</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Table/Class ID" value={selectedRecord.tableClassId} />
            <DataField label="Table/Class Name" value={selectedRecord.tableClassName} />
            <DataField label="Entity Type Classification" value={selectedRecord.entityType} />
            <DataField label="Version ID Signature" value={selectedRecord.version} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Description Summary" value={selectedRecord.description} />
            <DataField label="Attributes / Columns" value={selectedRecord.attributesColumns} />
            <DataField label="Data Types Specifications" value={selectedRecord.dataTypes} />
            <DataField label="Column Constraints" value={selectedRecord.columnConstraints} />
            <DataField label="Default Values Matrix" value={selectedRecord.defaultValues} />
            <DataField label="Nullable Fields Identifiers" value={selectedRecord.nullableFields} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Relations & Operations Rules</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Primary Key Type" value={selectedRecord.primaryKeyType} />
            <DataField label="Primary Key Column Name" value={selectedRecord.primaryKeyColumn} />
            <DataField label="Has Foreign Key Rules" value={selectedRecord.hasForeignKey} />
            <DataField label="Referenced Table" value={selectedRecord.referencedTable} />
            <DataField label="Referenced Column" value={selectedRecord.referencedColumn} />
            <DataField label="Connectivity Association Status" value={selectedRecord.relationships} />
            <DataField label="CRUD Standard Support Enforced" value={selectedRecord.crudSupported} />
            <DataField label="Class Primary Method" value={selectedRecord.methods} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Composite Key Specifications" value={selectedRecord.compositeKeyDetails} />
            <DataField label="Foreign Key Details Constraints" value={selectedRecord.foreignKeyDetails} />
            <DataField label="Relationship Description" value={selectedRecord.relationshipDescription} />
            <DataField label="Cardinality Rules Constraints" value={selectedRecord.cardinalityRules} />
            <DataField label="Entity Purpose Specification" value={selectedRecord.entityPurpose} />
            <DataField label="Business Rules Mapping" value={selectedRecord.businessRules} />
            <DataField label="Validation Rules" value={selectedRecord.validationRules} />
            <DataField label="Data Integrity Rules (ACID)" value={selectedRecord.dataIntegrityRules} />
            <DataField label="Method Execution Logic Details" value={selectedRecord.methodDescriptions} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Optimization & Governance Infrastructure</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Indexing Strategy Structure" value={selectedRecord.indexingStrategy} />
            <DataField label="Database Schema Name Target" value={selectedRecord.databaseSchemaName} />
            <DataField label="Estimated Record Volume Projection" value={selectedRecord.estimatedRecordVolume} />
            <DataField label="ORM Framework Engine" value={selectedRecord.ormFramework} />
            <DataField label="Entity Mapping Inheritance Style" value={selectedRecord.entityMappingStrategy} />
            <DataField label="Cascade Operations Rules" value={selectedRecord.cascadeOperations} />
            <DataField label="Audit Metadata Columns Enforced" value={selectedRecord.auditColumnsRequired} />
            <DataField label="Logical Soft Delete Flags" value={selectedRecord.softDeleteSupported} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Unique Constraints Matrix" value={selectedRecord.uniqueConstraints} />
            <DataField label="Check Constraints Logics" value={selectedRecord.checkConstraints} />
            <DataField label="Tablespace / Storage Parameters" value={selectedRecord.tablespaceStorageDetails} />
            <DataField label="Security Controls (Row Cryptography)" value={selectedRecord.securityRequirements} />
            <DataField label="Architectural Design Notes" value={selectedRecord.designNotes} />
          </div>
        </div>
      )}
    </div>
  );
}