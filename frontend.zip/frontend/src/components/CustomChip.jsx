import React from "react";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";

export default function CustomChip({
  label,
  variant = "standard",
  color = "primary",
  size = "medium",
  onDelete,
  icon,
  disabled = false,
}) {
  return (
    <Stack direction="row" spacing={1}>
      <Chip
        label={label}
        variant={variant}
        color={color}
        size={size}
        onDelete={onDelete}
        icon={icon}
        disabled={disabled}
      />
    </Stack>
  );
}