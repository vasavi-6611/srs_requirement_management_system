package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.TestingRequirement;
import demo.backend.repository.TestingRequirementRepository;

@RestController
@RequestMapping("/api/testing-requirements")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class TestingRequirementController {

    @Autowired
    private TestingRequirementRepository repository;

    @GetMapping({"", "/"})
    public List<TestingRequirement> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<TestingRequirement> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<TestingRequirement> saveRecord(@RequestBody TestingRequirement record) {
        TestingRequirement saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TestingRequirement> updateRecord(@PathVariable Long id, @RequestBody TestingRequirement details) {
        return repository.findById(id).map(record -> {
            record.setRequirementId(details.getRequirementId());
            record.setRequirementName(details.getRequirementName());
            record.setModuleContext(details.getModuleContext());
            record.setPriorityTier(details.getPriorityTier());
            record.setTestingType(details.getTestingType());
            record.setRequirementStatus(details.getRequirementStatus());
            record.setRequirementDescription(details.getRequirementDescription());
            record.setTargetEnvironment(details.getTargetEnvironment());
            record.setAssignedQAEngineer(details.getAssignedQAEngineer());
            record.setExecutionOrder(details.getExecutionOrder());
            record.setAssociatedUserStoryId(details.getAssociatedUserStoryId());
            record.setRbacRolesTargeted(details.getRbacRolesTargeted());
            record.setFeatureFlagsTargeted(details.getFeatureFlagsTargeted());
            record.setHardwareDeviceConstraints(details.getHardwareDeviceConstraints());
            record.setExpectedOutcomePattern(details.getExpectedOutcomePattern());
            record.setInputDatasetMockup(details.getInputDatasetMockup());
            record.setAutomationScriptPath(details.getAutomationScriptPath());
            record.setAnalyticsTrackingKey(details.getAnalyticsTrackingKey());
            record.setIsRegressionTest(details.getIsRegressionTest());
            record.setRequiresManualVerification(details.getRequiresManualVerification());
            record.setRequiresThirdPartySignOff(details.getRequiresThirdPartySignOff());
            record.setSlaThresholdMs(details.getSlaThresholdMs());
            record.setSlaSeverityColor(details.getSlaSeverityColor());
            record.setJiraIssueKey(details.getJiraIssueKey());
            record.setTargetWindow(details.getTargetWindow());
            record.setAssumptions(details.getAssumptions());
            record.setConstraints(details.getConstraints());
            record.setDesignNotes(details.getDesignNotes());
            record.setSupportingDocumentsName(details.getSupportingDocumentsName());

            TestingRequirement updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}