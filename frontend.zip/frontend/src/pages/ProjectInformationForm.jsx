import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomDatePicker from "../components/CustomDatePicker";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function ProjectInformationForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [projectList, setProjectList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  const emptyForm = {
    id: null,
    projectId: "", projectName: "", projectAcronym: "", projectDescription: "", businessNeed: "",
    projectObjective: "", projectScope: "", projectVision: "", projectBackground: "", projectJustification: "",
    projectType: "", projectCategory: "", projectPriority: "", projectStatus: "", projectVersion: "",
    startDate: "", expectedEndDate: "", estimatedBudget: "", projectSponsor: null, projectManager: null,
    stakeholders: null, intendedUsers: null, userClasses: "", businessDomain: "", operatingEnvironment: "",
    assumptions: "", constraints: "", dependencies: "", successCriteria: "", acceptanceCriteria: "",
    risks: "", regulatoryRequirements: "", standardsFollowed: "", supportingDocumentName: "", additionalNotes: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await api.get("/api/project");
      if (response.data) {
        setProjectList(response.data);
      }
    } catch (error) {
      console.error("Error fetching projects from server:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (field, file) => {
    setFormData((prev) => ({ ...prev, [field]: file ? file.name : "" }));
  };

  const handleNext = () => {
    setStep((prev) => prev + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prev) => prev - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (project) => {
    setFormData(project);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (project) => {
    setSelectedProject(project);
    setViewMode("VIEW_DETAILS");
  };

  // Create or Update Submission
  const handleSubmit = async () => {
    try {
      if (isEditing && formData.id) {
        await api.put(`/api/project/${formData.id}`, formData);
        alert("Project Information Updated Successfully!");
      } else {
        await api.post("/api/project", formData);
        alert("Project Information Saved Successfully!");
      }
      await fetchProjects();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Error:", error);
      alert("Failed to submit project entry. Please ensure backend is running.");
    }
  };

  // Delete Action Execution
  const handleDeleteClick = async (dbId) => {
    if (!dbId) {
      alert("Error: Database primary ID missing.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this project?")) {
      try {
        await api.delete(`/api/project/${dbId}`);
        alert("Project Deleted Successfully!");
        fetchProjects();
      } catch (error) {
        console.error("Delete Error:", error);
        alert("Failed to delete record from server.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>{value ? String(value) : "—"}</span>
    </div>
  );

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      
      {/* 1. PROJECT LIST VIEW */}
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Project Information
            </h2>
            <CustomButton text="+ Add New Configuration" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Project ID</th>
                <th style={{ padding: "14px" }}>Project Name</th>
                <th style={{ padding: "14px" }}>Type</th>
                <th style={{ padding: "14px" }}>Priority</th>
                <th style={{ padding: "14px" }}>Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {projectList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>
                    No project records found in database. Click "+ Add New Configuration" to create one.
                  </td>
                </tr>
              ) : (
                projectList.map((project) => (
                  <tr key={project.id} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{project.projectId || project.id}</td>
                    <td style={{ padding: "14px" }}>{project.projectName}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#e0f2fe", color: "#0369a1", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{project.projectType || "N/A"}</span></td>
                    <td style={{ padding: "14px" }}>{project.projectPriority}</td>
                    <td style={{ padding: "14px" }}>{project.projectStatus}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button title="View Detail View" onClick={() => handleViewClick(project)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>👁️ View</button>
                        <button title="Update Entry" onClick={() => handleEditClick(project)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>✏️ Edit</button>
                        <button title="Delete Item" onClick={() => handleDeleteClick(project.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* 2. FORM VIEW */}
      {viewMode === "FORM" && (
        <div className="form-container" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <h2>{isEditing ? "Modify Project Record" : "Project Registration Entry"}</h2>
            <CustomButton text="Cancel & Back" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
            {["1. Primary Details", "2. Strategy & Roles", "3. Bounds & Criteria"].map((title, index) => {
              const stepNum = index + 1;
              const isActive = step === stepNum;
              return (
                <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45 }}>
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700" }}>
                    {step > stepNum ? "✓" : stepNum}
                  </span>
                  <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
                </div>
              );
            })}
          </div>

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="Project ID" fullWidth value={formData.projectId || ""} onChange={(e) => handleChange("projectId", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Project Name" fullWidth value={formData.projectName || ""} onChange={(e) => handleChange("projectName", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Project Acronym" fullWidth value={formData.projectAcronym || ""} onChange={(e) => handleChange("projectAcronym", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Project Version" fullWidth value={formData.projectVersion || ""} onChange={(e) => handleChange("projectVersion", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomDatePicker label="Start Date" value={formData.startDate || ""} onChange={(e) => handleChange("startDate", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomDatePicker label="Expected End Date" value={formData.expectedEndDate || ""} onChange={(e) => handleChange("expectedEndDate", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Estimated Budget" fullWidth value={formData.estimatedBudget || ""} onChange={(e) => handleChange("estimatedBudget", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomSelect label="Project Type" value={formData.projectType || ""} onChange={(e) => handleChange("projectType", e.target.value)} options={[{ label: "Web Application", value: "WEB" }, { label: "Mobile Application", value: "MOBILE" }, { label: "Desktop Application", value: "DESKTOP" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Project Category" value={formData.projectCategory || ""} onChange={(e) => handleChange("projectCategory", e.target.value)} options={[{ label: "Commercial", value: "COMMERCIAL" }, { label: "Internal R&D", value: "RESEARCH" }, { label: "Open Source", value: "OPEN_SOURCE" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Project Priority" value={formData.projectPriority || ""} onChange={(e) => handleChange("projectPriority", e.target.value)} options={[{ label: "High", value: "HIGH" }, { label: "Medium", value: "MEDIUM" }, { label: "Low", value: "LOW" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Project Status" value={formData.projectStatus || ""} onChange={(e) => handleChange("projectStatus", e.target.value)} options={[{ label: "Initiation", value: "INITIATION" }, { label: "In Progress", value: "IN_PROGRESS" }, { label: "Completed", value: "COMPLETED" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="User Classes" value={formData.userClasses || ""} onChange={(e) => handleChange("userClasses", e.target.value)} options={[{ label: "Standard User", value: "STANDARD" }, { label: "Super Admin", value: "SUPER_ADMIN" }, { label: "Guest Viewer", value: "GUEST" }]} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}><CustomSelect label="Business Domain" value={formData.businessDomain || ""} onChange={(e) => handleChange("businessDomain", e.target.value)} options={[{ label: "Finance & Banking", value: "FINANCE" }, { label: "Telecommunications", value: "TELECOM" }, { label: "Healthcare Systems", value: "HEALTHCARE" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Operating Environment" value={formData.operatingEnvironment || ""} onChange={(e) => handleChange("operatingEnvironment", e.target.value)} options={[{ label: "Cloud Hosted (AWS/Azure)", value: "CLOUD" }, { label: "On-Premises Bare Metal", value: "ON_PREM" }, { label: "Hybrid Network Architecture", value: "HYBRID" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Standards Followed" value={formData.standardsFollowed || ""} onChange={(e) => handleChange("standardsFollowed", e.target.value)} options={[{ label: "ISO/IEC 27001 Security Standard", value: "ISO_27001" }, { label: "IEEE 829 Documentation Guideline", value: "IEEE_829" }, { label: "W3C Core Web Standards Compliance", value: "W3C_COMPLIANT" }]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Project Sponsor" width="100%" value={formData.projectSponsor || null} onChange={(v) => handleChange("projectSponsor", v)} options={["Sponsor Entity A", "Sponsor Entity B", "Executive Stakeholder Group"]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Project Manager" width="100%" value={formData.projectManager || null} onChange={(v) => handleChange("projectManager", v)} options={["Manager John", "Manager Smith", "Lead Architect Node"]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Stakeholders" width="100%" value={formData.stakeholders || null} onChange={(v) => handleChange("stakeholders", v)} options={["Client Team", "Project Devs", "End Users Group"]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Intended Users" width="100%" value={formData.intendedUsers || null} onChange={(v) => handleChange("intendedUsers", v)} options={["General Public", "Enterprise Administrators", "Data Specialists"]} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555", fontWeight: "600" }}>Supporting Documents Reference:</label>
                  <CustomFileUpload buttonText="Upload Attachment Spec File" fileName={formData.supportingDocumentName || ""} onChange={(e) => handleFileChange("supportingDocumentName", e)} accept=".pdf,.doc,.docx,.xlsx" />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={fullWidthItem}><CustomTextarea label="Project Description" value={formData.projectDescription || ""} onChange={(e) => handleChange("projectDescription", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Business Need" value={formData.businessNeed || ""} onChange={(e) => handleChange("businessNeed", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Project Objective" value={formData.projectObjective || ""} onChange={(e) => handleChange("projectObjective", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Project Scope" value={formData.projectScope || ""} onChange={(e) => handleChange("projectScope", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Project Vision" value={formData.projectVision || ""} onChange={(e) => handleChange("projectVision", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Project Background" value={formData.projectBackground || ""} onChange={(e) => handleChange("projectBackground", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Project Justification" value={formData.projectJustification || ""} onChange={(e) => handleChange("projectJustification", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Assumptions" value={formData.assumptions || ""} onChange={(e) => handleChange("assumptions", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Constraints" value={formData.constraints || ""} onChange={(e) => handleChange("constraints", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Dependencies" value={formData.dependencies || ""} onChange={(e) => handleChange("dependencies", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Success Criteria" value={formData.successCriteria || ""} onChange={(e) => handleChange("successCriteria", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Acceptance Criteria" value={formData.acceptanceCriteria || ""} onChange={(e) => handleChange("acceptanceCriteria", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Risks" value={formData.risks || ""} onChange={(e) => handleChange("risks", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Regulatory Requirements" value={formData.regulatoryRequirements || ""} onChange={(e) => handleChange("regulatoryRequirements", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Additional Notes" value={formData.additionalNotes || ""} onChange={(e) => handleChange("additionalNotes", e.target.value)} /></div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "30px", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: 1 }} /> : <div style={{ flex: 1 }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: 1 }} /> : <CustomButton text={isEditing ? "Update Data" : "Save Project Details"} onClick={handleSubmit} variant="contained" style={{ flex: 1, backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {/* 3. DETAILS READ-ONLY VIEW */}
      {viewMode === "VIEW_DETAILS" && selectedProject && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Full Specification Details</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Project: {selectedProject.projectName || "—"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Primary Information Fields</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="Project ID" value={selectedProject.projectId} />
            <DataField label="Project Name" value={selectedProject.projectName} />
            <DataField label="Project Acronym" value={selectedProject.projectAcronym} />
            <DataField label="Project Version" value={selectedProject.projectVersion} />
            <DataField label="Start Date" value={selectedProject.startDate} />
            <DataField label="Expected End Date" value={selectedProject.expectedEndDate} />
            <DataField label="Estimated Budget" value={selectedProject.estimatedBudget} />
            <DataField label="Project Type" value={selectedProject.projectType} />
            <DataField label="Project Category" value={selectedProject.projectCategory} />
            <DataField label="Project Priority" value={selectedProject.projectPriority} />
            <DataField label="Project Status" value={selectedProject.projectStatus} />
            <DataField label="User Classes" value={selectedProject.userClasses} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Strategy & Resource Roles</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="Business Domain" value={selectedProject.businessDomain} />
            <DataField label="Operating Environment" value={selectedProject.operatingEnvironment} />
            <DataField label="Standards Followed" value={selectedProject.standardsFollowed} />
            <DataField label="Project Sponsor" value={selectedProject.projectSponsor} />
            <DataField label="Project Manager" value={selectedProject.projectManager} />
            <DataField label="Stakeholders" value={selectedProject.stakeholders} />
            <DataField label="Intended Users" value={selectedProject.intendedUsers} />
            <DataField label="Supporting Document" value={selectedProject.supportingDocumentName} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Bounds, Criteria & Descriptions</h4>
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Project Description" value={selectedProject.projectDescription} />
              <DataField label="Business Need" value={selectedProject.businessNeed} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Project Objective" value={selectedProject.projectObjective} />
              <DataField label="Project Scope" value={selectedProject.projectScope} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Project Vision" value={selectedProject.projectVision} />
              <DataField label="Project Background" value={selectedProject.projectBackground} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Project Justification" value={selectedProject.projectJustification} />
              <DataField label="Assumptions" value={selectedProject.assumptions} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Constraints" value={selectedProject.constraints} />
              <DataField label="Dependencies" value={selectedProject.dependencies} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Success Criteria" value={selectedProject.successCriteria} />
              <DataField label="Acceptance Criteria" value={selectedProject.acceptanceCriteria} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <DataField label="Risks" value={selectedProject.risks} />
              <DataField label="Regulatory Requirements" value={selectedProject.regulatoryRequirements} />
            </div>
            <DataField label="Additional Notes" value={selectedProject.additionalNotes} />
          </div>
        </div>
      )}
    </div>
  );
}