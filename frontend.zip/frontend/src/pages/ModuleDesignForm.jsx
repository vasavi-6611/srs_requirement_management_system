import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function ModuleDesignForm() {
  const [viewMode, setViewMode] = useState("LIST"); // Supported Matrix Modes: "LIST", "FORM", "VIEW_DETAILS"
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    moduleId: "",
    moduleName: "",
    moduleVersion: "1.0",
    moduleCategory: "",
    moduleType: "",
    moduleStatus: "",
    moduleDescription: "",
    moduleObjective: "",
    primaryResponsibility: "",
    secondaryResponsibility: "",
    businessRules: "",
    processingLogic: "",
    relatedRequirements: "",
    requirementPriority: "",
    requirementSource: "",
    relatedUserClasses: "",
    relatedStakeholders: "",
    inputs: "",
    outputs: "",
    inputValidationRules: "",
    outputFormat: "",
    internalDependencies: "",
    externalDependencies: "",
    databaseDependencies: "",
    apiDependencies: "",
    thirdPartyDependencies: "",
    communicationProtocol: "",
    interfaceDescription: "",
    errorHandlingStrategy: "",
    authenticationRequired: false,
    authorizationRequired: false,
    sensitiveDataHandling: "",
    auditLoggingRequired: false,
    expectedResponseTime: 0,
    expectedThroughput: 0,
    scalabilityConsiderations: "",
    assumptions: "",
    constraints: "",
    designNotes: "",
    supportingDocumentsName: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/modules");
      setRecordsList(response.data || []);
    } catch (error) {
      console.error("Error fetching module design registry:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, event) => {
    const file = event.target.files?.[0];
    if (file) {
      handleChange(field, file.name);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      console.log("Sending Module Design Payload:", formData);
      if (isEditing) {
        await api.put(`/api/modules/${formData.id}`, formData);
        alert("Module Components Design Specification Updated Successfully!");
      } else {
        await api.post("/api/modules", formData);
        alert("Module Design Information Saved Successfully!");
      }
      fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this module components design data register entry?")) {
      try {
        await api.delete(`/api/modules/${id}`);
        alert("Entry Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Profile & Logic Architecture",
      "2. Contracts & Integration Graph",
      "3. Security & SLA Operations",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Module Designs
            </h2>
            <CustomButton text="+ Define New Module Setup" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Module ID</th>
                <th style={{ padding: "14px" }}>Module Name</th>
                <th style={{ padding: "14px" }}>Category Architecture</th>
                <th style={{ padding: "14px" }}>Component Type</th>
                <th style={{ padding: "14px" }}>Design Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active module components design specifications configured. Create an entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>{record.moduleId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.moduleName || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{record.moduleCategory || "—"}</span></td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.moduleType || "—"}</span></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.moduleStatus || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Blueprint</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container module-design-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Module Designs Specification Definition</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomTextField label="Module ID" fullWidth={true} value={formData.moduleId} onChange={(e) => handleChange("moduleId", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Module Name" width="100%" value={formData.moduleName} onChange={(newValue) => handleChange("moduleName", newValue)}
                    options={[
                      "JWT Authentication Controller",
                      "Telecom Predictive Analytics Engine",
                      "Oracle Persistence Data Sync Service",
                      "Lifecycle Validation Reporting Manager",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Module Version" fullWidth={true} value={formData.moduleVersion} onChange={(e) => handleChange("moduleVersion", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Module Category" value={formData.moduleCategory} onChange={(e) => handleChange("moduleCategory", e.target.value)}
                    options={[
                      { label: "Core System Infrastructure", value: "INFRASTRUCTURE" },
                      { label: "Security & Cryptography Access", value: "SECURITY" },
                      { label: "Business Processing Engine", value: "BUSINESS_LOGIC" },
                      { label: "Data Pipeline & Reporting analytics", value: "REPORTING" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Module Type" value={formData.moduleType} onChange={(e) => handleChange("moduleType", e.target.value)}
                    options={[
                      { label: "Controller Layer Endpoint Handler", value: "CONTROLLER" },
                      { label: "Service Layer Processing Component", value: "SERVICE" },
                      { label: "Data Access Object Repository Layer (DAO)", value: "REPOSITORY" },
                      { label: "External Third-Party Connector Middleware", value: "MIDDLEWARE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Module Status" value={formData.moduleStatus} onChange={(e) => handleChange("moduleStatus", e.target.value)}
                    options={[
                      { label: "Draft Component Design Specification", value: "DRAFT" },
                      { label: "Ready for Component Coding Sprint", value: "APPROVED" },
                      { label: "Under Active Unit Review Verification", value: "IN_REVIEW" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Module Description" value={formData.moduleDescription} onChange={(e) => handleChange("moduleDescription", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Module Objective" value={formData.moduleObjective} onChange={(e) => handleChange("moduleObjective", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Primary Responsibility" value={formData.primaryResponsibility} onChange={(e) => handleChange("primaryResponsibility", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Secondary Responsibility" value={formData.secondaryResponsibility} onChange={(e) => handleChange("secondaryResponsibility", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Business Rules" value={formData.businessRules} onChange={(e) => handleChange("businessRules", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Processing Logic" value={formData.processingLogic} onChange={(e) => handleChange("processingLogic", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Requirement Priority" value={formData.requirementPriority} onChange={(e) => handleChange("requirementPriority", e.target.value)}
                    options={[
                      { label: "High / Essential System Feature", value: "HIGH" },
                      { label: "Medium / Operational Extension", value: "MEDIUM" },
                      { label: "Low / Future Roadmap Enhancement", value: "LOW" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Requirement Source" width="100%" value={formData.requirementSource} onChange={(newValue) => handleChange("requirementSource", newValue)}
                    options={[
                      "IEEE Standard Baseline Requirements Document",
                      "Stakeholder Workspace Interview System",
                      "Legacy Infrastructure Reverse Engineering",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Related User Classes" width="100%" value={formData.relatedUserClasses} onChange={(newValue) => handleChange("relatedUserClasses", newValue)}
                    options={[
                      "System Administrator Tier",
                      "Business Operations Analyst Group",
                      "External Compliance Auditor",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Related Stakeholders" width="100%" value={formData.relatedStakeholders} onChange={(newValue) => handleChange("relatedStakeholders", newValue)}
                    options={[
                      "Product Engineering Executive Sponsor",
                      "Lead Solution Architect Core Node",
                      "Operations Security Desk",
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Related Requirements" value={formData.relatedRequirements} onChange={(e) => handleChange("relatedRequirements", e.target.value)} />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Inputs" value={formData.inputs} onChange={(e) => handleChange("inputs", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Outputs" value={formData.outputs} onChange={(e) => handleChange("outputs", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Input Validation Rules" value={formData.inputValidationRules} onChange={(e) => handleChange("inputValidationRules", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Output Format" value={formData.outputFormat} onChange={(e) => handleChange("outputFormat", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Internal Dependencies" value={formData.internalDependencies} onChange={(e) => handleChange("internalDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="External Dependencies" value={formData.externalDependencies} onChange={(e) => handleChange("externalDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Database Dependencies" value={formData.databaseDependencies} onChange={(e) => handleChange("databaseDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="API Dependencies" value={formData.apiDependencies} onChange={(e) => handleChange("apiDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Third-Party Dependencies" value={formData.thirdPartyDependencies} onChange={(e) => handleChange("thirdPartyDependencies", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Communication Protocol" value={formData.communicationProtocol} onChange={(e) => handleChange("communicationProtocol", e.target.value)}
                    options={[
                      { label: "REST Endpoints (JSON Data Payload over HTTPS)", value: "REST_HTTP" },
                      { label: "gRPC Streaming Pipelines (ProtoBuf Wire Format)", value: "GRPC" },
                      { label: "Asynchronous Message Queue Event Streams", value: "MQ_EVENT" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Interface Description" value={formData.interfaceDescription} onChange={(e) => handleChange("interfaceDescription", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Error Handling Strategy" value={formData.errorHandlingStrategy} onChange={(e) => handleChange("errorHandlingStrategy", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Mandatory Authentication Required" checked={formData.authenticationRequired} onChange={(e) => handleChange("authenticationRequired", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Mandatory Authorization Required (RBAC Checking)" checked={formData.authorizationRequired} onChange={(e) => handleChange("authorizationRequired", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Immutable Security Audit Logging Required" checked={formData.auditLoggingRequired} onChange={(e) => handleChange("auditLoggingRequired", e.target.checked)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Sensitive Data Handling" value={formData.sensitiveDataHandling} onChange={(e) => handleChange("sensitiveDataHandling", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Expected Response Time (ms Target)" fullWidth={true} min={1} value={formData.expectedResponseTime} onChange={(e) => handleChange("expectedResponseTime", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Expected Throughput (Requests/sec SLA)" fullWidth={true} min={1} value={formData.expectedThroughput} onChange={(e) => handleChange("expectedThroughput", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Scalability Considerations" value={formData.scalabilityConsiderations} onChange={(e) => handleChange("scalabilityConsiderations", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Assumptions" value={formData.assumptions} onChange={(e) => handleChange("assumptions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Constraints" value={formData.constraints} onChange={(e) => handleChange("constraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Design Notes" value={formData.designNotes} onChange={(e) => handleChange("designNotes", e.target.value)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Supporting Architecture Blueprints Attachment:</label>
                  <CustomFileUpload buttonText="Upload Supporting Document" fileName={formData.supportingDocumentsName} onChange={(e) => handleFileChange("supportingDocumentsName", e)} accept=".pdf,.doc,.docx,.xlsx,.png,.jpg" />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Components Specification Model" : "Save Module Components Design Data"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Module Architecture Deep Blueprint Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Database Identity Entry Reference: ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Profile & Logic Architecture</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Module ID" value={selectedRecord.moduleId} />
            <DataField label="Module Name" value={selectedRecord.moduleName} />
            <DataField label="Module Version" value={selectedRecord.moduleVersion} />
            <DataField label="Module Category" value={selectedRecord.moduleCategory} />
            <DataField label="Module Type" value={selectedRecord.moduleType} />
            <DataField label="Module Status" value={selectedRecord.moduleStatus} />
            <DataField label="Requirement Priority" value={selectedRecord.requirementPriority} />
            <DataField label="Requirement Source" value={selectedRecord.requirementSource} />
            <DataField label="Related User Classes" value={selectedRecord.relatedUserClasses} />
            <DataField label="Related Stakeholders" value={selectedRecord.relatedStakeholders} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Module Description" value={selectedRecord.moduleDescription} />
            <DataField label="Module Objective" value={selectedRecord.moduleObjective} />
            <DataField label="Primary Responsibility" value={selectedRecord.primaryResponsibility} />
            <DataField label="Secondary Responsibility" value={selectedRecord.secondaryResponsibility} />
            <DataField label="Business Rules" value={selectedRecord.businessRules} />
            <DataField label="Processing Logic" value={selectedRecord.processingLogic} />
            <DataField label="Related Requirements Scope" value={selectedRecord.relatedRequirements} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Contracts & Integration Graph</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Communication Protocol" value={selectedRecord.communicationProtocol} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Inputs Description" value={selectedRecord.inputs} />
            <DataField label="Outputs Description" value={selectedRecord.outputs} />
            <DataField label="Input Validation Rules" value={selectedRecord.inputValidationRules} />
            <DataField label="Output Format Mapping" value={selectedRecord.outputFormat} />
            <DataField label="Internal Dependencies Graph" value={selectedRecord.internalDependencies} />
            <DataField label="External Dependencies Topology" value={selectedRecord.externalDependencies} />
            <DataField label="Database Dependences Schema" value={selectedRecord.databaseDependencies} />
            <DataField label="API Integration Connectors" value={selectedRecord.apiDependencies} />
            <DataField label="Third Party Subsystems" value={selectedRecord.thirdPartyDependencies} />
            <DataField label="Interface Description Details" value={selectedRecord.interfaceDescription} />
            <DataField label="Error Handling Strategy Framework" value={selectedRecord.errorHandlingStrategy} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Security & SLA Operations</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Authentication Required" value={selectedRecord.authenticationRequired} />
            <DataField label="Authorization Enforced (RBAC)" value={selectedRecord.authorizationRequired} />
            <DataField label="Immutable Audit Logging" value={selectedRecord.auditLoggingRequired} />
            <DataField label="Expected Response Time (ms)" value={selectedRecord.expectedResponseTime} />
            <DataField label="Expected Throughput (RPS)" value={selectedRecord.expectedThroughput} />
            <DataField label="Supporting Document Asset" value={selectedRecord.supportingDocumentsName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Sensitive Data Handling Protocol" value={selectedRecord.sensitiveDataHandling} />
            <DataField label="Scalability Considerations Matrix" value={selectedRecord.scalabilityConsiderations} />
            <DataField label="Core Design Assumptions" value={selectedRecord.assumptions} />
            <DataField label="System Hard Constraints" value={selectedRecord.constraints} />
            <DataField label="Architectural Design Notes" value={selectedRecord.designNotes} />
          </div>
        </div>
      )}
    </div>
  );
}