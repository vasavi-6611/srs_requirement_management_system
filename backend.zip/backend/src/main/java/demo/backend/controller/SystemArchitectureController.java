package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.SystemArchitecture;
import demo.backend.repository.SystemArchitectureRepository;

@RestController
@RequestMapping("/api/architecture")
@CrossOrigin(origins = {"*"})
public class SystemArchitectureController {

    @Autowired
    private SystemArchitectureRepository repository;

    @GetMapping({"", "/"})
    public List<SystemArchitecture> getAllArchitectures() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SystemArchitecture> getArchitectureById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<SystemArchitecture> saveArchitecture(@RequestBody SystemArchitecture arch) {
        SystemArchitecture saved = repository.save(arch);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SystemArchitecture> updateArchitecture(@PathVariable Long id, @RequestBody SystemArchitecture details) {
        return repository.findById(id).map(arch -> {
            arch.setArchitectureId(details.getArchitectureId());
            arch.setArchitectureName(details.getArchitectureName());
            arch.setArchitectureVersion(details.getArchitectureVersion());
            arch.setArchitectureType(details.getArchitectureType());
            arch.setArchitectureDescription(details.getArchitectureDescription());
            arch.setArchitectureObjectives(details.getArchitectureObjectives());
            arch.setDesignPrinciples(details.getDesignPrinciples());
            arch.setBusinessGoalsSupported(details.getBusinessGoalsSupported());
            arch.setQualityAttributes(details.getQualityAttributes());
            arch.setDesignConstraints(details.getDesignConstraints());
            arch.setCoreComponents(details.getCoreComponents());
            arch.setComponentResponsibilities(details.getComponentResponsibilities());
            arch.setComponentInteractions(details.getComponentInteractions());
            arch.setComponentDependencies(details.getComponentDependencies());
            arch.setExternalComponents(details.getExternalComponents());
            arch.setPresentationLayerDescription(details.getPresentationLayerDescription());
            arch.setBusinessLayerDescription(details.getBusinessLayerDescription());
            arch.setDataAccessLayerDescription(details.getDataAccessLayerDescription());
            arch.setIntegrationLayerDescription(details.getIntegrationLayerDescription());
            arch.setCommunicationProtocols(details.getCommunicationProtocols());
            arch.setCommunicationInterfaces(details.getCommunicationInterfaces());
            
            // Updated to use the correct Object Wrapper getter methods
            arch.setApiGatewayRequired(details.getApiGatewayRequired());
            arch.setMessageQueueRequired(details.getMessageQueueRequired());
            arch.setServiceDiscoveryRequired(details.getServiceDiscoveryRequired());
            arch.setLoadBalancerRequired(details.getLoadBalancerRequired());
            arch.setIsHttpsSecure(details.getIsHttpsSecure());

            arch.setDeploymentModel(details.getDeploymentModel());
            arch.setHostingEnvironment(details.getHostingEnvironment());
            arch.setCloudProvider(details.getCloudProvider());
            arch.setContainerizationStrategy(details.getContainerizationStrategy());
            arch.setAuthenticationArchitecture(details.getAuthenticationArchitecture());
            arch.setAuthorizationArchitecture(details.getAuthorizationArchitecture());
            arch.setEncryptionStrategy(details.getEncryptionStrategy());
            arch.setAuditLoggingStrategy(details.getAuditLoggingStrategy());
            arch.setScalabilityStrategy(details.getScalabilityStrategy());
            arch.setHighAvailabilityStrategy(details.getHighAvailabilityStrategy());
            arch.setFaultToleranceStrategy(details.getFaultToleranceStrategy());
            arch.setPerformanceTargets(details.getPerformanceTargets());
            arch.setArchitectureDiagramName(details.getArchitectureDiagramName());
            arch.setAdditionalNotes(details.getAdditionalNotes());

            SystemArchitecture updated = repository.save(arch);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArchitecture(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}