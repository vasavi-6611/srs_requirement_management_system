import React from "react";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";

export default function CustomSwitch({
  label,
  checked,
  onChange,
  disabled = false,
  color = "primary",
}) {
  return (
    <FormControlLabel
      control={
        <Switch
          checked={checked}
          onChange={onChange}
          disabled={disabled}
          color={color}
        />
      }
      label={label}
    />
  );
}