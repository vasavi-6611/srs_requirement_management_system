package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.NonFunctionalRequirement;

@Repository
public interface NonFunctionalRequirementRepository 
        extends JpaRepository<NonFunctionalRequirement, Long> {
}