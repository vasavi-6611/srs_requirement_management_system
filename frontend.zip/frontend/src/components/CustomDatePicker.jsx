import React from "react";
import TextField from "@mui/material/TextField";

export default function CustomDatePicker({
  label,
  value,
  onChange,
  fullWidth = true,
  disabled = false,
  error = false,
  helperText = "",
}) {
  return (
    <TextField
      type="date"
      label={label}
      value={value}
      onChange={onChange}
      fullWidth={fullWidth}
      disabled={disabled}
      error={error}
      helperText={helperText}
      slotProps={{
        inputLabel: {
          shrink: true, // Fixes label overlapping issue natively
        },
      }}
    />
  );
}