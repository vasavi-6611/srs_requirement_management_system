package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "module_designs")
public class ModuleDesign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "module_id")
    private String moduleId = "";

    @Column(name = "module_name")
    private String moduleName = "";

    @Column(name = "module_version")
    private String moduleVersion = "1.0";

    @Column(name = "module_category")
    private String moduleCategory = "";

    @Column(name = "module_type")
    private String moduleType = "";

    @Column(name = "module_status")
    private String moduleStatus = "";

    @Column(name = "module_description", length = 2000)
    private String moduleDescription = "";

    @Column(name = "module_objective", length = 2000)
    private String moduleObjective = "";

    @Column(name = "primary_responsibility", length = 2000)
    private String primaryResponsibility = "";

    @Column(name = "secondary_responsibility", length = 2000)
    private String secondaryResponsibility = "";

    @Column(name = "business_rules", length = 2000)
    private String businessRules = "";

    @Column(name = "processing_logic", length = 2500)
    private String processingLogic = "";

    @Column(name = "related_requirements", length = 2000)
    private String relatedRequirements = "";

    @Column(name = "requirement_priority")
    private String requirementPriority = "";

    @Column(name = "requirement_source")
    private String requirementSource = "";

    @Column(name = "related_user_classes")
    private String relatedUserClasses = "";

    @Column(name = "related_stakeholders")
    private String relatedStakeholders = "";

    @Column(name = "inputs", length = 2000)
    private String inputs = "";

    @Column(name = "outputs", length = 2000)
    private String outputs = "";

    @Column(name = "input_validation_rules", length = 2000)
    private String inputValidationRules = "";

    @Column(name = "output_format", length = 2000)
    private String outputFormat = "";

    @Column(name = "internal_dependencies", length = 2000)
    private String internalDependencies = "";

    @Column(name = "external_dependencies", length = 2000)
    private String externalDependencies = "";

    @Column(name = "database_dependencies", length = 2000)
    private String databaseDependencies = "";

    @Column(name = "api_dependencies", length = 2000)
    private String apiDependencies = "";

    @Column(name = "third_party_dependencies", length = 2000)
    private String thirdPartyDependencies = "";

    @Column(name = "communication_protocol")
    private String communicationProtocol = "";

    @Column(name = "interface_description", length = 2000)
    private String interfaceDescription = "";

    @Column(name = "error_handling_strategy", length = 2000)
    private String errorHandlingStrategy = "";

    @Column(name = "authentication_required")
    private Boolean authenticationRequired = false;

    @Column(name = "authorization_required")
    private Boolean authorizationRequired = false;

    @Column(name = "audit_logging_required")
    private Boolean auditLoggingRequired = false;

    @Column(name = "sensitive_data_handling", length = 2000)
    private String sensitiveDataHandling = "";

    @Column(name = "expected_response_time")
    private Integer expectedResponseTime = 0;

    @Column(name = "expected_throughput")
    private Integer expectedThroughput = 0;

    @Column(name = "scalability_considerations", length = 2000)
    private String scalabilityConsiderations = "";

    @Column(name = "assumptions", length = 2000)
    private String assumptions = "";

    @Column(name = "constraints", length = 2000)
    private String constraints = "";

    @Column(name = "design_notes", length = 2500)
    private String designNotes = "";

    @Column(name = "supporting_documents_name")
    private String supportingDocumentsName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getModuleId() { return moduleId; }
    public void setModuleId(String moduleId) { this.moduleId = moduleId; }

    public String getModuleName() { return moduleName; }
    public void setModuleName(String moduleName) { this.moduleName = moduleName; }

    public String getModuleVersion() { return moduleVersion; }
    public void setModuleVersion(String moduleVersion) { this.moduleVersion = moduleVersion; }

    public String getModuleCategory() { return moduleCategory; }
    public void setModuleCategory(String moduleCategory) { this.moduleCategory = moduleCategory; }

    public String getModuleType() { return moduleType; }
    public void setModuleType(String moduleType) { this.moduleType = moduleType; }

    public String getModuleStatus() { return moduleStatus; }
    public void setModuleStatus(String moduleStatus) { this.moduleStatus = moduleStatus; }

    public String getModuleDescription() { return moduleDescription; }
    public void setModuleDescription(String moduleDescription) { this.moduleDescription = moduleDescription; }

    public String getModuleObjective() { return moduleObjective; }
    public void setModuleObjective(String moduleObjective) { this.moduleObjective = moduleObjective; }

    public String getPrimaryResponsibility() { return primaryResponsibility; }
    public void setPrimaryResponsibility(String primaryResponsibility) { this.primaryResponsibility = primaryResponsibility; }

    public String getSecondaryResponsibility() { return secondaryResponsibility; }
    public void setSecondaryResponsibility(String secondaryResponsibility) { this.secondaryResponsibility = secondaryResponsibility; }

    public String getBusinessRules() { return businessRules; }
    public void setBusinessRules(String businessRules) { this.businessRules = businessRules; }

    public String getProcessingLogic() { return processingLogic; }
    public void setProcessingLogic(String processingLogic) { this.processingLogic = processingLogic; }

    public String getRelatedRequirements() { return relatedRequirements; }
    public void setRelatedRequirements(String relatedRequirements) { this.relatedRequirements = relatedRequirements; }

    public String getRequirementPriority() { return requirementPriority; }
    public void setRequirementPriority(String requirementPriority) { this.requirementPriority = requirementPriority; }

    public String getRequirementSource() { return requirementSource; }
    public void setRequirementSource(String requirementSource) { this.requirementSource = requirementSource; }

    public String getRelatedUserClasses() { return relatedUserClasses; }
    public void setRelatedUserClasses(String relatedUserClasses) { this.relatedUserClasses = relatedUserClasses; }

    public String getRelatedStakeholders() { return relatedStakeholders; }
    public void setRelatedStakeholders(String relatedStakeholders) { this.relatedStakeholders = relatedStakeholders; }

    public String getInputs() { return inputs; }
    public void setInputs(String inputs) { this.inputs = inputs; }

    public String getOutputs() { return outputs; }
    public void setOutputs(String outputs) { this.outputs = outputs; }

    public String getInputValidationRules() { return inputValidationRules; }
    public void setInputValidationRules(String inputValidationRules) { this.inputValidationRules = inputValidationRules; }

    public String getOutputFormat() { return outputFormat; }
    public void setOutputFormat(String outputFormat) { this.outputFormat = outputFormat; }

    public String getInternalDependencies() { return internalDependencies; }
    public void setInternalDependencies(String internalDependencies) { this.internalDependencies = internalDependencies; }

    public String getExternalDependencies() { return externalDependencies; }
    public void setExternalDependencies(String externalDependencies) { this.externalDependencies = externalDependencies; }

    public String getDatabaseDependencies() { return databaseDependencies; }
    public void setDatabaseDependencies(String databaseDependencies) { this.databaseDependencies = databaseDependencies; }

    public String getApiDependencies() { return apiDependencies; }
    public void setApiDependencies(String apiDependencies) { this.apiDependencies = apiDependencies; }

    public String getThirdPartyDependencies() { return thirdPartyDependencies; }
    public void setThirdPartyDependencies(String thirdPartyDependencies) { this.thirdPartyDependencies = thirdPartyDependencies; }

    public String getCommunicationProtocol() { return communicationProtocol; }
    public void setCommunicationProtocol(String communicationProtocol) { this.communicationProtocol = communicationProtocol; }

    public String getInterfaceDescription() { return interfaceDescription; }
    public void setInterfaceDescription(String interfaceDescription) { this.interfaceDescription = interfaceDescription; }

    public String getErrorHandlingStrategy() { return errorHandlingStrategy; }
    public void setErrorHandlingStrategy(String errorHandlingStrategy) { this.errorHandlingStrategy = errorHandlingStrategy; }

    public Boolean getAuthenticationRequired() { return authenticationRequired; }
    public void setAuthenticationRequired(Boolean authenticationRequired) { this.authenticationRequired = authenticationRequired; }

    public Boolean getAuthorizationRequired() { return authorizationRequired; }
    public void setAuthorizationRequired(Boolean authorizationRequired) { this.authorizationRequired = authorizationRequired; }

    public Boolean getAuditLoggingRequired() { return auditLoggingRequired; }
    public void setAuditLoggingRequired(Boolean auditLoggingRequired) { this.auditLoggingRequired = auditLoggingRequired; }

    public String getSensitiveDataHandling() { return sensitiveDataHandling; }
    public void setSensitiveDataHandling(String sensitiveDataHandling) { this.sensitiveDataHandling = sensitiveDataHandling; }

    public Integer getExpectedResponseTime() { return expectedResponseTime; }
    public void setExpectedResponseTime(Integer expectedResponseTime) { this.expectedResponseTime = expectedResponseTime; }

    public Integer getExpectedThroughput() { return expectedThroughput; }
    public void setExpectedThroughput(Integer expectedThroughput) { this.expectedThroughput = expectedThroughput; }

    public String getScalabilityConsiderations() { return scalabilityConsiderations; }
    public void setScalabilityConsiderations(String scalabilityConsiderations) { this.scalabilityConsiderations = scalabilityConsiderations; }

    public String getAssumptions() { return assumptions; }
    public void setAssumptions(String assumptions) { this.assumptions = assumptions; }

    public String getConstraints() { return constraints; }
    public void setConstraints(String constraints) { this.constraints = constraints; }

    public String getDesignNotes() { return designNotes; }
    public void setDesignNotes(String designNotes) { this.designNotes = designNotes; }

    public String getSupportingDocumentsName() { return supportingDocumentsName; }
    public void setSupportingDocumentsName(String supportingDocumentsName) { this.supportingDocumentsName = supportingDocumentsName; }
}