package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "automation_unit_tests")
public class AutomationUnitTest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "test_case_id")
    private String testCaseId = "";

    @Column(name = "test_case_name")
    private String testCaseName = "";

    @Column(name = "target_class_or_method")
    private String targetClassOrMethod = "";

    @Column(name = "testing_framework")
    private String testingFramework = "";

    @Column(name = "assertion_strategy")
    private String assertionStrategy = "";

    @Column(name = "test_status")
    private String testStatus = "";

    @Lob
    @Column(name = "test_description")
    private String testDescription = "";

    @Column(name = "execution_runner_env")
    private String executionRunnerEnv = "";

    @Column(name = "assigned_developer")
    private String assignedDeveloper = "";

    @Column(name = "timeout_threshold_ms")
    private String timeoutThresholdMs = "";

    @Column(name = "associated_user_story_id")
    private String associatedUserStoryId = "";

    @Column(name = "mocked_dependencies")
    private String mockedDependencies = "";

    @Column(name = "fixtures_required")
    private String fixturesRequired = "";

    @Column(name = "code_coverage_target_pct")
    private String codeCoverageTargetPct = "";

    @Column(name = "expected_exception_pattern")
    private String expectedExceptionPattern = "";

    @Lob
    @Column(name = "input_arguments_mockup")
    private String inputArgumentsMockup = "";

    @Lob
    @Column(name = "output_result_mockup")
    private String outputResultMockup = "";

    @Column(name = "is_flaky_test")
    private Boolean isFlakyTest = false;

    @Column(name = "requires_database_sandbox")
    private Boolean requiresDatabaseSandbox = false;

    @Column(name = "requires_network_isolation")
    private Boolean requiresNetworkIsolation = false;

    @Column(name = "memory_footprint_limit_mb")
    private String memoryFootprintLimitMb = "";

    @Column(name = "log_severity_filter")
    private String logSeverityFilter = "";

    @Column(name = "jira_issue_key")
    private String jiraIssueKey = "";

    @Lob
    @Column(name = "preconditions")
    private String preconditions = "";

    @Lob
    @Column(name = "side_effects")
    private String sideEffects = "";

    @Lob
    @Column(name = "refactoring_notes")
    private String refactoringNotes = "";

    @Column(name = "test_artifact_name")
    private String testArtifactName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTestCaseId() { return testCaseId; }
    public void setTestCaseId(String testCaseId) { this.testCaseId = testCaseId; }

    public String getTestCaseName() { return testCaseName; }
    public void setTestCaseName(String testCaseName) { this.testCaseName = testCaseName; }

    public String getTargetClassOrMethod() { return targetClassOrMethod; }
    public void setTargetClassOrMethod(String targetClassOrMethod) { this.targetClassOrMethod = targetClassOrMethod; }

    public String getTestingFramework() { return testingFramework; }
    public void setTestingFramework(String testingFramework) { this.testingFramework = testingFramework; }

    public String getAssertionStrategy() { return assertionStrategy; }
    public void setAssertionStrategy(String assertionStrategy) { this.assertionStrategy = assertionStrategy; }

    public String getTestStatus() { return testStatus; }
    public void setTestStatus(String testStatus) { this.testStatus = testStatus; }

    public String getTestDescription() { return testDescription; }
    public void setTestDescription(String testDescription) { this.testDescription = testDescription; }

    public String getExecutionRunnerEnv() { return executionRunnerEnv; }
    public void setExecutionRunnerEnv(String executionRunnerEnv) { this.executionRunnerEnv = executionRunnerEnv; }

    public String getAssignedDeveloper() { return assignedDeveloper; }
    public void setAssignedDeveloper(String assignedDeveloper) { this.assignedDeveloper = assignedDeveloper; }

    public String getTimeoutThresholdMs() { return timeoutThresholdMs; }
    public void setTimeoutThresholdMs(String timeoutThresholdMs) { this.timeoutThresholdMs = timeoutThresholdMs; }

    public String getAssociatedUserStoryId() { return associatedUserStoryId; }
    public void setAssociatedUserStoryId(String associatedUserStoryId) { this.associatedUserStoryId = associatedUserStoryId; }

    public String getMockedDependencies() { return mockedDependencies; }
    public void setMockedDependencies(String mockedDependencies) { this.mockedDependencies = mockedDependencies; }

    public String getFixturesRequired() { return fixturesRequired; }
    public void setFixturesRequired(String fixturesRequired) { this.fixturesRequired = fixturesRequired; }

    public String getCodeCoverageTargetPct() { return codeCoverageTargetPct; }
    public void setCodeCoverageTargetPct(String codeCoverageTargetPct) { this.codeCoverageTargetPct = codeCoverageTargetPct; }

    public String getExpectedExceptionPattern() { return expectedExceptionPattern; }
    public void setExpectedExceptionPattern(String expectedExceptionPattern) { this.expectedExceptionPattern = expectedExceptionPattern; }

    public String getInputArgumentsMockup() { return inputArgumentsMockup; }
    public void setInputArgumentsMockup(String inputArgumentsMockup) { this.inputArgumentsMockup = inputArgumentsMockup; }

    public String getOutputResultMockup() { return outputResultMockup; }
    public void setOutputResultMockup(String outputResultMockup) { this.outputResultMockup = outputResultMockup; }

    public Boolean getIsFlakyTest() { return isFlakyTest; }
    public void setIsFlakyTest(Boolean isFlakyTest) { this.isFlakyTest = isFlakyTest; }

    public Boolean getRequiresDatabaseSandbox() { return requiresDatabaseSandbox; }
    public void setRequiresDatabaseSandbox(Boolean requiresDatabaseSandbox) { this.requiresDatabaseSandbox = requiresDatabaseSandbox; }

    public Boolean getRequiresNetworkIsolation() { return requiresNetworkIsolation; }
    public void setRequiresNetworkIsolation(Boolean requiresNetworkIsolation) { this.requiresNetworkIsolation = requiresNetworkIsolation; }

    public String getMemoryFootprintLimitMb() { return memoryFootprintLimitMb; }
    public void setMemoryFootprintLimitMb(String memoryFootprintLimitMb) { this.memoryFootprintLimitMb = memoryFootprintLimitMb; }

    public String getLogSeverityFilter() { return logSeverityFilter; }
    public void setLogSeverityFilter(String logSeverityFilter) { this.logSeverityFilter = logSeverityFilter; }

    public String getJiraIssueKey() { return jiraIssueKey; }
    public void setJiraIssueKey(String jiraIssueKey) { this.jiraIssueKey = jiraIssueKey; }

    public String getPreconditions() { return preconditions; }
    public void setPreconditions(String preconditions) { this.preconditions = preconditions; }

    public String getSideEffects() { return sideEffects; }
    public void setSideEffects(String sideEffects) { this.sideEffects = sideEffects; }

    public String getRefactoringNotes() { return refactoringNotes; }
    public void setRefactoringNotes(String refactoringNotes) { this.refactoringNotes = refactoringNotes; }

    public String getTestArtifactName() { return testArtifactName; }
    public void setTestArtifactName(String testArtifactName) { this.testArtifactName = testArtifactName; }
}