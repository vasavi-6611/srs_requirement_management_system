package demo.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import demo.backend.entity.UserProfile;
import demo.backend.repository.UserProfileRepository;

@RestController
@RequestMapping("/api/user-profile")
@CrossOrigin(origins = {"*"})
public class UserProfileController {

    @Autowired
    private UserProfileRepository repository;

    // 1. Create User Profile
    @PostMapping
    public ResponseEntity<UserProfile> createUserProfile(@RequestBody UserProfile profile) {
        UserProfile saved = repository.save(profile);
        return ResponseEntity.ok(saved);
    }

    // 2. Get All User Profiles
    @GetMapping
    public List<UserProfile> getAllProfiles() {
        return repository.findAll();
    }

    // 3. Get User Profile By Primary Key ID
    @GetMapping("/{id}")
    public ResponseEntity<UserProfile> getProfileById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 4. Delete User Profile By Primary Key ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUserProfile(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.ok("User Profile Deleted Successfully");
    }

    // 5. Update User Profile
    @PutMapping("/{id}")
    public ResponseEntity<UserProfile> updateUserProfile(
            @PathVariable Long id,
            @RequestBody UserProfile updatedProfile) {

        return repository.findById(id).map(profile -> {
            profile.setUserClassId(updatedProfile.getUserClassId());
            profile.setUserClassName(updatedProfile.getUserClassName());
            profile.setUserCategory(updatedProfile.getUserCategory());
            profile.setUserDescription(updatedProfile.getUserDescription());
            profile.setTechnicalExpertiseLevel(updatedProfile.getTechnicalExpertiseLevel());
            profile.setDomainKnowledgeLevel(updatedProfile.getDomainKnowledgeLevel());
            profile.setExperienceLevel(updatedProfile.getExperienceLevel());
            profile.setEducationLevel(updatedProfile.getEducationLevel());
            profile.setComputerProficiency(updatedProfile.getComputerProficiency());
            profile.setPreferredLanguage(updatedProfile.getPreferredLanguage());
            profile.setPrimaryResponsibilities(updatedProfile.getPrimaryResponsibilities());
            profile.setSecondaryResponsibilities(updatedProfile.getSecondaryResponsibilities());
            profile.setBusinessGoals(updatedProfile.getBusinessGoals());
            profile.setExpectedOutcomes(updatedProfile.getExpectedOutcomes());
            profile.setKeyActivitiesPerformed(updatedProfile.getKeyActivitiesPerformed());
            profile.setUsageFrequency(updatedProfile.getUsageFrequency());
            profile.setUsageDurationPerDay(updatedProfile.getUsageDurationPerDay());
            profile.setExpectedNumberOfUsers(updatedProfile.getExpectedNumberOfUsers());
            profile.setConcurrentUsersExpected(updatedProfile.getConcurrentUsersExpected());
            profile.setPeakUsageTime(updatedProfile.getPeakUsageTime());
            profile.setMobileAccessRequired(updatedProfile.isMobileAccessRequired());
            profile.setRemoteAccessRequired(updatedProfile.isRemoteAccessRequired());
            profile.setInternetDependency(updatedProfile.getInternetDependency());
            profile.setAccessibilityRequirements(updatedProfile.getAccessibilityRequirements());
            profile.setTrainingRequired(updatedProfile.isTrainingRequired());
            profile.setHelpDocumentationRequired(updatedProfile.isHelpDocumentationRequired());
            profile.setSecurityClearanceLevel(updatedProfile.getSecurityClearanceLevel());
            profile.setDataAccessLevel(updatedProfile.getDataAccessLevel());
            profile.setUserConstraints(updatedProfile.getUserConstraints());
            profile.setAssumptionsAboutUsers(updatedProfile.getAssumptionsAboutUsers());

            UserProfile saved = repository.save(profile);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }
}