import React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";

export default function CustomNavbar({
  title,
  icon,
  buttonText,
  onButtonClick,
  onIconClick,
  position = "static",
}) {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position={position}>
        
        <Toolbar>

          {icon && (
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              onClick={onIconClick}
              sx={{ mr: 2 }}
            >
              {icon}
            </IconButton>
          )}

          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1 }}
          >
            {title}
          </Typography>

          {buttonText && (
            <Button
              color="inherit"
              onClick={onButtonClick}
            >
              {buttonText}
            </Button>
          )}

        </Toolbar>

      </AppBar>
    </Box>
  );
}