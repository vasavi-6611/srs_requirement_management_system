import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomTextarea from "../components/CustomTextarea";

export default function InfrastructureSecurityForm() {
  // Navigation & Matrix View State Controls
  const [viewMode, setViewMode] = useState("LIST"); // Supported Modes: "LIST", "FORM", "VIEW_DETAILS"
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  // Form Initial Baseline Structural State
  const emptyForm = {
    cicdPipelineIntegration: false,
    securityPenetrationTesting: "",
    testEnvironmentRequirements: "",
    testDataSanitizationRequired: false,
    testPlanDocumentName: "",
    complianceStandardRequirement: "",
    vulnerabilityScanFrequency: "",
    maxAllowedSev1Defects: 0,
    maxAllowedSev2Defects: 2,
    sslCertExpirationAlertDays: 30,
    sandboxInstanceCount: 1,
    environmentTtlDays: 7,
    iamAccessReviewCycle: "QUARTERLY",
    encryptionAlgorithmStatic: "AES_256",
    staticCodeAnalysisTool: "",
    penetrationReportArtifactName: "",
    infrastructureDeploymentYamlName: ""
  };

  const [formData, setFormData] = useState(emptyForm);

  // Fetch Existing Infrastructure Records Matrix on Mount
  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      console.log("Fetching infrastructure records from /api/testing/infrastructure...");
      const response = await api.get("/api/testing/infrastructure");
      console.log("API Response received successfully:", response.data);
      
      const records = Array.isArray(response.data) 
        ? response.data 
        : (response.data.content || response.data._embedded?.records || []);
        
      console.log("Parsed records list to display:", records);
      setRecordsList(records);
    } catch (error) {
      console.error("CRITICAL ERROR fetching infrastructure registry:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  // POST or PUT Network Actions Channel
  const handleSubmit = async () => {
    try {
      console.log("Submitting Infrastructure Profile Configuration:", formData);
      if (isEditing) {
        await api.put(`/api/testing/infrastructure/${formData.id}`, formData);
        alert("Infrastructure provisions updated successfully!");
      } else {
        await api.post("/api/testing/infrastructure", formData);
        alert("Infrastructure & Security provisions locked successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to submit infrastructure config.");
    }
  };

  // DELETE Network Action Trigger
  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this infrastructure security configuration profile?")) {
      try {
        await api.delete(`/api/testing/infrastructure/${id}`);
        alert("Infrastructure Template Dropped Successfully!");
        await fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to delete selected database register reference entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  // Read-Only Text Block Wrapper Component
  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Mandatory Enforced" : "❌ Disengaged / Bypassed") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Automation Hooks & Pipelines",
      "2. Security, Compliance & Defect Gates",
      "3. Environment Specs & Topology",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>

      {/* ======================================= */}
      {/* 1. DASHBOARD REGISTRY GRID MATRIX TRACK */}
      {/* ======================================= */}
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Infrastructure & Security Parameters
            </h2>
            <CustomButton text="+ Establish Security Profile" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Profile Ref</th>
                <th style={{ padding: "14px" }}>Static Code Analyzer</th>
                <th style={{ padding: "14px" }}>Compliance Target</th>
                <th style={{ padding: "14px" }}>Vulnerability Policy</th>
                <th style={{ padding: "14px" }}>Sandbox Targets</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No infrastructure templates or security clusters configured. Create a blueprint entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>INF-{record.id || index + 1}</td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "700" }}>{record.staticCodeAnalysisTool || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.complianceStandardRequirement || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px", fontWeight: "600" }}>{record.vulnerabilityScanFrequency || "—"}</span></td>
                    <td style={{ padding: "14px", fontWeight: "500", color: "#16a34a" }}>{record.sandboxInstanceCount || "0"} Nodes</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Drop</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ======================================= */}
      {/* 2. THREE-STEP WIZARD INGESTION FORMS    */}
      {/* ======================================= */}
      {viewMode === "FORM" && (
        <div className="form-container infrastructure-security-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>4. Infrastructure & Security Parameters Definition</h2>
            <CustomButton text="Cancel Blueprint" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {/* --- STEP 1: Automation Hooks & Pipelines --- */}
            {step === 1 && (
              <>
                <div style={{ ...fullWidthItem, marginBottom: "10px" }}>
                  <CustomCheckbox
                    label="Mandatory Continuous Integration Pipeline Automatic Test Failure Intercept Hook"
                    checked={formData.cicdPipelineIntegration}
                    onChange={(e) => handleChange("cicdPipelineIntegration", e.target.checked)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomRadioGroup
                    label="Static Code Analysis Security Engine (SAST)"
                    row={true}
                    value={formData.staticCodeAnalysisTool}
                    onChange={(e) => handleChange("staticCodeAnalysisTool", e.target.value)}
                    options={[
                      { label: "SonarQube Core Platform Engine", value: "SONARQUBE" },
                      { label: "Checkmarx Enterprise Static Scanner", value: "CHECKMARX" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete
                    label="Target Regulatory Compliance Framework Base"
                    width="100%"
                    value={formData.complianceStandardRequirement}
                    onChange={(newValue) => handleChange("complianceStandardRequirement", newValue)}
                    options={["ISO/IEC 27001 Certification Framework", "SOC2 Type II Security Protocol Trust Matrix", "GDPR Data Processing Privacy Compliance Architecture"]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea
                    label="Security Vulnerability Penetration Evaluation Parameters (OWASP Audit Strategy)"
                    value={formData.securityPenetrationTesting}
                    onChange={(e) => handleChange("securityPenetrationTesting", e.target.value)}
                  />
                </div>
              </>
            )}

            {/* --- STEP 2: Security, Compliance & Defect Gates --- */}
            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="Automated Vulnerability Image Scanning Routine Policy"
                    value={formData.vulnerabilityScanFrequency}
                    onChange={(e) => handleChange("vulnerabilityScanFrequency", e.target.value)}
                    options={[
                      { label: "On Every Code Commit Pipeline Trigger", value: "PER_COMMIT" },
                      { label: "Daily Scheduled Midnight Background Routine", value: "DAILY" },
                      { label: "Weekly Architecture Security Synchronized Scan", value: "WEEKLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="At-Rest Data Encryption Standards Protocol"
                    value={formData.encryptionAlgorithmStatic}
                    onChange={(e) => handleChange("encryptionAlgorithmStatic", e.target.value)}
                    options={[
                      { label: "Advanced Encryption Standard (AES-256 Bit block cipher)", value: "AES_256" },
                      { label: "ChaCha20 stream cipher with Poly1305 authenticator", value: "CHACHA20" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Maximum Allowed Unresolved Severity-1 (Blocker) Defects"
                    fullWidth={true}
                    min={0}
                    max={5}
                    value={formData.maxAllowedSev1Defects}
                    onChange={(e) => handleChange("maxAllowedSev1Defects", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Maximum Allowed Unresolved Severity-2 (Critical) Defects"
                    fullWidth={true}
                    min={0}
                    max={20}
                    value={formData.maxAllowedSev2Defects}
                    onChange={(e) => handleChange("maxAllowedSev2Defects", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="SSL / TLS Certificate Expiration Alert Advance Threshold (Days)"
                    fullWidth={true}
                    min={7}
                    max={90}
                    value={formData.sslCertExpirationAlertDays}
                    onChange={(e) => handleChange("sslCertExpirationAlertDays", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="IAM Active Account Access Credentials Audit Review Lifecycle"
                    value={formData.iamAccessReviewCycle}
                    onChange={(e) => handleChange("iamAccessReviewCycle", e.target.value)}
                    options={[
                      { label: "Monthly Governance Inspection Cycle", value: "MONTHLY" },
                      { label: "Quarterly Enterprise Access Assessment Review", value: "QUARTERLY" },
                    ]}
                  />
                </div>
              </>
            )}

            {/* --- STEP 3: Environment Specs & Topology --- */}
            {step === 3 && (
              <>
                <div style={fullWidthItem}>
                  <CustomTextarea
                    label="Isolated Test Sandbox Infrastructure Environment Setup Specifications"
                    value={formData.testEnvironmentRequirements}
                    onChange={(e) => handleChange("testEnvironmentRequirements", e.target.value)}
                  />
                </div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", justifyContent: "center", marginBottom: "10px" }}>
                  <CustomCheckbox
                    label="Enforce Complete Synthetic Masking / Sanitization Rules on Staging Databases"
                    checked={formData.testDataSanitizationRequired}
                    onChange={(e) => handleChange("testDataSanitizationRequired", e.target.checked)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Total Concurrently Provisioned Sandbox Target Instances"
                    fullWidth={true}
                    min={1}
                    max={20}
                    value={formData.sandboxInstanceCount}
                    onChange={(e) => handleChange("sandboxInstanceCount", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Ephemeral Environment Automatic Lease TTL Lifespan (Days)"
                    fullWidth={true}
                    min={1}
                    max={30}
                    value={formData.environmentTtlDays}
                    onChange={(e) => handleChange("environmentTtlDays", e.target.value)}
                  />
                </div>

                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Master Architecture QA Test Plan Document:</label>
                  <CustomFileUpload
                    buttonText="Upload Master Test Plan Document"
                    fileName={formData.testPlanDocumentName}
                    onChange={(e) => handleFileChange("testPlanDocumentName", e)}
                    accept=".pdf,.doc,.docx,.xlsx"
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Penetration Audit Profile Artifact:</label>
                  <CustomFileUpload
                    buttonText="Upload Penetration Assessment Scope"
                    fileName={formData.penetrationReportArtifactName}
                    onChange={(e) => handleFileChange("penetrationReportArtifactName", e)}
                    accept=".pdf,.json,.csv"
                  />
                </div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center", marginTop: "10px" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>GitOps Sandbox Orchestration Configuration YAML Blueprint:</label>
                  <CustomFileUpload
                    buttonText="Upload IaC Infrastructure Blueprint"
                    fileName={formData.infrastructureDeploymentYamlName}
                    onChange={(e) => handleFileChange("infrastructureDeploymentYamlName", e)}
                    accept=".yaml,.yml,.json"
                  />
                </div>
              </>
            )}
          </div>

          {/* Wizard Interface Lower Segment Control Interceptors */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Commit Strategic Updates" : "Commit Infrastructure Config Model"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {/* ======================================= */}
      {/* 3. COMPREHENSIVE DETAIL DEEP INSPECTION */}
      {/* ======================================= */}
      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Infrastructure & Security Policy Target Metrics</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Template Verification Anchor: INF-SEC-ID-{selectedRecord.id || "LIVE"}</p>
            </div>
            <CustomButton text="Return to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Automation Hooks & Pipelines</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="CI/CD Failure Intercept Hook" value={selectedRecord.cicdPipelineIntegration} />
            <DataField label="Static Code Security Analyzer" value={selectedRecord.staticCodeAnalysisTool} />
            <DataField label="Regulatory Compliance Framework" value={selectedRecord.complianceStandardRequirement} />
          </div>
          <div style={{ marginBottom: "30px" }}>
            <DataField label="OWASP Vulnerability Pentest Parameters" value={selectedRecord.securityPenetrationTesting} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Security, Compliance & Defect Gates</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Vulnerability Scan Routine" value={selectedRecord.vulnerabilityScanFrequency} />
            <DataField label="At-Rest Encryption Protocol" value={selectedRecord.encryptionAlgorithmStatic} />
            <DataField label="Max Allowed Sev-1 Defects" value={selectedRecord.maxAllowedSev1Defects} />
            <DataField label="Max Allowed Sev-2 Defects" value={selectedRecord.maxAllowedSev2Defects} />
            <DataField label="SSL Cert Expiration Alert Advance" value={`${selectedRecord.sslCertExpirationAlertDays} Days`} />
            <DataField label="IAM Credentials Audit Lifecycle" value={selectedRecord.iamAccessReviewCycle} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Environment Specs & Topology</h4>
          <div style={{ marginBottom: "20px" }}>
            <DataField label="Sandbox Isolation Environment Specifications" value={selectedRecord.testEnvironmentRequirements} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Staging Database Data Masking" value={selectedRecord.testDataSanitizationRequired} />
            <DataField label="Target Sandbox Instances" value={`${selectedRecord.sandboxInstanceCount} Instances`} />
            <DataField label="Ephemeral Lease Run TTL" value={`${selectedRecord.environmentTtlDays} Days`} />
            <DataField label="Master Architecture Test Plan" value={selectedRecord.testPlanDocumentName} />
            <DataField label="Penetration Audit Profile Artifact" value={selectedRecord.penetrationReportArtifactName} />
          </div>
          <div style={{ marginTop: "16px" }}>
            <DataField label="GitOps Sandbox Orchestration Configuration" value={selectedRecord.infrastructureDeploymentYamlName} />
          </div>
        </div>
      )}
    </div>
  );
}