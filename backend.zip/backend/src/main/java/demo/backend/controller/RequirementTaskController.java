package demo.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import demo.backend.entity.RequirementTask;
import demo.backend.repository.RequirementTaskRepository;

@RestController
@RequestMapping("/api/requirements")
@CrossOrigin(origins = {"*"})
public class RequirementTaskController {

    @Autowired
    private RequirementTaskRepository repository;

    // 1. Create Requirement Task
    @PostMapping
    public ResponseEntity<RequirementTask> createRequirement(@RequestBody RequirementTask requirement) {
        // Assign default values for columns marked NOT NULL in Oracle if they are blank/null
        if (requirement.getComplexityLevel() == null || requirement.getComplexityLevel().trim().isEmpty()) {
            requirement.setComplexityLevel("1");
        }
        if (requirement.getApproved() == null) {
            requirement.setApproved(false);
        }
        // Add a default for estimated effort if it's missing or mapped as a string/number
        // (If estimatedEffortHours is a String or Integer in your entity, handle it safely here)
        if (requirement.getEstimatedEffortHours() == null) {
            requirement.setEstimatedEffortHours(0.0);
        }

        RequirementTask saved = repository.save(requirement);
        return ResponseEntity.ok(saved);
    }

    // 2. Get All Requirement Tasks
    @GetMapping
    public List<RequirementTask> getAllRequirements() {
        return repository.findAll();
    }

    // 3. Get Requirement Task By ID
    @GetMapping("/{id}")
    public ResponseEntity<RequirementTask> getRequirementById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 4. Delete Requirement Task By ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRequirement(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.ok("Requirement Task Deleted Successfully");
    }

    // 5. Update Requirement Task
    @PutMapping("/{id}")
    public ResponseEntity<RequirementTask> updateRequirement(
            @PathVariable Long id,
            @RequestBody RequirementTask updatedReq) {

        return repository.findById(id).map(req -> {
            req.setRequirementId(updatedReq.getRequirementId());
            req.setRequirementName(updatedReq.getRequirementName());
            req.setRequirementTitle(updatedReq.getRequirementTitle());
            req.setRequirementCategory(updatedReq.getRequirementCategory());
            req.setRequirementType(updatedReq.getRequirementType());
            req.setRequirementSource(updatedReq.getRequirementSource());
            req.setStakeholderName(updatedReq.getStakeholderName());
            req.setUserClass(updatedReq.getUserClass());
            req.setRequirementDescription(updatedReq.getRequirementDescription());
            req.setBusinessObjective(updatedReq.getBusinessObjective());
            req.setBusinessValue(updatedReq.getBusinessValue());
            req.setProblemStatement(updatedReq.getProblemStatement());
            req.setRequirementRationale(updatedReq.getRequirementRationale());
            req.setExpectedBenefit(updatedReq.getExpectedBenefit());
            req.setPriority(updatedReq.getPriority());
            req.setRiskLevel(updatedReq.getRiskLevel());
            req.setComplexityLevel(updatedReq.getComplexityLevel());
            req.setStatus(updatedReq.getStatus());
            req.setTriggerEvent(updatedReq.getTriggerEvent());
            req.setPreconditions(updatedReq.getPreconditions());
            req.setPostconditions(updatedReq.getPostconditions());
            req.setInputData(updatedReq.getInputData());
            req.setOutputData(updatedReq.getOutputData());
            req.setProcessingRules(updatedReq.getProcessingRules());
            req.setDependencies(updatedReq.getDependencies());
            req.setAssumptions(updatedReq.getAssumptions());
            req.setConstraints(updatedReq.getConstraints());
            req.setVerificationMethod(updatedReq.getVerificationMethod());
            req.setAcceptanceCriteria(updatedReq.getAcceptanceCriteria());
            req.setAdditionalNotes(updatedReq.getAdditionalNotes());

            RequirementTask saved = repository.save(req);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }
}