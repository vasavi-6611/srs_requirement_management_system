package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.ModuleDesign;
import demo.backend.repository.ModuleDesignRepository;

@RestController
@RequestMapping("/api/modules")
@CrossOrigin(origins = {"*"})
public class ModuleDesignController {

    @Autowired
    private ModuleDesignRepository repository;

    @GetMapping({"", "/"})
    public List<ModuleDesign> getAllModules() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ModuleDesign> getModuleById(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<ModuleDesign> saveModule(@RequestBody ModuleDesign module) {
        return ResponseEntity.ok(repository.save(module));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ModuleDesign> updateModule(@PathVariable Long id, @RequestBody ModuleDesign details) {
        return repository.findById(id).map(module -> {
            module.setModuleId(details.getModuleId());
            module.setModuleName(details.getModuleName());
            module.setModuleVersion(details.getModuleVersion());
            module.setModuleCategory(details.getModuleCategory());
            module.setModuleType(details.getModuleType());
            module.setModuleStatus(details.getModuleStatus());
            module.setModuleDescription(details.getModuleDescription());
            module.setModuleObjective(details.getModuleObjective());
            module.setPrimaryResponsibility(details.getPrimaryResponsibility());
            module.setSecondaryResponsibility(details.getSecondaryResponsibility());
            module.setBusinessRules(details.getBusinessRules());
            module.setProcessingLogic(details.getProcessingLogic());
            module.setRelatedRequirements(details.getRelatedRequirements());
            module.setRequirementPriority(details.getRequirementPriority());
            module.setRequirementSource(details.getRequirementSource());
            module.setRelatedUserClasses(details.getRelatedUserClasses());
            module.setRelatedStakeholders(details.getRelatedStakeholders());
            module.setInputs(details.getInputs());
            module.setOutputs(details.getOutputs());
            module.setInputValidationRules(details.getInputValidationRules());
            module.setOutputFormat(details.getOutputFormat());
            module.setInternalDependencies(details.getInternalDependencies());
            module.setExternalDependencies(details.getExternalDependencies());
            module.setDatabaseDependencies(details.getDatabaseDependencies());
            module.setApiDependencies(details.getApiDependencies());
            module.setThirdPartyDependencies(details.getThirdPartyDependencies());
            module.setCommunicationProtocol(details.getCommunicationProtocol());
            module.setInterfaceDescription(details.getInterfaceDescription());
            module.setErrorHandlingStrategy(details.getErrorHandlingStrategy());
            module.setAuthenticationRequired(details.getAuthenticationRequired());
            module.setAuthorizationRequired(details.getAuthorizationRequired());
            module.setAuditLoggingRequired(details.getAuditLoggingRequired());
            module.setSensitiveDataHandling(details.getSensitiveDataHandling());
            module.setExpectedResponseTime(details.getExpectedResponseTime());
            module.setExpectedThroughput(details.getExpectedThroughput());
            module.setScalabilityConsiderations(details.getScalabilityConsiderations());
            module.setAssumptions(details.getAssumptions());
            module.setConstraints(details.getConstraints());
            module.setDesignNotes(details.getDesignNotes());
            module.setSupportingDocumentsName(details.getSupportingDocumentsName());

            return ResponseEntity.ok(repository.save(module));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteModule(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}