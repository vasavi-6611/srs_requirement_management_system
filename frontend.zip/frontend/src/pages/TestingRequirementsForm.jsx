import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function TestingRequirementForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    requirementId: "",
    requirementName: "",
    moduleContext: "",
    priorityTier: "",
    testingType: "",
    requirementStatus: "",
    requirementDescription: "",
    targetEnvironment: "",
    assignedQAEngineer: "",
    executionOrder: "",
    associatedUserStoryId: "",
    rbacRolesTargeted: "",
    featureFlagsTargeted: "",
    hardwareDeviceConstraints: "",
    expectedOutcomePattern: "",
    inputDatasetMockup: "",
    automationScriptPath: "",
    analyticsTrackingKey: "",
    isRegressionTest: true,
    requiresManualVerification: false,
    requiresThirdPartySignOff: false,
    slaThresholdMs: "",
    slaSeverityColor: "",
    jiraIssueKey: "",
    targetWindow: "",
    assumptions: "",
    constraints: "",
    designNotes: "",
    supportingDocumentsName: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/testing-requirements");
      const records = Array.isArray(response.data) ? response.data : response.data.content || [];
      setRecordsList(records);
    } catch (error) {
      console.error("Error fetching testing requirement registry:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing) {
        await api.put(`/api/testing-requirements/${formData.id}`, formData);
        alert("Testing Requirement Specification Updated Successfully!");
      } else {
        await api.post("/api/testing-requirements", formData);
        alert("Testing Requirement Configuration Saved Successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Testing Requirement Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this testing requirement specification configuration?")) {
      try {
        await api.delete(`/api/testing-requirements/${id}`);
        alert("Testing Requirement Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Requirement Profile & Scope",
      "2. Runtime Schemes & Environment Matrix",
      "3. Validation Criteria & SLA Constraints",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              QA Testing Requirements Form
            </h2>
            <CustomButton text="+ Configure New Testing Requirement" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Requirement ID</th>
                <th style={{ padding: "14px" }}>Requirement Name</th>
                <th style={{ padding: "14px" }}>Module Context</th>
                <th style={{ padding: "14px" }}>Testing Strategy</th>
                <th style={{ padding: "14px" }}>Priority State</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active testing requirements or baseline criteria logs configured. Create an entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>{record.requirementId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.requirementName || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{record.moduleContext || "—"}</span></td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.testingType || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.priorityTier || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container testing-requirements-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Testing Requirement Specification Schema</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomTextField label="Requirement Specification ID" fullWidth={true} value={formData.requirementId} onChange={(e) => handleChange("requirementId", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Requirement Core Action Reference" width="100%" value={formData.requirementName} onChange={(newValue) => handleChange("requirementName", newValue)}
                    options={[
                      "Distributed Database Failover Emulation",
                      "Multi-Factor Session Handshake Invalidation",
                      "Cryptographic Envelope Cipher Verification",
                      "High-Throughput Concurrency Volumetric Loading",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Target Application Module Context" fullWidth={true} value={formData.moduleContext} onChange={(e) => handleChange("moduleContext", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Requirement Priority Tier Escalation" value={formData.priorityTier} onChange={(e) => handleChange("priorityTier", e.target.value)}
                    options={[
                      { label: "Tier 0 - System-Wide Critical Defect Block", value: "CRITICAL" },
                      { label: "Tier 1 - High Priority Pipeline Guardrail", value: "HIGH" },
                      { label: "Tier 2 - Medium Scope Production Parity", value: "MEDIUM" },
                      { label: "Tier 3 - Minor Visual Polish Verification", value: "LOW" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Testing Execution Strategy Classification" value={formData.testingType} onChange={(e) => handleChange("testingType", e.target.value)}
                    options={[
                      { label: "Isolated Unit Execution Suite", value: "UNIT" },
                      { label: "Cross-Module Integration Contract Testing", value: "INTEGRATION" },
                      { label: "End-to-End Visual Sandbox Validation", value: "E2E" },
                      { label: "Volumetric High-Load Performance Evaluation", value: "PERFORMANCE" },
                      { label: "Penetration Sandbox Security Auditing", value: "SECURITY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Requirement Lifecycle Status" value={formData.requirementStatus} onChange={(e) => handleChange("requirementStatus", e.target.value)}
                    options={[
                      { label: "Draft Proposal Definition", value: "DRAFT" },
                      { label: "Approved Functional Blueprint", value: "APPROVED" },
                      { label: "Active Test Cycle Execution Engaged", value: "IN_TESTING" },
                      { label: "Verified Production Sign-off Complete", value: "VERIFIED" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Requirement Core Functional Description" value={formData.requirementDescription} onChange={(e) => handleChange("requirementDescription", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Target Verification Environment" fullWidth={true} value={formData.targetEnvironment} onChange={(e) => handleChange("targetEnvironment", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Lead Assigned Quality Assurance Engineer" fullWidth={true} value={formData.assignedQAEngineer} onChange={(e) => handleChange("assignedQAEngineer", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Execution Flow Blocking Dependency Mode" value={formData.targetWindow} onChange={(e) => handleChange("targetWindow", e.target.value)}
                    options={[
                      { label: "Halt Entire Pipeline On Failure (_blocking)", value: "_blocking" },
                      { label: "Continue Sequence and Flag Fail Log (_non_blocking)", value: "_non_blocking" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Positional Test Execution Order Sequence Priority" fullWidth={true} min={1} value={formData.executionOrder} onChange={(e) => handleChange("executionOrder", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomAutocomplete label="Parent Product Specification / User Story ID Mapping" width="100%" value={formData.associatedUserStoryId} onChange={(newValue) => handleChange("associatedUserStoryId", newValue)}
                    options={["None - Autonomous Independent Baseline Structure", "STORY-101 (Distributed Cache Engine)", "STORY-205 (Stripe Gateway Hook Integration)"]}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Target Security RBAC Authorization Groups Under Evaluation" width="100%" value={formData.rbacRolesTargeted} onChange={(newValue) => handleChange("rbacRolesTargeted", newValue)}
                    options={[
                      "Global Administrator Super User",
                      "Operational Desk Analyst Tier",
                      "Standard Authenticated Consumer Account",
                      "Guest / Unauthenticated Profile Route",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Interlocked Feature Flags Under Testing Matrix Condition" width="100%" value={formData.featureFlagsTargeted} onChange={(newValue) => handleChange("featureFlagsTargeted", newValue)}
                    options={[
                      "None - Always Pure Static Release Environment",
                      "ENABLE_PREDICTIVE_ANALYTICS_V2",
                      "STRIPE_BILLING_PORTAL_UPGRADE",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Hardware Device & Runtime Visibility Matrix Constraints" value={formData.responsiveVisibility} onChange={(e) => handleChange("responsiveVisibility", e.target.value)}
                    options={[
                      { label: "Evaluate Across All Hybrid Screen Form Factors", value: "ALL_DEVICES" },
                      { label: "Isolated Mobile iOS/Android Emulation Context", value: "MOBILE_ONLY" },
                      { label: "Headless Linux Virtualization Cluster Core Exclusive", value: "DESKTOP_ONLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Associated Automated Script Execution Suite Name" fullWidth={true} value={formData.automationScriptPath} onChange={(e) => handleChange("automationScriptPath", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Expected Outcome Telemetry Signature Logic Pattern Matching" value={formData.expectedOutcomePattern} onChange={(e) => handleChange("expectedOutcomePattern", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Default Input Dataset Mockup JSON Array Payload Configurations" value={formData.inputDatasetMockup} onChange={(e) => handleChange("inputDatasetMockup", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextField label="Static Hardware Core Node Device Cluster Target Path" fullWidth={true} value={formData.hardwareDeviceConstraints} onChange={(e) => handleChange("hardwareDeviceConstraints", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Test Is Flagged For Continuous Integration Regression Suite" checked={formData.isRegressionTest} onChange={(e) => handleChange("isRegressionTest", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce Manual Quality Assurance Visual Verification Verification Check" checked={formData.requiresManualVerification} onChange={(e) => handleChange("requiresManualVerification", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce External Enterprise Architecture Third Party Compliance Sign-Off" checked={formData.requiresThirdPartySignOff} onChange={(e) => handleChange("requiresThirdPartySignOff", e.target.checked)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="SLA Latency Constraint Execution Threshold Timeout (ms)" fullWidth={true} value={formData.slaThresholdMs} onChange={(e) => handleChange("slaThresholdMs", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="SLA Alert Threshold Visual Theme Accent Hex Value" fullWidth={true} value={formData.slaSeverityColor} onChange={(e) => handleChange("slaSeverityColor", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Bi-Directional Atlassian Jira Tracking Reference Issue Key" fullWidth={true} value={formData.jiraIssueKey} onChange={(e) => handleChange("jiraIssueKey", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Behavior Telemetry Pipeline Analytics Core Tracking Identity Event Key" fullWidth={true} value={formData.analyticsTrackingKey} onChange={(e) => handleChange("analyticsTrackingKey", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Architecture Mock Testing Baseline Assumptions" value={formData.assumptions} onChange={(e) => handleChange("assumptions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Hardware / Software Boundary Pipeline System Hard Constraints" value={formData.constraints} onChange={(e) => handleChange("constraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Infrastructure Quality Engineering Pipeline Performance Tuning Notes" value={formData.designNotes} onChange={(e) => handleChange("designNotes", e.target.value)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Supporting System Requirement Specification (SRS) Attachment Log Asset:</label>
                  <CustomFileUpload buttonText="Upload Requirement Specification Artifact" fileName={formData.supportingDocumentsName} onChange={(e) => handleFileChange("supportingDocumentsName", e)} accept=".pdf,.doc,.docx,.xlsx,.json,.yaml,.xml" />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Testing Requirement Spec" : "Save Testing Requirement Node"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Testing Requirement Architecture Blueprint Details Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Database Reference: REQ-ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Requirement Profile & Scope</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Requirement ID" value={selectedRecord.requirementId} />
            <DataField label="Requirement Core Action" value={selectedRecord.requirementName} />
            <DataField label="Application Module Context" value={selectedRecord.moduleContext} />
            <DataField label="Requirement Priority Tier" value={selectedRecord.priorityTier} />
            <DataField label="Execution Strategy Type" value={selectedRecord.testingType} />
            <DataField label="Requirement Lifecycle Status" value={selectedRecord.requirementStatus} />
            <DataField label="Target Verification Environment" value={selectedRecord.targetEnvironment} />
            <DataField label="Lead QA Systems Engineer" value={selectedRecord.assignedQAEngineer} />
            <DataField label="Pipeline Blocking Strategy Code" value={selectedRecord.targetWindow} />
            <DataField label="Execution Sequence Position Priority" value={selectedRecord.executionOrder} />
            <DataField label="Mapped Parent User Story ID" value={selectedRecord.associatedUserStoryId} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Requirement Functional Core Description" value={selectedRecord.requirementDescription} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Runtime Schemes & Environment Matrix</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Target Security RBAC Roles Evaluated" value={selectedRecord.rbacRolesTargeted} />
            <DataField label="Interlocked Structural Feature Flags Under Test" value={selectedRecord.featureFlagsTargeted} />
            <DataField label="Hardware Device Form Breakpoint Constraints" value={selectedRecord.responsiveVisibility} />
            <DataField label="Target Script Automation Suite Core Path" value={selectedRecord.automationScriptPath} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Expected Outcome Telemetry Validation Pattern" value={selectedRecord.expectedOutcomePattern} />
            <DataField label="Default Input Mock Dataset JSON Setup Matrix" value={selectedRecord.inputDatasetMockup} />
            <DataField label="Static Hardware Cluster Core Node Location Context" value={selectedRecord.hardwareDeviceConstraints} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Validation Criteria & SLA Constraints</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Continuous Integration Regression Active Flag" value={selectedRecord.isRegressionTest} />
            <DataField label="Requires Manual Engineering Validation Action" value={selectedRecord.requiresManualVerification} />
            <DataField label="Requires Third Party Compliance Auditing Sign-Off" value={selectedRecord.requiresThirdPartySignOff} />
            <DataField label="Execution Speed SLA Boundary Threshold Limit" value={selectedRecord.slaThresholdMs} />
            <DataField label="SLA Severity Visual Color Alert Accent Hex" value={selectedRecord.slaSeverityColor} />
            <DataField label="Atlassian Jira Issue Operational Key Identity" value={selectedRecord.jiraIssueKey} />
            <DataField label="Telemetry Engine Pipeline Analytics Tracking Event Key" value={selectedRecord.analyticsTrackingKey} />
            <DataField label="Supporting Asset / SRS Blueprint Log" value={selectedRecord.supportingDocumentsName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Architecture Engineering Mock Design Assumptions" value={selectedRecord.assumptions} />
            <DataField label="Testing Infrastructure Hard Boundary System Constraints" value={selectedRecord.constraints} />
            <DataField label="Quality Control Pipeline Optimization Engineering Notes" value={selectedRecord.designNotes} />
          </div>
        </div>
      )}
    </div>
  );
}