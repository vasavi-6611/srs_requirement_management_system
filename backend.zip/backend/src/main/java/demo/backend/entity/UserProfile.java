package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_profile")
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "active_user")
    private Boolean activeUser = true;

    @Column(name = "user_class_id")
    private String userClassId;

    @Column(name = "user_class_name")
    private String userClassName;

    @Column(name = "user_category")
    private String userCategory;

    @Column(name = "technical_expertise_level")
    private String technicalExpertiseLevel;

    @Column(name = "domain_knowledge_level")
    private String domainKnowledgeLevel;

    @Column(name = "experience_level")
    private String experienceLevel;

    @Column(name = "education_level")
    private String educationLevel;

    @Column(name = "computer_proficiency")
    private String computerProficiency;

    @Column(name = "preferred_language")
    private String preferredLanguage;

    @Column(name = "user_description", length = 2000)
    private String userDescription;

    @Column(name = "primary_responsibilities", length = 2000)
    private String primaryResponsibilities;

    @Column(name = "secondary_responsibilities", length = 2000)
    private String secondaryResponsibilities;

    @Column(name = "business_goals", length = 2000)
    private String businessGoals;

    @Column(name = "expected_outcomes", length = 2000)
    private String expectedOutcomes;

    @Column(name = "key_activities_performed", length = 2000)
    private String keyActivitiesPerformed;

    @Column(name = "usage_frequency")
    private String usageFrequency;

    @Column(name = "usage_duration_per_day")
    private String usageDurationPerDay;

    @Column(name = "expected_number_of_users")
    private String expectedNumberOfUsers;

    @Column(name = "concurrent_users_expected")
    private String concurrentUsersExpected;

    @Column(name = "peak_usage_time")
    private String peakUsageTime;

    @Column(name = "mobile_access_required")
    private boolean mobileAccessRequired;

    @Column(name = "remote_access_required")
    private boolean remoteAccessRequired;

    @Column(name = "internet_dependency")
    private String internetDependency;

    @Column(name = "accessibility_requirements", length = 1000)
    private String accessibilityRequirements;

    @Column(name = "training_required")
    private boolean trainingRequired;

    @Column(name = "help_documentation_required")
    private boolean helpDocumentationRequired;

    @Column(name = "security_clearance_level")
    private String securityClearanceLevel;

    @Column(name = "data_access_level")
    private String dataAccessLevel;

    @Column(name = "user_constraints", length = 2000)
    private String userConstraints;

    @Column(name = "assumptions_about_users", length = 2000)
    private String assumptionsAboutUsers;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(Boolean activeUser) {
        this.activeUser = activeUser;
    }

    public String getUserClassId() {
        return userClassId;
    }

    public void setUserClassId(String userClassId) {
        this.userClassId = userClassId;
    }

    public String getUserClassName() {
        return userClassName;
    }

    public void setUserClassName(String userClassName) {
        this.userClassName = userClassName;
    }

    public String getUserCategory() {
        return userCategory;
    }

    public void setUserCategory(String userCategory) {
        this.userCategory = userCategory;
    }

    public String getTechnicalExpertiseLevel() {
        return technicalExpertiseLevel;
    }

    public void setTechnicalExpertiseLevel(String technicalExpertiseLevel) {
        this.technicalExpertiseLevel = technicalExpertiseLevel;
    }

    public String getDomainKnowledgeLevel() {
        return domainKnowledgeLevel;
    }

    public void setDomainKnowledgeLevel(String domainKnowledgeLevel) {
        this.domainKnowledgeLevel = domainKnowledgeLevel;
    }

    public String getExperienceLevel() {
        return experienceLevel;
    }

    public void setExperienceLevel(String experienceLevel) {
        this.experienceLevel = experienceLevel;
    }

    public String getEducationLevel() {
        return educationLevel;
    }

    public void setEducationLevel(String educationLevel) {
        this.educationLevel = educationLevel;
    }

    public String getComputerProficiency() {
        return computerProficiency;
    }

    public void setComputerProficiency(String computerProficiency) {
        this.computerProficiency = computerProficiency;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public String getUserDescription() {
        return userDescription;
    }

    public void setUserDescription(String userDescription) {
        this.userDescription = userDescription;
    }

    public String getPrimaryResponsibilities() {
        return primaryResponsibilities;
    }

    public void setPrimaryResponsibilities(String primaryResponsibilities) {
        this.primaryResponsibilities = primaryResponsibilities;
    }

    public String getSecondaryResponsibilities() {
        return secondaryResponsibilities;
    }

    public void setSecondaryResponsibilities(String secondaryResponsibilities) {
        this.secondaryResponsibilities = secondaryResponsibilities;
    }

    public String getBusinessGoals() {
        return businessGoals;
    }

    public void setBusinessGoals(String businessGoals) {
        this.businessGoals = businessGoals;
    }

    public String getExpectedOutcomes() {
        return expectedOutcomes;
    }

    public void setExpectedOutcomes(String expectedOutcomes) {
        this.expectedOutcomes = expectedOutcomes;
    }

    public String getKeyActivitiesPerformed() {
        return keyActivitiesPerformed;
    }

    public void setKeyActivitiesPerformed(String keyActivitiesPerformed) {
        this.keyActivitiesPerformed = keyActivitiesPerformed;
    }

    public String getUsageFrequency() {
        return usageFrequency;
    }

    public void setUsageFrequency(String usageFrequency) {
        this.usageFrequency = usageFrequency;
    }

    public String getUsageDurationPerDay() {
        return usageDurationPerDay;
    }

    public void setUsageDurationPerDay(String usageDurationPerDay) {
        this.usageDurationPerDay = usageDurationPerDay;
    }

    public String getExpectedNumberOfUsers() {
        return expectedNumberOfUsers;
    }

    public void setExpectedNumberOfUsers(String expectedNumberOfUsers) {
        this.expectedNumberOfUsers = expectedNumberOfUsers;
    }

    public String getConcurrentUsersExpected() {
        return concurrentUsersExpected;
    }

    public void setConcurrentUsersExpected(String concurrentUsersExpected) {
        this.concurrentUsersExpected = concurrentUsersExpected;
    }

    public String getPeakUsageTime() {
        return peakUsageTime;
    }

    public void setPeakUsageTime(String peakUsageTime) {
        this.peakUsageTime = peakUsageTime;
    }

    public boolean isMobileAccessRequired() {
        return mobileAccessRequired;
    }

    public void setMobileAccessRequired(boolean mobileAccessRequired) {
        this.mobileAccessRequired = mobileAccessRequired;
    }

    public boolean isRemoteAccessRequired() {
        return remoteAccessRequired;
    }

    public void setRemoteAccessRequired(boolean remoteAccessRequired) {
        this.remoteAccessRequired = remoteAccessRequired;
    }

    public String getInternetDependency() {
        return internetDependency;
    }

    public void setInternetDependency(String internetDependency) {
        this.internetDependency = internetDependency;
    }

    public String getAccessibilityRequirements() {
        return accessibilityRequirements;
    }

    public void setAccessibilityRequirements(String accessibilityRequirements) {
        this.accessibilityRequirements = accessibilityRequirements;
    }

    public boolean isTrainingRequired() {
        return trainingRequired;
    }

    public void setTrainingRequired(boolean trainingRequired) {
        this.trainingRequired = trainingRequired;
    }

    public boolean isHelpDocumentationRequired() {
        return helpDocumentationRequired;
    }

    public void setHelpDocumentationRequired(boolean helpDocumentationRequired) {
        this.helpDocumentationRequired = helpDocumentationRequired;
    }

    public String getSecurityClearanceLevel() {
        return securityClearanceLevel;
    }

    public void setSecurityClearanceLevel(String securityClearanceLevel) {
        this.securityClearanceLevel = securityClearanceLevel;
    }

    public String getDataAccessLevel() {
        return dataAccessLevel;
    }

    public void setDataAccessLevel(String dataAccessLevel) {
        this.dataAccessLevel = dataAccessLevel;
    }

    public String getUserConstraints() {
        return userConstraints;
    }

    public void setUserConstraints(String userConstraints) {
        this.userConstraints = userConstraints;
    }

    public String getAssumptionsAboutUsers() {
        return assumptionsAboutUsers;
    }

    public void setAssumptionsAboutUsers(String assumptionsAboutUsers) {
        this.assumptionsAboutUsers = assumptionsAboutUsers;
    }
}