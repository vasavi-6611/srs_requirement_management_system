package demo.backend;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = {
    "http://localhost:5173",
    "http://localhost:5174"
})
public class StatusController {

    @GetMapping("/api/status")
    public ResponseEntity<Map<String, String>> getStatus() {

        Map<String, String> response = new HashMap<>();

        response.put("status", "SUCCESS");
        response.put("message", "Spring Boot running perfectly via Terminal!");

        return ResponseEntity.ok(response);
    }
}