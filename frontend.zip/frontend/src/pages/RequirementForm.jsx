import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomSelect from "../components/CustomSelect";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function RequirementForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [requirementsList, setRequirementsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRequirement, setSelectedRequirement] = useState(null);

  const emptyForm = {
    id: null,
    requirementId: "", requirementName: "", requirementTitle: "", requirementDescription: "",
    requirementCategory: "", requirementType: "", requirementSource: null, stakeholderName: null,
    userClass: null, businessObjective: "", businessValue: "", problemStatement: "",
    requirementRationale: "", expectedBenefit: "", priority: "", riskLevel: "",
    complexityLevel: "", status: "", preconditions: "", postconditions: "",
    triggerEvent: "", inputData: "", outputData: "", processingRules: "",
    dependencies: "", assumptions: "", constraints: "", acceptanceCriteria: "",
    verificationMethod: "", additionalNotes: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchRequirements();
  }, []);

  const fetchRequirements = async () => {
    try {
      const response = await api.get("/api/requirements");
      if (response.data) {
        setRequirementsList(response.data);
      }
    } catch (error) {
      console.error("Error fetching Requirements:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (requirement) => {
    setFormData(requirement);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (requirement) => {
    setSelectedRequirement(requirement);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing && formData.id) {
        await api.put(`/api/requirements/${formData.id}`, formData);
        alert("Requirement Updated Successfully!");
      } else {
        await api.post("/api/requirements", formData);
        alert("Requirement Saved Successfully!");
      }
      await fetchRequirements();
      setViewMode("LIST");
    } catch (error) {
      console.error("Error submitting requirement:", error);
      alert("Failed to save Requirement.");
    }
  };

  const handleDeleteClick = async (dbId) => {
    if (!dbId) {
      alert("Error: Missing primary ID.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this requirement?")) {
      try {
        await api.delete(`/api/requirements/${dbId}`);
        alert("Requirement Deleted Successfully!");
        fetchRequirements();
      } catch (error) {
        console.error("Delete error:", error);
        alert("Failed to delete record.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>{value ? String(value) : "—"}</span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = ["1. Core ID & Context", "2. Business Case & Metrics", "3. Behavioral Specs & Verification"];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45 }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>

      {/* 1. LIST VIEW */}
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>Functional Requirements</h2>
            <CustomButton text="+ Add New Requirement" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Requirement ID</th>
                <th style={{ padding: "14px" }}>Requirement Title</th>
                <th style={{ padding: "14px" }}>Category</th>
                <th style={{ padding: "14px" }}>Priority</th>
                <th style={{ padding: "14px" }}>Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {requirementsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active functional requirements found.</td>
                </tr>
              ) : (
                requirementsList.map((req) => (
                  <tr key={req.id} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0f172a" }}>{req.requirementId || req.id}</td>
                    <td style={{ padding: "14px" }}>{req.requirementTitle || req.requirementName}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#e0f2fe", color: "#0369a1", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{req.requirementCategory || "N/A"}</span></td>
                    <td style={{ padding: "14px" }}>{req.priority || "—"}</td>
                    <td style={{ padding: "14px" }}>{req.status || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(req)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>👁️ View</button>
                        <button onClick={() => handleEditClick(req)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(req.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* 2. FORM WIZARD VIEW */}
      {viewMode === "FORM" && (
        <div className="form-container requirement-def-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>
              {isEditing ? `Modify Requirement [${formData.requirementId || formData.id}]` : "Functional Requirements Specifications Capture"}
            </h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="Requirement ID" fullWidth={true} value={formData.requirementId || ""} onChange={(e) => handleChange("requirementId", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Requirement Name" fullWidth={true} value={formData.requirementName || ""} onChange={(e) => handleChange("requirementName", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Requirement Title" fullWidth={true} value={formData.requirementTitle || ""} onChange={(e) => handleChange("requirementTitle", e.target.value)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Requirement Category" value={formData.requirementCategory || ""} onChange={(e) => handleChange("requirementCategory", e.target.value)}
                    options={[
                      { label: "Core Functional Feature", value: "FUNCTIONAL" },
                      { label: "Data Quality Control Mapping", value: "DATA_QUALITY" },
                      { label: "Reporting & Dashboard Analytics", value: "REPORTING" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Requirement Type" value={formData.requirementType || ""} onChange={(e) => handleChange("requirementType", e.target.value)}
                    options={[
                      { label: "User Action Request Use-case", value: "USER_TYPE" },
                      { label: "System Automated Cron Task", value: "SYSTEM_TYPE" },
                      { label: "External Core Hook Interface", value: "INTERFACE_TYPE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Requirement Source" width="100%" value={formData.requirementSource || ""} onChange={(newValue) => handleChange("requirementSource", newValue)}
                    options={["IEEE Technical Baseline Document", "Stakeholder Interview Session", "Legacy Product Architecture Reengineering"]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Stakeholder Name" width="100%" value={formData.stakeholderName || ""} onChange={(newValue) => handleChange("stakeholderName", newValue)}
                    options={["Product Sponsor Group", "Lead System Developer", "Operations Domain Expert"]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="User Class" width="100%" value={formData.userClass || ""} onChange={(newValue) => handleChange("userClass", newValue)}
                    options={["System Administrator", "Standard Business User", "External Auditing Executive"]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Requirement Description" value={formData.requirementDescription || ""} onChange={(e) => handleChange("requirementDescription", e.target.value)} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Priority" value={formData.priority || ""} onChange={(e) => handleChange("priority", e.target.value)}
                    options={[
                      { label: "High / Critical Pipeline", value: "HIGH" },
                      { label: "Medium / Balanced Deployment", value: "MEDIUM" },
                      { label: "Low / Iterative Product Backlog", value: "LOW" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Risk Level" value={formData.riskLevel || ""} onChange={(e) => handleChange("riskLevel", e.target.value)}
                    options={[
                      { label: "High Technical Implementation Risk", value: "HIGH" },
                      { label: "Medium Managed Impact Risk", value: "MEDIUM" },
                      { label: "Low Minimal Risk", value: "LOW" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Complexity Level" value={formData.complexityLevel || ""} onChange={(e) => handleChange("complexityLevel", e.target.value)}
                    options={[
                      { label: "High Effort (5-Star)", value: "5" },
                      { label: "Medium Effort (3-Star)", value: "3" },
                      { label: "Low Effort (1-Star)", value: "1" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Status" value={formData.status || ""} onChange={(e) => handleChange("status", e.target.value)}
                    options={[
                      { label: "Draft Specifications Mode", value: "DRAFT" },
                      { label: "Under Active Design Verification", value: "IN_REVIEW" },
                      { label: "Approved for Engineering Sprint", value: "APPROVED" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Business Objective" value={formData.businessObjective || ""} onChange={(e) => handleChange("businessObjective", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Business Value" value={formData.businessValue || ""} onChange={(e) => handleChange("businessValue", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Problem Statement" value={formData.problemStatement || ""} onChange={(e) => handleChange("problemStatement", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Requirement Rationale" value={formData.requirementRationale || ""} onChange={(e) => handleChange("requirementRationale", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Expected Benefit" value={formData.expectedBenefit || ""} onChange={(e) => handleChange("expectedBenefit", e.target.value)} /></div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={fullWidthItem}><CustomTextField label="Trigger Event" fullWidth={true} value={formData.triggerEvent || ""} onChange={(e) => handleChange("triggerEvent", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Preconditions" value={formData.preconditions || ""} onChange={(e) => handleChange("preconditions", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Postconditions" value={formData.postconditions || ""} onChange={(e) => handleChange("postconditions", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Input Data Specifications" value={formData.inputData || ""} onChange={(e) => handleChange("inputData", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Output Data Elements Schema" value={formData.outputData || ""} onChange={(e) => handleChange("outputData", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Processing Rules" value={formData.processingRules || ""} onChange={(e) => handleChange("processingRules", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Dependencies" value={formData.dependencies || ""} onChange={(e) => handleChange("dependencies", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Assumptions" value={formData.assumptions || ""} onChange={(e) => handleChange("assumptions", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Constraints" value={formData.constraints || ""} onChange={(e) => handleChange("constraints", e.target.value)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Verification Method" value={formData.verificationMethod || ""} onChange={(e) => handleChange("verificationMethod", e.target.value)}
                    options={[
                      { label: "Automated Testing", value: "TESTING" },
                      { label: "Formal Code Review", value: "INSPECTION" },
                      { label: "User Demo Walkthrough", value: "DEMONSTRATION" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Acceptance Criteria" value={formData.acceptanceCriteria || ""} onChange={(e) => handleChange("acceptanceCriteria", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Additional Notes" value={formData.additionalNotes || ""} onChange={(e) => handleChange("additionalNotes", e.target.value)} /></div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Requirement" : "Submit Requirement"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {/* 3. DETAILS READ-ONLY VIEW */}
      {viewMode === "VIEW_DETAILS" && selectedRequirement && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Requirement Specification Details</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Target ID: {selectedRequirement.requirementId}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Core Identification & Context</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="Requirement ID" value={selectedRequirement.requirementId} />
            <DataField label="Requirement Name" value={selectedRequirement.requirementName} />
            <DataField label="Requirement Title" value={selectedRequirement.requirementTitle} />
            <DataField label="Requirement Category" value={selectedRequirement.requirementCategory} />
            <DataField label="Requirement Type" value={selectedRequirement.requirementType} />
            <DataField label="Requirement Source" value={selectedRequirement.requirementSource} />
            <DataField label="Stakeholder Name" value={selectedRequirement.stakeholderName} />
            <DataField label="User Class" value={selectedRequirement.userClass} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Requirement Description" value={selectedRequirement.requirementDescription} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Business Case & Metrics</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Priority Tier" value={selectedRequirement.priority} />
            <DataField label="Risk Level" value={selectedRequirement.riskLevel} />
            <DataField label="Complexity Scale" value={selectedRequirement.complexityLevel} />
            <DataField label="Status" value={selectedRequirement.status} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Business Objective" value={selectedRequirement.businessObjective} />
            <DataField label="Business Value" value={selectedRequirement.businessValue} />
            <DataField label="Problem Statement" value={selectedRequirement.problemStatement} />
            <DataField label="Requirement Rationale" value={selectedRequirement.requirementRationale} />
            <DataField label="Expected Benefit" value={selectedRequirement.expectedBenefit} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Behavioral Specs & Verification</h4>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "20px" }}>
            <DataField label="Trigger Event" value={selectedRequirement.triggerEvent} />
            <DataField label="Preconditions" value={selectedRequirement.preconditions} />
            <DataField label="Postconditions" value={selectedRequirement.postconditions} />
            <DataField label="Input Data" value={selectedRequirement.inputData} />
            <DataField label="Output Data" value={selectedRequirement.outputData} />
            <DataField label="Processing Rules" value={selectedRequirement.processingRules} />
            <DataField label="Dependencies" value={selectedRequirement.dependencies} />
            <DataField label="Assumptions" value={selectedRequirement.assumptions} />
            <DataField label="Constraints" value={selectedRequirement.constraints} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "16px" }}>
            <DataField label="Verification Method" value={selectedRequirement.verificationMethod} />
            <DataField label="Acceptance Criteria" value={selectedRequirement.acceptanceCriteria} />
            <DataField label="Additional Notes" value={selectedRequirement.additionalNotes} />
          </div>
        </div>
      )}

    </div>
  );
}