import React from "react";
import ImageList from "@mui/material/ImageList";
import ImageListItem from "@mui/material/ImageListItem";

export default function CustomImageList({
  items = [],
  width = 500,
  height = 450,
  cols = 3,
  rowHeight = 164,
}) {
  return (
    <ImageList
      sx={{ width, height }}
      cols={cols}
      rowHeight={rowHeight}
    >
      {items.map((item, index) => (
        <ImageListItem key={index}>
          <img
            src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
            srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
            alt={item.title}
            loading="lazy"
          />
        </ImageListItem>
      ))}
    </ImageList>
  );
}