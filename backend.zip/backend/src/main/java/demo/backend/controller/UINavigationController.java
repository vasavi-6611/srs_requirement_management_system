package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.UINavigation;
import demo.backend.repository.UINavigationRepository;

@RestController
@RequestMapping("/api/ui-navigation")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class UINavigationController {

    @Autowired
    private UINavigationRepository repository;

    @GetMapping({"", "/"})
    public List<UINavigation> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<UINavigation> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<UINavigation> saveRecord(@RequestBody UINavigation record) {
        UINavigation saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UINavigation> updateRecord(@PathVariable Long id, @RequestBody UINavigation details) {
        return repository.findById(id).map(record -> {
            record.setNavigationId(details.getNavigationId());
            record.setNavigationName(details.getNavigationName());
            record.setNavigationPath(details.getNavigationPath());
            record.setNavigationCategory(details.getNavigationCategory());
            record.setNavigationType(details.getNavigationType());
            record.setNavigationStatus(details.getNavigationStatus());
            record.setNavigationDescription(details.getNavigationDescription());
            record.setNavigationLabel(details.getNavigationLabel());
            record.setIconClass(details.getIconClass());
            record.setTargetWindow(details.getTargetWindow());
            record.setDisplayOrder(details.getDisplayOrder());
            record.setParentNavigationId(details.getParentNavigationId());
            record.setRbacRolesAllowed(details.getRbacRolesAllowed());
            record.setFeatureFlagsRequired(details.getFeatureFlagsRequired());
            record.setResponsiveVisibility(details.getResponsiveVisibility());
            record.setRelatedRouteComponent(details.getRelatedRouteComponent());
            record.setUrlParameters(details.getUrlParameters());
            record.setQueryParameters(details.getQueryParameters());
            record.setBreadCrumbLabel(details.getBreadCrumbLabel());
            record.setAnalyticsEventName(details.getAnalyticsEventName());
            record.setIsExternalLink(details.getIsExternalLink());
            record.setRequiresAuthentication(details.getRequiresAuthentication());
            record.setRequiresSubscription(details.getRequiresSubscription());
            record.setBadgeText(details.getBadgeText());
            record.setBadgeColor(details.getBadgeColor());
            record.setLocalizationKey(details.getLocalizationKey());
            record.setAssumptions(details.getAssumptions());
            record.setConstraints(details.getConstraints());
            record.setDesignNotes(details.getDesignNotes());
            record.setSupportingDocumentsName(details.getSupportingDocumentsName());

            UINavigation updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}