import TextField from "@mui/material/TextField";

export default function CustomNumberField({
  label,
  value,
  onChange,
  min,
  max,
  size = "medium",
  error = false,
  helperText,
  defaultValue,
  disabled = false,
  fullWidth = false,
}) {
  return (
    <TextField
      type="number"
      label={label}
      value={value}
      onChange={onChange}
      defaultValue={defaultValue}
      size={size}
      error={error}
      helperText={helperText}
      disabled={disabled}
      fullWidth={fullWidth}
      inputprops={{
        min,
        max,
      }}
    />
  );
}

// import TextField from "@mui/material/TextField";

// export default function CustomNumberField({
//   label,
//   value,
//   onChange,
//   min,
//   max,
//   size = "medium",
//   error = false,
//   helperText,
//   defaultValue,
//   disabled = false,
//   fullWidth = false,
//   ...rest
// }) {
//   return (
//     <TextField
//       type="number"
//       label={label}
//       value={value}
//       onChange={onChange}
//       defaultValue={defaultValue}
//       size={size}
//       error={error}
//       helperText={helperText}
//       disabled={disabled}
//       fullWidth={fullWidth}
  
//       slotProps={{
//         htmlInput: {
//           min: min !== undefined ? min : undefined,
//           max: max !== undefined ? max : undefined,
//         }
//       }}
//     />
//   );
// }