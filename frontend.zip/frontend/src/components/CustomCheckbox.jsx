import React from "react";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";

export default function CustomCheckbox({
  label,
  checked,
  onChange,
  disabled = false,
  defaultChecked = false,
  color = "primary",
}) {
  return (
    <FormControlLabel
      control={
        <Checkbox
          checked={checked}
          onChange={onChange}
          disabled={disabled}
          defaultChecked={defaultChecked}
          color={color}
        />
      }
      label={label}
    />
  );
}