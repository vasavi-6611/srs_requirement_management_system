import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomTextarea from "../components/CustomTextarea";

export default function InterfacesAndConstraintsForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    userInterfaceStandards: "",
    supportedScreenResolutions: "",
    accessibilityRequirements: false,
    supportedLanguages: "",
    hardwareRequirements: "",
    deviceCompatibility: false,
    peripheralDeviceSupport: false,
    operatingSystemRequirements: false,
    browserCompatibility: false,
    externalSoftwareDependencies: "",
    middlewareRequirements: "",
    networkRequirements: "",
    communicationProtocol: "",
    bandwidthRequirements: "",
    apiAuthenticationMethod: "",
    regulatoryConstraints: "",
    legalConstraints: "",
    securityConstraints: "",
    performanceConstraints: "",
    technologyConstraints: "",
    businessAssumptions: "",
    technicalAssumptions: "",
    externalDependencies: "",
    vendorDependencies: "",
    referenceDocumentsName: "",
    complianceStandards: "",
    supportingArtifactsName: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/interfaces-constraints");
      setRecordsList(response.data || []);
    } catch (error) {
      console.error("Error fetching interfaces and constraints registry:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, event) => {
    const file = event.target.files?.[0];
    if (file) {
      handleChange(field, file.name);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      console.log("Sending Interfaces and Constraints Payload:", formData);
      if (isEditing) {
        await api.put(`/api/interfaces-constraints/${formData.id}`, formData);
        alert("Interfaces and Constraints Setup Updated Successfully!");
      } else {
        await api.post("/api/interfaces-constraints", formData);
        alert("Interface and constraints Saved Successfully!");
      }
      fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this config registration mapping?")) {
      try {
        await api.delete(`/api/interfaces-constraints/${id}`);
        alert("Entry Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. UI & System Requirements",
      "2. Integration & Constraints",
      "3. Dependencies & Artifacts",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Interfaces and Constraints
            </h2>
            <CustomButton text="+ Define New System Setup" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#1c78d3", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Configuration ID</th>
                <th style={{ padding: "14px" }}>UI Standards Framework</th>
                <th style={{ padding: "14px" }}>Screen Resolution Type</th>
                <th style={{ padding: "14px" }}>Primary Protocol Style</th>
                <th style={{ padding: "14px" }}>Compliance Architecture</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active interface schema profiles configured. Create an entry map configuration instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>CFG-{record.id || index + 1}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.userInterfaceStandards || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{record.supportedScreenResolutions || "—"}</span></td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.communicationProtocol || "—"}</span></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.complianceStandards || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Blueprint</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container interfaces-constraints-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Interfaces and Constraints Definition</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="User Interface Standards" value={formData.userInterfaceStandards} onChange={(e) => handleChange("userInterfaceStandards", e.target.value)}
                    options={[
                      { label: "Material Design Framework Guidelines", value: "MATERIAL_DESIGN" },
                      { label: "IEEE Standard 1003.1 UI Interfaces Compliance", value: "IEEE_UI" },
                      { label: "Sovereign Web Core Access standards", value: "GOV_WEB_STANDARDS" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Supported Screen Resolutions" value={formData.supportedScreenResolutions} onChange={(e) => handleChange("supportedScreenResolutions", e.target.value)}
                    options={[
                      { label: "Responsive Desktop Full HD (1920x1080 Baseline)", value: "FHD_1080P" },
                      { label: "Adaptive Standard Layout Grid (1366x768 Tier)", value: "HD_768P" },
                      { label: "Mobile Adaptive Scale Viewport Matrix", value: "MOBILE_VIEW" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Supported Languages" width="100%" value={formData.supportedLanguages} onChange={(newValue) => handleChange("supportedLanguages", newValue)} options={["English Base UI Engine", "Multi-lingual Package (EN, TE, HI)"]} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Enforce Accessibility Requirements Compliance (WCAG 2.1 AA Standards)" checked={formData.accessibilityRequirements} onChange={(e) => handleChange("accessibilityRequirements", e.target.checked)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Hardware Requirements" value={formData.hardwareRequirements} onChange={(e) => handleChange("hardwareRequirements", e.target.value)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Verify Multi-Device Compatibility Layers" checked={formData.deviceCompatibility} onChange={(e) => handleChange("deviceCompatibility", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Enable External Peripheral Device Support Infrastructure" checked={formData.peripheralDeviceSupport} onChange={(e) => handleChange("peripheralDeviceSupport", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Operating System Requirements Validation Check" checked={formData.operatingSystemRequirements} onChange={(e) => handleChange("operatingSystemRequirements", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox label="Cross-Browser Compatibility Verification Enforced" checked={formData.browserCompatibility} onChange={(e) => handleChange("browserCompatibility", e.target.checked)} />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={fullWidthItem}>
                  <CustomTextarea label="External Software Dependencies" value={formData.externalSoftwareDependencies} onChange={(e) => handleChange("externalSoftwareDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Middleware Requirements" value={formData.middlewareRequirements} onChange={(e) => handleChange("middlewareRequirements", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomRadioGroup label="Primary Communication Protocol Style" row={true} value={formData.communicationProtocol} onChange={(e) => handleChange("communicationProtocol", e.target.value)}
                    options={[
                      { label: "REST Endpoints Over HTTPS", value: "REST_HTTP" },
                      { label: "gRPC High-Performance Async Pipeline", value: "GRPC_PROTOCOL" },
                      { label: "GraphQL Federated Data Endpoint Layer", value: "GRAPHQL_ENGINE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Minimum Bandwidth Requirements Allocation (Mbps Target)" fullWidth={true} min={1} value={formData.bandwidthRequirements} onChange={(e) => handleChange("bandwidthRequirements", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="API Authentication Method Secure Mode" value={formData.apiAuthenticationMethod} onChange={(e) => handleChange("apiAuthenticationMethod", e.target.value)}
                    options={[
                      { label: "OAuth2 Bearer Token Delegation Framework", value: "OAUTH2" },
                      { label: "Stateless JWT Authentication Tokens", value: "JWT_SEC" },
                      { label: "Secure API Key String Headers Injection", value: "API_KEY" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Network Requirements Specification Details" value={formData.networkRequirements} onChange={(e) => handleChange("networkRequirements", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Regulatory Constraints" value={formData.regulatoryConstraints} onChange={(e) => handleChange("regulatoryConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Legal Constraints" value={formData.legalConstraints} onChange={(e) => handleChange("legalConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Security Constraints" value={formData.securityConstraints} onChange={(e) => handleChange("securityConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Performance Constraints" value={formData.performanceConstraints} onChange={(e) => handleChange("performanceConstraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Technology Constraints" value={formData.technologyConstraints} onChange={(e) => handleChange("technologyConstraints", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Business Assumptions" value={formData.businessAssumptions} onChange={(e) => handleChange("businessAssumptions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Technical Assumptions" value={formData.technicalAssumptions} onChange={(e) => handleChange("technicalAssumptions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="External Dependencies" value={formData.externalDependencies} onChange={(e) => handleChange("externalDependencies", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Vendor Dependencies" value={formData.vendorDependencies} onChange={(e) => handleChange("vendorDependencies", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Compliance Standards Architecture" value={formData.complianceStandards} onChange={(e) => handleChange("complianceStandards", e.target.value)}
                    options={[
                      { label: "ISO/IEC 27001 Security Audit Metrics", value: "ISO_27001" },
                      { label: "IEEE 830 Standard Architecture Software Specifications", value: "IEEE_SRS" },
                      { label: "IEEE 802.11ah Wireless Sub-GHz Profile Rules", value: "IEEE_802_11AH" },
                    ]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Reference Documents Attachment:</label>
                  <CustomFileUpload buttonText="Upload Reference Document" fileName={formData.referenceDocumentsName} onChange={(e) => handleFileChange("referenceDocumentsName", e)} accept=".pdf,.doc,.docx,.xlsx" />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Supporting Artifacts Specification File:</label>
                  <CustomFileUpload buttonText="Upload Supporting Artifact" fileName={formData.supportingArtifactsName} onChange={(e) => handleFileChange("supportingArtifactsName", e)} accept=".pdf,.doc,.docx,.xlsx,.png,.jpg" />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Configuration Profile Model" : "Commit Integrated Configuration Model"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Interfaces and Constraints Deep Blueprint Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Database Identity Entry Reference: ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. UI, Standards & System Requirements Check</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="User Interface Standards" value={selectedRecord.userInterfaceStandards} />
            <DataField label="Supported Screen Resolutions" value={selectedRecord.supportedScreenResolutions} />
            <DataField label="Supported Languages Setup" value={selectedRecord.supportedLanguages} />
            <DataField label="Accessibility Enforced (WCAG 2.1 AA)" value={selectedRecord.accessibilityRequirements} />
            <DataField label="Multi-Device Compatibility Layer" value={selectedRecord.deviceCompatibility} />
            <DataField label="External Peripheral Support" value={selectedRecord.peripheralDeviceSupport} />
            <DataField label="Operating System Validation Check" value={selectedRecord.operatingSystemRequirements} />
            <DataField label="Cross-Browser Compatibility Enforced" value={selectedRecord.browserCompatibility} />
          </div>
          <div style={{ marginBottom: "30px" }}>
            <DataField label="Hardware Requirements Summary" value={selectedRecord.hardwareRequirements} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Core Integration Parameters & System Constraints</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Primary Communication Protocol" value={selectedRecord.communicationProtocol} />
            <DataField label="Allocated Minimum Bandwidth (Mbps)" value={selectedRecord.bandwidthRequirements} />
            <DataField label="API Authentication Secure Mode" value={selectedRecord.apiAuthenticationMethod} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="External Software Dependencies Description" value={selectedRecord.externalSoftwareDependencies} />
            <DataField label="Middleware Architectural Requirements" value={selectedRecord.middlewareRequirements} />
            <DataField label="Network Requirements Specifications Details" value={selectedRecord.networkRequirements} />
            <DataField label="Regulatory Constraints Profile" value={selectedRecord.regulatoryConstraints} />
            <DataField label="Legal Constraints Scope" value={selectedRecord.legalConstraints} />
            <DataField label="Security Hard Constraints Matrix" value={selectedRecord.securityConstraints} />
            <DataField label="Performance Boundary Constraints" value={selectedRecord.performanceConstraints} />
            <DataField label="Technology Infrastructure Constraints" value={selectedRecord.technologyConstraints} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Business Dependencies & Document Artifacts</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Compliance Standards Architecture" value={selectedRecord.complianceStandards} />
            <DataField label="Attached Reference Document Asset" value={selectedRecord.referenceDocumentsName} />
            <DataField label="Supporting Artifacts Design Asset" value={selectedRecord.supportingArtifactsName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Business Layer Assumptions" value={selectedRecord.businessAssumptions} />
            <DataField label="Technical Design Assumptions" value={selectedRecord.technicalAssumptions} />
            <DataField label="System External Dependencies Topology" value={selectedRecord.externalDependencies} />
            <DataField label="Vendor Lock-in & Service Dependencies" value={selectedRecord.vendorDependencies} />
          </div>
        </div>
      )}
    </div>
  );
}