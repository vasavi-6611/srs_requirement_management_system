import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomTextarea from "../components/CustomTextarea";

export default function ManualVerificationForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    uatCriteria: "",
    manualTestingProcedures: "",
    defectSeverityMatrix: "",
    crossDeviceTestingMatrix: false,
    qaTeamSizeAllocated: 1,
    targetBrowsersList: "",
    mobileOsRequirements: "",
    regressionCycleFrequency: "PER_RELEASE",
    exploratoryTestingHours: 4,
    bugTrackingToolIntegration: "",
    accessibilityComplianceRequired: false,
    localizationTestingRequired: false,
    manualRegressionArtifactName: "",
    uatSignOffTemplateName: ""
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/testing/manual");
      const records = Array.isArray(response.data) ? response.data : response.data.content || [];
      setRecordsList(records);
    } catch (error) {
      console.error("Error fetching manual verification registry:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing) {
        await api.put(`/api/testing/manual/${formData.id}`, formData);
        alert("Manual Verification Specification Updated Successfully!");
      } else {
        await api.post("/api/testing/manual", formData);
        alert("Manual Verification Configuration Saved Successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Manual Verification Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this manual verification matrix specification configuration?")) {
      try {
        await api.delete(`/api/testing/manual/${id}`);
        alert("Manual Verification Template Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Manual Procedures & Scope",
      "2. Environment Matrix & Defect Tiers",
      "3. Compliance, Integrations & Deliverables",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              QA & Manual Verification
            </h2>
            <CustomButton text="+ Define New Verification Matrix" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Registry ID</th>
                <th style={{ padding: "14px" }}>Manual Testing Strategy Overview</th>
                <th style={{ padding: "14px" }}>QA Team Size</th>
                <th style={{ padding: "14px" }}>Cycle Frequency</th>
                <th style={{ padding: "14px" }}>Severity Setup</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No manual QA matrix workflows or verification specs configured. Initialize an entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>MVR-{record.id || index + 1}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155", maxWidth: "300px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{record.manualTestingProcedures || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px", fontWeight: "600" }}>{record.qaTeamSizeAllocated || "0"} QA Eng</span></td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.regressionCycleFrequency || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.defectSeverityMatrix || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container manual-verification-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>2. QA & Manual Verification Matrix Definition</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={fullWidthItem}>
                  <CustomTextarea
                    label="Exploratory & Manual Script Testing Run-through Procedures"
                    value={formData.manualTestingProcedures}
                    onChange={(e) => handleChange("manualTestingProcedures", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Allocated Manual QA Engineers (Team Size)"
                    fullWidth={true}
                    min={1}
                    max={50}
                    value={formData.qaTeamSizeAllocated}
                    onChange={(e) => handleChange("qaTeamSizeAllocated", e.target.value)}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField
                    label="Target Exploratory Timebox Focus (Hours per Sprint)"
                    fullWidth={true}
                    min={1}
                    max={160}
                    value={formData.exploratoryTestingHours}
                    onChange={(e) => handleChange("exploratoryTestingHours", e.target.value)}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea
                    label="User Acceptance Testing (UAT) Acceptance Sign-off Criteria"
                    value={formData.uatCriteria}
                    onChange={(e) => handleChange("uatCriteria", e.target.value)}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="Defect Severity Matrix Allocation Model"
                    value={formData.defectSeverityMatrix}
                    onChange={(e) => handleChange("defectSeverityMatrix", e.target.value)}
                    options={[
                      { label: "Standard Tier (Blocker, Critical, Major, Minor)", value: "STANDARD_SEV" },
                      { label: "Agile Priority Scheme (High, Medium, Low Impact Matrix)", value: "AGILE_PRIORITY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect
                    label="Manual Regression Cycle Execution Frequency"
                    value={formData.regressionCycleFrequency}
                    onChange={(e) => handleChange("regressionCycleFrequency", e.target.value)}
                    options={[
                      { label: "On Every Target Release Candidate Build", value: "PER_RELEASE" },
                      { label: "Bi-Weekly Scheduled Sprint Regression Plan", value: "BI_WEEKLY" },
                      { label: "Monthly Extended Feature Core Regression Run", value: "MONTHLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete
                    label="Target Core Desktop Browser Matrix Scope"
                    width="100%"
                    value={formData.targetBrowsersList}
                    onChange={(newValue) => handleChange("targetBrowsersList", newValue)}
                    options={["Google Chrome & Apple Safari Standards", "Chrome, Firefox, Safari, and Microsoft Edge Core Quad"]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete
                    label="Target Mobile Operating System Profiles"
                    width="100%"
                    value={formData.mobileOsRequirements}
                    onChange={(newValue) => handleChange("mobileOsRequirements", newValue)}
                    options={["Latest iOS and Android Stable Releases", "Legacy Mobile Form Factor Backward Compatibility Matrix"]}
                  />
                </div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", justifyContent: "center", marginTop: "10px" }}>
                  <CustomCheckbox
                    label="Enforce Real Cross-Device Cloud Hardware Testing Matrix"
                    checked={formData.crossDeviceTestingMatrix}
                    onChange={(e) => handleChange("crossDeviceTestingMatrix", e.target.checked)}
                  />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={fullWidthItem}>
                  <CustomRadioGroup
                    label="Primary Project Bug Management Ecosystem Link"
                    row={true}
                    value={formData.bugTrackingToolIntegration}
                    onChange={(e) => handleChange("bugTrackingToolIntegration", e.target.value)}
                    options={[
                      { label: "Atlassian Jira Enterprise Cloud Workspace", value: "JIRA" },
                      { label: "GitHub Enterprise Issues / Project Tracking board", value: "GITHUB_ISSUES" },
                    ]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox
                    label="Enforce WCAG 2.1 AA Screen Reader & Keyboard Accessibility Audit Checks"
                    checked={formData.accessibilityComplianceRequired}
                    onChange={(e) => handleChange("accessibilityComplianceRequired", e.target.checked)}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomCheckbox
                    label="Mandatory Multi-Region Localization / Internationalization UI Layout Validation"
                    checked={formData.localizationTestingRequired}
                    onChange={(e) => handleChange("localizationTestingRequired", e.target.checked)}
                  />
                </div>

                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center", marginTop: "10px" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Manual Regression Run Book & Scripts Script List:</label>
                  <CustomFileUpload
                    buttonText="UPLOAD ATTACHMENT SPEC FILE"
                    fileName={formData.manualRegressionArtifactName}
                    onChange={(e) => handleFileChange("manualRegressionArtifactName", e)}
                    accept=".pdf,.doc,.docx,.xlsx,.csv"
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center", marginTop: "10px" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>UAT Sign-off Form Signature Template:</label>
                  <CustomFileUpload
                    buttonText="Upload Template File"
                    fileName={formData.uatSignOffTemplateName}
                    onChange={(e) => handleFileChange("uatSignOffTemplateName", e)}
                    accept=".pdf,.doc,.docx"
                  />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Verification Specs" : "Save Verification Specs"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Manual & UAT Verification Blueprint Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Reference Track: MVR-SPEC-ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Manual Procedures & Scope</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Allocated Manual QA Team Size" value={selectedRecord.qaTeamSizeAllocated} />
            <DataField label="Target Exploratory Sprint Timebox (Hours)" value={selectedRecord.exploratoryTestingHours} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Manual Run-through Testing Procedures" value={selectedRecord.manualTestingProcedures} />
            <DataField label="User Acceptance Testing (UAT) Criteria" value={selectedRecord.uatCriteria} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Environment Matrix & Defect Tiers</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Defect Severity Allocation Model" value={selectedRecord.defectSeverityMatrix} />
            <DataField label="Manual Regression Execution Cycle Frequency" value={selectedRecord.regressionCycleFrequency} />
            <DataField label="Target Core Desktop Browser Matrix Scope" value={selectedRecord.targetBrowsersList} />
            <DataField label="Target Mobile Operating System Profiles" value={selectedRecord.mobileOsRequirements} />
            <DataField label="Enforce Cross-Device Cloud Hardware Testing" value={selectedRecord.crossDeviceTestingMatrix} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Compliance, Integrations & Deliverables</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Primary Project Bug Management Workspace" value={selectedRecord.bugTrackingToolIntegration} />
            <DataField label="WCAG 2.1 AA Accessibility Checks Enforced" value={selectedRecord.accessibilityComplianceRequired} />
            <DataField label="Mandatory Multi-Region UI Layout Validation" value={selectedRecord.localizationTestingRequired} />
            <DataField label="Manual Regression Run Book Attachment" value={selectedRecord.manualRegressionArtifactName} />
            <DataField label="UAT Sign-off Signature Template File" value={selectedRecord.uatSignOffTemplateName} />
          </div>
        </div>
      )}
    </div>
  );
}