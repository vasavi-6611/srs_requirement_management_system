package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.DatabaseClassDesign;
import demo.backend.repository.DatabaseClassDesignRepository;

@RestController
@RequestMapping("/api/db-class-designs")
@CrossOrigin(origins = {"*"})
public class DatabaseClassDesignController {

    @Autowired
    private DatabaseClassDesignRepository repository;

    @GetMapping({"", "/"})
    public List<DatabaseClassDesign> getAllDesigns() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DatabaseClassDesign> getDesignById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<DatabaseClassDesign> saveDesign(@RequestBody DatabaseClassDesign design) {
        DatabaseClassDesign saved = repository.save(design);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DatabaseClassDesign> updateDesign(@PathVariable Long id, @RequestBody DatabaseClassDesign details) {
        return repository.findById(id).map(design -> {
            design.setTableClassId(details.getTableClassId());
            design.setTableClassName(details.getTableClassName());
            design.setEntityType(details.getEntityType());
            design.setVersion(details.getVersion());
            design.setDescription(details.getDescription());
            design.setAttributesColumns(details.getAttributesColumns());
            design.setDataTypes(details.getDataTypes());
            design.setColumnConstraints(details.getColumnConstraints());
            design.setDefaultValues(details.getDefaultValues());
            design.setNullableFields(details.getNullableFields());
            design.setPrimaryKeyType(details.getPrimaryKeyType());
            design.setPrimaryKeyColumn(details.getPrimaryKeyColumn());
            design.setCompositeKeyDetails(details.getCompositeKeyDetails());
            
            // Fixed to use get...() for Boolean wrapper fields
            design.setHasForeignKey(details.getHasForeignKey());
            
            design.setForeignKeyDetails(details.getForeignKeyDetails());
            design.setReferencedTable(details.getReferencedTable());
            design.setReferencedColumn(details.getReferencedColumn());
            design.setRelationships(details.getRelationships());
            design.setRelationshipDescription(details.getRelationshipDescription());
            design.setCardinalityRules(details.getCardinalityRules());
            design.setEntityPurpose(details.getEntityPurpose());
            design.setBusinessRules(details.getBusinessRules());
            design.setValidationRules(details.getValidationRules());
            design.setDataIntegrityRules(details.getDataIntegrityRules());
            design.setMethods(details.getMethods());
            design.setMethodDescriptions(details.getMethodDescriptions());
            
            // Fixed to use get...() for Boolean wrapper fields
            design.setCrudSupported(details.getCrudSupported());
            
            design.setIndexingStrategy(details.getIndexingStrategy());
            design.setDatabaseSchemaName(details.getDatabaseSchemaName());
            design.setEstimatedRecordVolume(details.getEstimatedRecordVolume());
            design.setUniqueConstraints(details.getUniqueConstraints());
            design.setCheckConstraints(details.getCheckConstraints());
            design.setTablespaceStorageDetails(details.getTablespaceStorageDetails());
            design.setOrmFramework(details.getOrmFramework());
            design.setEntityMappingStrategy(details.getEntityMappingStrategy());
            design.setCascadeOperations(details.getCascadeOperations());
            
            // Fixed to use get...() for Boolean wrapper fields
            design.setAuditColumnsRequired(details.getAuditColumnsRequired());
            design.setSoftDeleteSupported(details.getSoftDeleteSupported());
            
            design.setSecurityRequirements(details.getSecurityRequirements());
            design.setDesignNotes(details.getDesignNotes());

            DatabaseClassDesign updated = repository.save(design);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDesign(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}