import React from "react";
import Rating from "@mui/material/Rating";
import Stack from "@mui/material/Stack";

export default function CustomRating({
  name,
  value,
  defaultValue,
  precision = 1,
  readOnly = false,
  onChange,
}) {
  return (
    <Stack spacing={1}>
      <Rating
        name={name}
        value={value}
        defaultValue={defaultValue}
        precision={precision}
        readOnly={readOnly}
        onChange={onChange}
      />
    </Stack>
  );
}