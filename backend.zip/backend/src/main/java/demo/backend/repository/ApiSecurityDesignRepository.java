package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.ApiSecurityDesign;

@Repository
public interface ApiSecurityDesignRepository 
        extends JpaRepository<ApiSecurityDesign, Long> {
}