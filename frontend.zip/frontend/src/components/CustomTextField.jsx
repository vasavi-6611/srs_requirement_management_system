import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

export default function CustomTextField({
  label,
  variant = "outlined",
  value,
  onChange,
  type = "text",
  size = "medium",
  fullWidth = false,
  disabled = false,
  error = false,
  helperText = "",
  multiline = false,
  rows,
  ...rest
}) {
  const [showPassword, setShowPassword] = useState(false);

  const handleClickShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  const getInputType = () => {
    if (type === "password") {
      return showPassword ? "text" : "password";
    }
    return type;
  };

  return (
    <TextField
      label={label}
      variant={variant}
      value={value}
      onChange={onChange}
      type={getInputType()}
      size={size}
      fullWidth={fullWidth}
      disabled={disabled}
      error={error}
      helperText={helperText}
      multiline={multiline}
      rows={rows}
       slotprops={
        type === "password"
          ? {
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }
          : undefined
      }
      {...rest}
    />
  );
}