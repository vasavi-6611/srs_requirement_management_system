import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function UINavigationForm() {
  // Navigation & View Controls Matrix
  const [viewMode, setViewMode] = useState("LIST"); // Supported Matrix Modes: "LIST", "FORM", "VIEW_DETAILS"
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  // Initial Form Baseline Structural State Matrix for UI Navigation Elements
  const emptyForm = {
    navigationId: "",
    navigationName: "",
    navigationPath: "",
    navigationCategory: "", // e.g., SIDEBAR, NAVBAR, FOOTER
    navigationType: "",     // e.g., LINK, DROPDOWN, GROUP_HEADER
    navigationStatus: "",   // e.g., ACTIVE, DEPRECATED, HIDDEN
    navigationDescription: "",
    navigationLabel: "",
    iconClass: "",
    targetWindow: "_self",  // e.g., _self, _blank
    displayOrder: "",
    parentNavigationId: "",
    rbacRolesAllowed: "",
    featureFlagsRequired: "",
    responsiveVisibility: "", // e.g., ALL_DEVICES, MOBILE_ONLY, DESKTOP_ONLY
    relatedRouteComponent: "",
    urlParameters: "",
    queryParameters: "",
    breadCrumbLabel: "",
    analyticsEventName: "",
    isExternalLink: false,
    requiresAuthentication: true,
    requiresSubscription: false,
    badgeText: "",
    badgeColor: "",
    localizationKey: "",
    assumptions: "",
    constraints: "",
    designNotes: "",
    supportingDocumentsName: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  // Fetch Existing UI Navigation Configurations Matrix on Mount
  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/ui-navigation");
      const records = Array.isArray(response.data) ? response.data : response.data.content || [];
      setRecordsList(records);
    } catch (error) {
      console.error("Error fetching UI navigation registry:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  // POST or PUT Async Network Submission Action Channel
  const handleSubmit = async () => {
    try {
      console.log("Sending UI Navigation Payload:", formData);
      if (isEditing) {
        await api.put(`/api/ui-navigation/${formData.id}`, formData);
        alert("UI Navigation Specification Updated Successfully!");
      } else {
        await api.post("/api/ui-navigation", formData);
        alert("UI Navigation Configuration Saved Successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save UI Navigation Data");
    }
  };

  // Delete Record Confirmation Action Routine
  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this UI navigation node configuration entry?")) {
      try {
        await api.delete(`/api/ui-navigation/${id}`);
        alert("Navigation Route Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  // Read-only Text Inspector Metric Component Wrapper
  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Route Profile & Hierarchies",
      "2. URL Schemes & Access Controls",
      "3. UX Presentation & Visual States",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>

      {/* ======================================= */}
      {/* 1. DASHBOARD REGISTRY OVERVIEW DISPLAY  */}
      {/* ======================================= */}
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              UI Navigation Design
            </h2>
            <CustomButton text="+ Configure New Navigation Node" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Navigation ID</th>
                <th style={{ padding: "14px" }}>Navigation Link Name</th>
                <th style={{ padding: "14px" }}>Category Frame</th>
                <th style={{ padding: "14px" }}>Route Path URI</th>
                <th style={{ padding: "14px" }}>Node Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active UI navigation nodes or structure maps configured. Create an entry instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>{record.navigationId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.navigationName || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{record.navigationCategory || "—"}</span></td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.navigationPath || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.navigationStatus || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ======================================= */}
      {/* 2. THREE-STEP STEPPER WIZARD INPUT FORM */}
      {/* ======================================= */}
      {viewMode === "FORM" && (
        <div className="form-container ui-navigation-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>UI Navigation Configuration Schema</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomTextField label="Navigation ID" fullWidth={true} value={formData.navigationId} onChange={(e) => handleChange("navigationId", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Navigation Name Link Reference" width="100%" value={formData.navigationName} onChange={(newValue) => handleChange("navigationName", newValue)}
                    options={[
                      "Primary System Settings Menu",
                      "Cloud Infrastructure Dashboard Tab",
                      "Operational Analytics Report Router",
                      "Billing & Subscriptions Access Route",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Navigation URI Path Route" fullWidth={true} value={formData.navigationPath} onChange={(e) => handleChange("navigationPath", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Navigation UI Frame Location" value={formData.navigationCategory} onChange={(e) => handleChange("navigationCategory", e.target.value)}
                    options={[
                      { label: "Left Sticky Sidebar Panel", value: "SIDEBAR" },
                      { label: "Top Navigation Header bar", value: "NAVBAR" },
                      { label: "Footer Map Index Grid", value: "FOOTER" },
                      { label: "User Quick Actions Dropdown Menu", value: "USER_MENU" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Structural Node Action Type" value={formData.navigationType} onChange={(e) => handleChange("navigationType", e.target.value)}
                    options={[
                      { label: "Direct Endpoint Action Link", value: "LINK" },
                      { label: "Cascading Dropdown Menu Container", value: "DROPDOWN" },
                      { label: "Non-Clickable Menu Group Header Divider", value: "GROUP_HEADER" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Navigation State Status" value={formData.navigationStatus} onChange={(e) => handleChange("navigationStatus", e.target.value)}
                    options={[
                      { label: "Active and Rendered Live", value: "ACTIVE" },
                      { label: "Hidden Globally from Render Engine", value: "HIDDEN" },
                      { label: "Deprecated Legacy Endpoint Node", value: "DEPRECATED" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Navigation Item Core Description" value={formData.navigationDescription} onChange={(e) => handleChange("navigationDescription", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Default Visual Label Text" fullWidth={true} value={formData.navigationLabel} onChange={(e) => handleChange("navigationLabel", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Vector Graphics / Icon Library Class Name" fullWidth={true} value={formData.iconClass} onChange={(e) => handleChange("iconClass", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Target Trigger Context" value={formData.targetWindow} onChange={(e) => handleChange("targetWindow", e.target.value)}
                    options={[
                      { label: "Same Browser Sandbox Window (_self)", value: "_self" },
                      { label: "Launch Independent Tab Context (_blank)", value: "_blank" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Positional Rendering Display Order Priority" fullWidth={true} min={1} value={formData.displayOrder} onChange={(e) => handleChange("displayOrder", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomAutocomplete label="Parent Node Link Identity Reference Mapping" width="100%" value={formData.parentNavigationId} onChange={(newValue) => handleChange("parentNavigationId", newValue)}
                    options={["None - Root Tier Node Configuration", "NAV-001 (Main Dashboard Container)", "NAV-010 (Advanced Adjustments Node)"]}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Allowed Security RBAC Authorization Groups" width="100%" value={formData.rbacRolesAllowed} onChange={(newValue) => handleChange("rbacRolesAllowed", newValue)}
                    options={[
                      "Global Administrator Super User",
                      "Operational Desk Analyst Tier",
                      "Standard Authenticated Consumer Account",
                      "Guest / Unauthenticated Profile Route",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Interlocked Component Feature Flag Targets" width="100%" value={formData.featureFlagsRequired} onChange={(newValue) => handleChange("featureFlagsRequired", newValue)}
                    options={[
                      "None - Always Public Deployment Target",
                      "ENABLE_PREDICTIVE_ANALYTICS_V2",
                      "STRIPE_BILLING_PORTAL_UPGRADE",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Responsive Screen Breakpoint Visibility Rules" value={formData.responsiveVisibility} onChange={(e) => handleChange("responsiveVisibility", e.target.value)}
                    options={[
                      { label: "Render Across All Breakpoint Dimensions", value: "ALL_DEVICES" },
                      { label: "Mobile Device Layout Structures Only", value: "MOBILE_ONLY" },
                      { label: "Desktop Workspace Screens Exclusive", value: "DESKTOP_ONLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Associated Engine Virtual Router Component Name" fullWidth={true} value={formData.relatedRouteComponent} onChange={(e) => handleChange("relatedRouteComponent", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Dynamic Restrictive Injection Path Route Parameters (:id format parsing)" value={formData.urlParameters} onChange={(e) => handleChange("urlParameters", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Default Fallback URL Query Strings parameters (?query format parsing)" value={formData.queryParameters} onChange={(e) => handleChange("queryParameters", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextField label="Static / Dynamic Breadcrumb Label Generation Pattern" fullWidth={true} value={formData.breadCrumbLabel} onChange={(e) => handleChange("breadCrumbLabel", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Absolute Route Target points outside application context (External URL Link)" checked={formData.isExternalLink} onChange={(e) => handleChange("isExternalLink", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce Valid Cryptographic Session Check (Authentication State Required)" checked={formData.requiresAuthentication} onChange={(e) => handleChange("requiresAuthentication", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce Enterprise Premium Subscription Tier Gate Validation" checked={formData.requiresSubscription} onChange={(e) => handleChange("requiresSubscription", e.target.checked)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Dynamic Visual Alert Badge Text Overlays" fullWidth={true} value={formData.badgeText} onChange={(e) => handleChange("badgeText", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Visual Alert Badge Theme Hex Color Accent" fullWidth={true} value={formData.badgeColor} onChange={(e) => handleChange("badgeColor", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="i18n UI Application Multi-Language Localization Translation Key Lookup" fullWidth={true} value={formData.localizationKey} onChange={(e) => handleChange("localizationKey", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Behavior Analytics Tracking Context Identity Event Key" fullWidth={true} value={formData.analyticsEventName} onChange={(e) => handleChange("analyticsEventName", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Architecture Assumptions" value={formData.assumptions} onChange={(e) => handleChange("assumptions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="System Navigation Tree Hard Constraints" value={formData.constraints} onChange={(e) => handleChange("constraints", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Front-End Routing Engineering Notes" value={formData.designNotes} onChange={(e) => handleChange("designNotes", e.target.value)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Supporting Layout Prototypes/Figma Blueprint Attachment:</label>
                  <CustomFileUpload buttonText="Upload Layout Attachment Asset" fileName={formData.supportingDocumentsName} onChange={(e) => handleFileChange("supportingDocumentsName", e)} accept=".pdf,.doc,.docx,.xlsx,.png,.jpg" />
                </div>
              </>
            )}
          </div>

          {/* Stepper Flow Interactive Action Toolbar */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update UI Navigation Model" : "Save UI Navigation Tree Node"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {/* ======================================= */}
      {/* 3. FULL READ-ONLY DETAIL BLUEPRINT DEEP VIEW */}
      {/* ======================================= */}
      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>UI Navigation Architecture Node Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Database Reference: ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Route Profile & Hierarchies</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Navigation ID" value={selectedRecord.navigationId} />
            <DataField label="Navigation Name Link" value={selectedRecord.navigationName} />
            <DataField label="Navigation URI Path Route" value={selectedRecord.navigationPath} />
            <DataField label="Navigation UI Frame Location" value={selectedRecord.navigationCategory} />
            <DataField label="Structural Node Action Type" value={selectedRecord.navigationType} />
            <DataField label="Navigation State Status" value={selectedRecord.navigationStatus} />
            <DataField label="Default Visual Label Text" value={selectedRecord.navigationLabel} />
            <DataField label="Icon Library Class Name" value={selectedRecord.iconClass} />
            <DataField label="Target Trigger Context" value={selectedRecord.targetWindow} />
            <DataField label="Display Order Priority" value={selectedRecord.displayOrder} />
            <DataField label="Parent Node Link Match" value={selectedRecord.parentNavigationId} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Navigation Item Core Description" value={selectedRecord.navigationDescription} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. URL Schemes & Access Controls</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Allowed Security RBAC Authorization Groups" value={selectedRecord.rbacRolesAllowed} />
            <DataField label="Interlocked Feature Flags" value={selectedRecord.featureFlagsRequired} />
            <DataField label="Responsive Breakpoint Visibility Rules" value={selectedRecord.responsiveVisibility} />
            <DataField label="Associated Virtual Router Component" value={selectedRecord.relatedRouteComponent} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Dynamic Path Parameter Specifications" value={selectedRecord.urlParameters} />
            <DataField label="Default Fallback Query String Matrix" value={selectedRecord.queryParameters} />
            <DataField label="Breadcrumb Component Generation Pattern" value={selectedRecord.breadCrumbLabel} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. UX Presentation & Visual States</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Is External Link" value={selectedRecord.isExternalLink} />
            <DataField label="Session Authorization State Required" value={selectedRecord.requiresAuthentication} />
            <DataField label="Premium Gate Access Validation Required" value={selectedRecord.requiresSubscription} />
            <DataField label="Alert Badge Overlay Text" value={selectedRecord.badgeText} />
            <DataField label="Alert Badge Accent Color" value={selectedRecord.badgeColor} />
            <DataField label="Translation Key Match" value={selectedRecord.localizationKey} />
            <DataField label="Behavior Analytics Tracking Event Key" value={selectedRecord.analyticsEventName} />
            <DataField label="Supporting Asset/Blueprint" value={selectedRecord.supportingDocumentsName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Architecture Assumptions" value={selectedRecord.assumptions} />
            <DataField label="Navigation Tree System Hard Constraints" value={selectedRecord.constraints} />
            <DataField label="Front-End Routing Engineering Notes" value={selectedRecord.designNotes} />
          </div>
        </div>
      )}
    </div>
  );
}