package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.UINavigation;

@Repository
public interface UINavigationRepository extends JpaRepository<UINavigation, Long> {
}