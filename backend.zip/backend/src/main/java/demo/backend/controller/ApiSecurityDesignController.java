package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.ApiSecurityDesign;
import demo.backend.repository.ApiSecurityDesignRepository;

@RestController
@RequestMapping("/api/api-security-designs")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ApiSecurityDesignController {

    @Autowired
    private ApiSecurityDesignRepository repository;

    @GetMapping({"", "/"})
    public List<ApiSecurityDesign> getAllDesigns() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiSecurityDesign> getDesignById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<ApiSecurityDesign> saveDesign(@RequestBody ApiSecurityDesign design) {
        ApiSecurityDesign saved = repository.save(design);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiSecurityDesign> updateDesign(@PathVariable Long id, @RequestBody ApiSecurityDesign details) {
        return repository.findById(id).map(design -> {
            design.setApiId(details.getApiId());
            design.setApiName(details.getApiName());
            design.setApiVersion(details.getApiVersion());
            design.setApiCategory(details.getApiCategory());
            design.setApiStatus(details.getApiStatus());
            design.setHttpMethod(details.getHttpMethod());
            design.setAuthenticationRequired(details.getAuthenticationRequired());
            design.setEncryptionRequired(details.getEncryptionRequired());
            design.setAuditLoggingRequired(details.getAuditLoggingRequired());
            design.setRateLimitingRequired(details.getRateLimitingRequired());
            design.setUserRolesAllowed(details.getUserRolesAllowed());
            design.setAuthorizationMethod(details.getAuthorizationMethod());
            design.setCommunicationProtocol(details.getCommunicationProtocol());
            design.setContentType(details.getContentType());
            design.setResponseTimeTarget(details.getResponseTimeTarget());
            design.setSessionTimeout(details.getSessionTimeout());
            design.setMaxRequestsPerMinute(details.getMaxRequestsPerMinute());
            design.setSecurityLevel(details.getSecurityLevel());
            design.setSupportedEnvironments(details.getSupportedEnvironments());
            design.setSupportedClients(details.getSupportedClients());
            design.setErrorSeverityLevel(details.getErrorSeverityLevel());
            design.setRetryMechanismEnabled(details.getRetryMechanismEnabled());
            design.setApiDocumentationName(details.getApiDocumentationName());
            design.setRelatedRequirementIds(details.getRelatedRequirementIds());
            design.setRelatedModuleIds(details.getRelatedModuleIds());
            design.setApiLifecycleStatus(details.getApiLifecycleStatus());
            design.setTestingRequired(details.getTestingRequired());
            design.setThirdPartyIntegration(details.getThirdPartyIntegration());

            ApiSecurityDesign updated = repository.save(design);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDesign(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}