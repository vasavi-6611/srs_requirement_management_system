import React from "react";
import Box from "@mui/material/Box";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";

export default function CustomBottomNavigation({
  value,
  onChange,
  actions = [],
  width = 500,
  showLabels = true,
}) {
  return (
    <Box sx={{ width }}>
      <BottomNavigation
        value={value}
        onChange={(event, newValue) => onChange(newValue)}
        showLabels={showLabels}
      >
        {actions.map((action, index) => (
          <BottomNavigationAction
            key={index}
            label={action.label}
            icon={action.icon}
          />
        ))}
      </BottomNavigation>
    </Box>
  );
}