package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "manual_verifications")
public class ManualVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(name = "uat_criteria")
    private String uatCriteria = "";

    @Lob
    @Column(name = "manual_testing_procedures")
    private String manualTestingProcedures = "";

    @Column(name = "defect_severity_matrix")
    private String defectSeverityMatrix = "";

    @Column(name = "cross_device_testing_matrix")
    private Boolean crossDeviceTestingMatrix = false;

    @Column(name = "qa_team_size_allocated")
    private Integer qaTeamSizeAllocated = 1;

    @Column(name = "target_browsers_list")
    private String targetBrowsersList = "";

    @Column(name = "mobile_os_requirements")
    private String mobileOsRequirements = "";

    @Column(name = "regression_cycle_frequency")
    private String regressionCycleFrequency = "PER_RELEASE";

    @Column(name = "exploratory_testing_hours")
    private Integer exploratoryTestingHours = 4;

    @Column(name = "bug_tracking_tool_integration")
    private String bugTrackingToolIntegration = "";

    @Column(name = "accessibility_compliance_required")
    private Boolean accessibilityComplianceRequired = false;

    @Column(name = "localization_testing_required")
    private Boolean localizationTestingRequired = false;

    @Column(name = "manual_regression_artifact_name")
    private String manualRegressionArtifactName = "";

    @Column(name = "uat_sign_off_template_name")
    private String uatSignOffTemplateName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUatCriteria() { return uatCriteria; }
    public void setUatCriteria(String uatCriteria) { this.uatCriteria = uatCriteria; }

    public String getManualTestingProcedures() { return manualTestingProcedures; }
    public void setManualTestingProcedures(String manualTestingProcedures) { this.manualTestingProcedures = manualTestingProcedures; }

    public String getDefectSeverityMatrix() { return defectSeverityMatrix; }
    public void setDefectSeverityMatrix(String defectSeverityMatrix) { this.defectSeverityMatrix = defectSeverityMatrix; }

    public Boolean getCrossDeviceTestingMatrix() { return crossDeviceTestingMatrix; }
    public void setCrossDeviceTestingMatrix(Boolean crossDeviceTestingMatrix) { this.crossDeviceTestingMatrix = crossDeviceTestingMatrix; }

    public Integer getQaTeamSizeAllocated() { return qaTeamSizeAllocated; }
    public void setQaTeamSizeAllocated(Integer qaTeamSizeAllocated) { this.qaTeamSizeAllocated = qaTeamSizeAllocated; }

    public String getTargetBrowsersList() { return targetBrowsersList; }
    public void setTargetBrowsersList(String targetBrowsersList) { this.targetBrowsersList = targetBrowsersList; }

    public String getMobileOsRequirements() { return mobileOsRequirements; }
    public void setMobileOsRequirements(String mobileOsRequirements) { this.mobileOsRequirements = mobileOsRequirements; }

    public String getRegressionCycleFrequency() { return regressionCycleFrequency; }
    public void setRegressionCycleFrequency(String regressionCycleFrequency) { this.regressionCycleFrequency = regressionCycleFrequency; }

    public Integer getExploratoryTestingHours() { return exploratoryTestingHours; }
    public void setExploratoryTestingHours(Integer exploratoryTestingHours) { this.exploratoryTestingHours = exploratoryTestingHours; }

    public String getBugTrackingToolIntegration() { return bugTrackingToolIntegration; }
    public void setBugTrackingToolIntegration(String bugTrackingToolIntegration) { this.bugTrackingToolIntegration = bugTrackingToolIntegration; }

    public Boolean getAccessibilityComplianceRequired() { return accessibilityComplianceRequired; }
    public void setAccessibilityComplianceRequired(Boolean accessibilityComplianceRequired) { this.accessibilityComplianceRequired = accessibilityComplianceRequired; }

    public Boolean getLocalizationTestingRequired() { return localizationTestingRequired; }
    public void setLocalizationTestingRequired(Boolean localizationTestingRequired) { this.localizationTestingRequired = localizationTestingRequired; }

    public String getManualRegressionArtifactName() { return manualRegressionArtifactName; }
    public void setManualRegressionArtifactName(String manualRegressionArtifactName) { this.manualRegressionArtifactName = manualRegressionArtifactName; }

    public String getUatSignOffTemplateName() { return uatSignOffTemplateName; }
    public void setUatSignOffTemplateName(String uatSignOffTemplateName) { this.uatSignOffTemplateName = uatSignOffTemplateName; }
}