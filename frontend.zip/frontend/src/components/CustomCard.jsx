import React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";

export default function CustomCard({
  title,
  subtitle,
  children,
  actions,
  variant = "outlined",
  raised = false,
}) {
  return (
    <Card variant={variant} raised={raised} sx={{ borderRadius: "12px" }}>
      <CardContent>
        {title && (
          <Typography variant="h5" component="div" sx={{ mb: 0.5, fontWeight: "medium" }}>
            {title}
          </Typography>
        )}
        {subtitle && (
          <Typography variant="body2" sx={{ color: "text.secondary", mb: 2 }}>
            {subtitle}
          </Typography>
        )}
        {children}
      </CardContent>
      {actions && <CardActions>{actions}</CardActions>}
    </Card>
  );
}