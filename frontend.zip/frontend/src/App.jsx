import { useState } from 'react';
import bgImage from './assets/backgroung.jpg';
import './styles/global.css';

import CustomButton from './components/CustomButton';
import ApiSecurityDesignForm from './pages/ApiSecurityDesignForm';
import AutomationUnitTestingForm from "./pages/AutomationUnitTestingForm";
import DatabaseClassDesignForm from './pages/DatabaseClassDesignForm';
import InfrastructureSecurityForm from "./pages/InfrastructureSecurityForm";
import InterfacesAndConstraintsForm from './pages/InterfacesAndConstraintsForm';
import ManualVerificationForm from "./pages/ManualVerificationForm";
import ModuleDesignForm from './pages/ModuleDesignForm';
import NonFunctionalRequirementForm from './pages/NonFunctionalRequirementForm';
import PerformanceStressTestingForm from "./pages/PerformanceStressTestingForm";
import ProjectInformationForm from './pages/ProjectInformationForm';
import RequirementForm from './pages/RequirementForm';
import SystemArchitectureForm from './pages/SystemArchitectureForm';
import TestingRequirementsForm from './pages/TestingRequirementsForm';
import UiNavigationDesignForm from './pages/UiNavigationDesignForm';
import UserProfilesForm from './pages/UserProfilesForm';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [activeForm, setActiveForm] = useState('');

  const handleBackToHome = () => {
    setCurrentPage('home');
    setSelectedCategory('');
    setActiveForm('');
  };

  const handleOpenCategory = (category) => {
    setSelectedCategory(category);
    setCurrentPage('workspace');
    if (category === 'basic') {
      setActiveForm('project');
    } else if (category === 'design') {
      setActiveForm('system-architecture');
    } else if (category === 'testing') {
      setActiveForm('testing-specs');
    }
  };

  return (
    <div style={{
      margin: 0,
      padding: 0,
      width: '100vw',
      height: '100vh',
      backgroundImage: `url(${bgImage})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      backgroundAttachment: 'fixed',
      position: 'fixed',
      top: 0,
      left: 0,
      boxSizing: 'border-box',
      overflow: 'hidden'
    }}>
      
      {/* ---------------- LEVEL 1: LANDING HOME PAGE VIEW ---------------- */}
      {currentPage === 'home' && (
        <div style={{
          padding: '30px',
          width: '100%',
          height: '100%',
          boxSizing: 'border-box',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          overflowY: 'auto'
        }}>
          <h1 style={{ marginBottom: '50px', color: '#ffffff', fontSize: '50px', fontWeight: '800', textShadow: '0 2px 10px rgba(0,0,0,0.5)', textAlign: 'center' }}>
            SRS Requirements Management System
          </h1>
          
          <div style={{
            display: 'flex',
            width: '100%',
            fontSize: '16px',
            gap: '30px',
            justifyContent: 'center',
            alignItems: 'stretch',
            flexWrap: 'wrap',
            maxWidth: '1400px'
          }}>
            {/* 1. Basic Requirements Card */}
            <div style={{
              flex: '1',
              minWidth: '320px',
              maxWidth: '400px',
              padding: '40px 30px',
              background: 'rgba(255, 255, 255, 0.12)',
              backdropFilter: 'blur(12px)',
              WebkitBackdropFilter: 'blur(12px)',
              borderRadius: '16px',
              boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
              border: '1px solid rgba(255, 255, 255, 0.18)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '20px'
            }}>
              <div>
                <h2 style={{ color: '#ffffff', margin: '0', fontSize: '1.6rem' }}>1. Basic Requirements</h2>
                <b><p style={{ color: '#cbd5e1', fontSize: '15px', fontWeight: '400', lineHeight: '1.5', marginTop: '10px' }}>For Uploading Basic Requirements of the project</p></b>
              </div>
              <CustomButton
                text="Open Modules"
                variant="contained"
                onClick={() => handleOpenCategory('basic')}
              />
            </div>

            {/* 2. Design Requirements Card */}
            <div style={{
              flex: '1',
              minWidth: '320px',
              maxWidth: '400px',
              padding: '40px 30px',
              background: 'rgba(255, 255, 255, 0.12)',
              backdropFilter: 'blur(12px)',
              WebkitBackdropFilter: 'blur(12px)',
              borderRadius: '16px',
              boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
              border: '1px solid rgba(255, 255, 255, 0.18)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '20px'
            }}>
              <div>
                <h2 style={{ color: '#ffffff', margin: '0', fontSize: '1.6rem' }}>2. Design Requirements</h2>
                <b><p style={{ color: '#cbd5e1', fontSize: '15px', fontWeight: '400', lineHeight: '1.5', marginTop: '10px' }}>For Uploading Design Requirements of the project</p></b>
              </div>
              <CustomButton
                text="Open Modules"
                variant="contained"
                onClick={() => handleOpenCategory('design')}
              />
            </div>

            {/* 3. Testing Requirements Card */}
            <div style={{
              flex: '1',
              minWidth: '320px',
              maxWidth: '400px',
              padding: '40px 30px',
              background: 'rgba(255, 255, 255, 0.12)',
              backdropFilter: 'blur(12px)',
              WebkitBackdropFilter: 'blur(12px)',
              borderRadius: '16px',
              boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
              border: '1px solid rgba(255, 255, 255, 0.18)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '20px'
            }}>
              <div>
                <h2 style={{ color: '#ffffff', margin: '0', fontSize: '1.6rem' }}>3. Testing Requirements</h2>
                <b><p style={{ color: '#cbd5e1', fontSize: '15px', fontWeight: '400', lineHeight: '1.5', marginTop: '10px' }}>For Uploading Testing Requirements of the project</p></b>
              </div>
              <CustomButton
                text="Open Modules"
                variant="contained"
                onClick={() => handleOpenCategory('testing')}
              />
            </div>
          </div>
        </div>
      )}

      {/* ---------------- LEVEL 2 & 3 INTEGRATED DASHBOARD WORKSPACE ---------------- */}
      {currentPage === 'workspace' && (
        <div style={{ display: 'flex', width: '100vw', height: '100vh', boxSizing: 'border-box' }}>
          
          {/* === LEFT SIDEBAR COMPONENT === */}
          <div style={{
            width: '320px',
            background: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(20px)',
            borderRight: '1px solid rgba(255, 255, 255, 0.1)',
            padding: '25px 20px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            boxSizing: 'border-box',
            height: '100%'
          }}>
            <div>
              <h3 style={{
                color: '#38bdf8',
                fontSize: '14px',
                fontWeight: '700',
                textTransform: 'uppercase',
                letterSpacing: '1px',
                marginBottom: '25px',
                borderBottom: '1px solid rgba(56, 189, 248, 0.2)',
                paddingBottom: '10px'
              }}>
                {selectedCategory === 'basic' && 'Basic Requirements'}
                {selectedCategory === 'design' && 'Design Requirements'}
                {selectedCategory === 'testing' && 'Testing Requirements'}
              </h3>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {selectedCategory === 'basic' && (
                  <>
                    <CustomButton text="Project Information" variant={activeForm === 'project' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('project')} />
                    <CustomButton text="User Profiles" variant={activeForm === 'user' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('user')} />
                    <CustomButton text="Functional Specs" variant={activeForm === 'requirement' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('requirement')} />
                    <CustomButton text="Non-Functional Specs" variant={activeForm === 'nfr' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('nfr')} />
                    <CustomButton text="System Interfaces" variant={activeForm === 'interface-constraint' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('interface-constraint')} />
                  </>
                )}
                
                {selectedCategory === 'design' && (
                  <>
                    <CustomButton text="Architecture Models" variant={activeForm === 'system-architecture' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('system-architecture')} />
                    <CustomButton text="Module Designs" variant={activeForm === 'module-design' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('module-design')} />
                    <CustomButton text="Database Schema" variant={activeForm === 'db-class-design' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('db-class-design')} />
                    <CustomButton text="API & Security" variant={activeForm === 'api-security-design' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('api-security-design')} />
                    <CustomButton text="UI Navigation Flow" variant={activeForm === 'ui-navigation-design' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('ui-navigation-design')} />
                  </>
                )}

                {selectedCategory === 'testing' && (
                  <>
                    <CustomButton text="Testing & QA Specifications" variant={activeForm === 'testing-specs' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('testing-specs')} />
                    <CustomButton text="Automation & Unit Specs" variant={activeForm === 'testing-automation' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('testing-automation')} />
                    <CustomButton text="Manual & QA Matrix" variant={activeForm === 'testing-manual' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('testing-manual')} />
                    <CustomButton text="Performance & Stress" variant={activeForm === 'testing-performance' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('testing-performance')} />
                    <CustomButton text="Security & Environments" variant={activeForm === 'testing-infra' ? 'contained' : 'outlined'} fullWidth={true} onClick={() => setActiveForm('testing-infra')} />
                  </>
                )}
              </div>
            </div>

            <div style={{ marginTop: '20px' }}>
              <CustomButton text="← Back To Main Menu" variant="contained" fullWidth={true} onClick={handleBackToHome} style={{ backgroundColor: '#ef4444 !important' }} />
            </div>
          </div>

          {/* === RIGHT MAIN DATA WORKSPACE === */}
          <div style={{
            flex: 1,
            padding: '0px',
            overflowY: 'auto',
            height: '100vh',
            boxSizing: 'border-box',
            background: '#ffffff'
          }}>
            <div style={{ width: '100%', height: '100%', boxSizing: 'border-box' }}>
              {activeForm === 'project' && <ProjectInformationForm />}
              {activeForm === 'user' && <UserProfilesForm />}
              {activeForm === 'requirement' && <RequirementForm />}
              {activeForm === 'nfr' && <NonFunctionalRequirementForm />}
              {activeForm === 'interface-constraint' && <InterfacesAndConstraintsForm />}
              
              {activeForm === 'system-architecture' && <SystemArchitectureForm />}
              {activeForm === 'module-design' && <ModuleDesignForm />}
              {activeForm === 'db-class-design' && <DatabaseClassDesignForm />}
              {activeForm === 'api-security-design' && <ApiSecurityDesignForm />}
              {activeForm === 'ui-navigation-design' && <UiNavigationDesignForm />}

              {activeForm === 'testing-specs' && <TestingRequirementsForm />}
              {activeForm === 'testing-automation' && <AutomationUnitTestingForm />}
              {activeForm === 'testing-manual' && <ManualVerificationForm />}
              {activeForm === 'testing-performance' && <PerformanceStressTestingForm />}
              {activeForm === 'testing-infra' && <InfrastructureSecurityForm />}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}

export default App;