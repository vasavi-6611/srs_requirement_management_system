package demo.backend.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.ProjectInformation;

@Repository
public interface ProjectInformationRepository
        extends JpaRepository<ProjectInformation, Long> {

    // (Optional) Find a project by its business String ID (e.g., "P-101")
    Optional<ProjectInformation> findByProjectId(String projectId);

    // (Optional) Check if a project with a specific business ID already exists
    boolean existsByProjectId(String projectId);
}