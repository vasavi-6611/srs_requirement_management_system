package demo.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import demo.backend.entity.ProjectInformation;
import demo.backend.repository.ProjectInformationRepository;

@RestController
@RequestMapping("/api/project")
@CrossOrigin(origins = "*")
public class ProjectInformationController {

    @Autowired
    private ProjectInformationRepository repository;

    // Create New Project
    @PostMapping
    public ResponseEntity<ProjectInformation> saveProject(@RequestBody ProjectInformation project) {
        ProjectInformation savedProject = repository.save(project);
        return ResponseEntity.ok(savedProject);
    }

    // Get All Projects
    @GetMapping
    public List<ProjectInformation> getAllProjects() {
        return repository.findAll();
    }

    // Get Single Project by Database Primary Key ID
    @GetMapping("/{id}")
    public ResponseEntity<ProjectInformation> getProjectById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Delete Project by Primary Key ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProject(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.ok("Project Deleted Successfully");
    }

    // Update Existing Project
    @PutMapping("/{id}")
    public ResponseEntity<ProjectInformation> updateProject(
            @PathVariable Long id,
            @RequestBody ProjectInformation updatedProject) {

        return repository.findById(id).map(project -> {
            // Business Keys & Metadata
            project.setProjectId(updatedProject.getProjectId());
            project.setProjectName(updatedProject.getProjectName());
            project.setProjectAcronym(updatedProject.getProjectAcronym());
            project.setProjectVersion(updatedProject.getProjectVersion());
            
            // Dates & Budgets
            project.setStartDate(updatedProject.getStartDate());
            project.setExpectedEndDate(updatedProject.getExpectedEndDate());
            project.setEstimatedBudget(updatedProject.getEstimatedBudget());
            
            // Classifications & Status
            project.setProjectType(updatedProject.getProjectType());
            project.setProjectCategory(updatedProject.getProjectCategory());
            project.setProjectPriority(updatedProject.getProjectPriority());
            project.setProjectStatus(updatedProject.getProjectStatus());
            project.setUserClasses(updatedProject.getUserClasses());
            
            // Operational & Domain Context
            project.setBusinessDomain(updatedProject.getBusinessDomain());
            project.setOperatingEnvironment(updatedProject.getOperatingEnvironment());
            project.setStandardsFollowed(updatedProject.getStandardsFollowed());
            
            // Personnel & Roles
            project.setProjectSponsor(updatedProject.getProjectSponsor());
            project.setProjectManager(updatedProject.getProjectManager());
            project.setStakeholders(updatedProject.getStakeholders());
            project.setIntendedUsers(updatedProject.getIntendedUsers());
            project.setSupportingDocumentName(updatedProject.getSupportingDocumentName());
            
            // Textarea Specifications
            project.setProjectDescription(updatedProject.getProjectDescription());
            project.setBusinessNeed(updatedProject.getBusinessNeed());
            project.setProjectObjective(updatedProject.getProjectObjective());
            project.setProjectScope(updatedProject.getProjectScope());
            project.setProjectVision(updatedProject.getProjectVision());
            project.setProjectBackground(updatedProject.getProjectBackground());
            project.setProjectJustification(updatedProject.getProjectJustification());
            project.setAssumptions(updatedProject.getAssumptions());
            project.setConstraints(updatedProject.getConstraints());
            project.setDependencies(updatedProject.getDependencies());
            project.setSuccessCriteria(updatedProject.getSuccessCriteria());
            project.setAcceptanceCriteria(updatedProject.getAcceptanceCriteria());
            project.setRisks(updatedProject.getRisks());
            project.setRegulatoryRequirements(updatedProject.getRegulatoryRequirements());
            project.setAdditionalNotes(updatedProject.getAdditionalNotes());

            ProjectInformation saved = repository.save(project);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }
}