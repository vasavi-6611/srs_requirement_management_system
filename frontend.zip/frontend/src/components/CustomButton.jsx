import React from "react";
import Button from "@mui/material/Button";

export default function CustomButton({
  text,
  variant = "contained",
  color = "primary",
  onClick,
  startIcon,
  endIcon,
  size = "medium",
  fullWidth = false,
  disabled = false,
}) {
  return (
    <Button
      variant={variant}
      color={color}
      onClick={onClick}
      startIcon={startIcon}
      endIcon={endIcon}
      size={size}
      fullWidth={fullWidth}
      disabled={disabled}
    >
      {text}
    </Button>
  );
}