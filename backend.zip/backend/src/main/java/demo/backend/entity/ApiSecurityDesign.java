package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "api_security_designs")
public class ApiSecurityDesign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "api_id")
    private String apiId = "";

    @Column(name = "api_name", nullable = false)
    private String apiName = "";

    @Column(name = "api_version")
    private String apiVersion = "v1.0.0";

    @Column(name = "api_category")
    private String apiCategory = "";

    @Column(name = "api_status")
    private String apiStatus = "DRAFT";

    @Column(name = "http_method")
    private String httpMethod = "GET";

    @Column(name = "authentication_required")
    private Boolean authenticationRequired = false;

    @Column(name = "encryption_required")
    private Boolean encryptionRequired = false;

    @Column(name = "audit_logging_required")
    private Boolean auditLoggingRequired = false;

    @Column(name = "rate_limiting_required")
    private Boolean rateLimitingRequired = false;

    @Column(name = "user_roles_allowed")
    private String userRolesAllowed = "";

    @Column(name = "authorization_method")
    private String authorizationMethod = "";

    @Column(name = "communication_protocol")
    private String communicationProtocol = "";

    @Column(name = "content_type")
    private String contentType = "";

    @Column(name = "response_time_target")
    private Integer responseTimeTarget = 200;

    @Column(name = "session_timeout")
    private String sessionTimeout = "";

    @Column(name = "max_requests_per_minute")
    private String maxRequestsPerMinute = "";

    @Column(name = "security_level")
    private String securityLevel = "";

    @Column(name = "supported_environments")
    private Boolean supportedEnvironments = false;

    @Column(name = "supported_clients")
    private Boolean supportedClients = false;

    @Column(name = "error_severity_level")
    private String errorSeverityLevel = "";

    @Column(name = "retry_mechanism_enabled")
    private Boolean retryMechanismEnabled = false;

    @Column(name = "api_documentation_name")
    private String apiDocumentationName = "";

    @Column(name = "related_requirement_ids")
    private String relatedRequirementIds = "";

    @Column(name = "related_module_ids")
    private String relatedModuleIds = "";

    @Column(name = "api_lifecycle_status")
    private String apiLifecycleStatus = "ACTIVE";

    @Column(name = "testing_required")
    private Boolean testingRequired = false;

    @Column(name = "third_party_integration")
    private Boolean thirdPartyIntegration = false;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getApiId() { return apiId; }
    public void setApiId(String apiId) { this.apiId = apiId; }

    public String getApiName() { return apiName; }
    public void setApiName(String apiName) { this.apiName = apiName; }

    public String getApiVersion() { return apiVersion; }
    public void setApiVersion(String apiVersion) { this.apiVersion = apiVersion; }

    public String getApiCategory() { return apiCategory; }
    public void setApiCategory(String apiCategory) { this.apiCategory = apiCategory; }

    public String getApiStatus() { return apiStatus; }
    public void setApiStatus(String apiStatus) { this.apiStatus = apiStatus; }

    public String getHttpMethod() { return httpMethod; }
    public void setHttpMethod(String httpMethod) { this.httpMethod = httpMethod; }

    public Boolean getAuthenticationRequired() { return authenticationRequired; }
    public void setAuthenticationRequired(Boolean authenticationRequired) { this.authenticationRequired = authenticationRequired; }

    public Boolean getEncryptionRequired() { return encryptionRequired; }
    public void setEncryptionRequired(Boolean encryptionRequired) { this.encryptionRequired = encryptionRequired; }

    public Boolean getAuditLoggingRequired() { return auditLoggingRequired; }
    public void setAuditLoggingRequired(Boolean auditLoggingRequired) { this.auditLoggingRequired = auditLoggingRequired; }

    public Boolean getRateLimitingRequired() { return rateLimitingRequired; }
    public void setRateLimitingRequired(Boolean rateLimitingRequired) { this.rateLimitingRequired = rateLimitingRequired; }

    public String getUserRolesAllowed() { return userRolesAllowed; }
    public void setUserRolesAllowed(String userRolesAllowed) { this.userRolesAllowed = userRolesAllowed; }

    public String getAuthorizationMethod() { return authorizationMethod; }
    public void setAuthorizationMethod(String authorizationMethod) { this.authorizationMethod = authorizationMethod; }

    public String getCommunicationProtocol() { return communicationProtocol; }
    public void setCommunicationProtocol(String communicationProtocol) { this.communicationProtocol = communicationProtocol; }

    public String getContentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }

    public Integer getResponseTimeTarget() { return responseTimeTarget; }
    public void setResponseTimeTarget(Integer responseTimeTarget) { this.responseTimeTarget = responseTimeTarget; }

    public String getSessionTimeout() { return sessionTimeout; }
    public void setSessionTimeout(String sessionTimeout) { this.sessionTimeout = sessionTimeout; }

    public String getMaxRequestsPerMinute() { return maxRequestsPerMinute; }
    public void setMaxRequestsPerMinute(String maxRequestsPerMinute) { this.maxRequestsPerMinute = maxRequestsPerMinute; }

    public String getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(String securityLevel) { this.securityLevel = securityLevel; }

    public Boolean getSupportedEnvironments() { return supportedEnvironments; }
    public void setSupportedEnvironments(Boolean supportedEnvironments) { this.supportedEnvironments = supportedEnvironments; }

    public Boolean getSupportedClients() { return supportedClients; }
    public void setSupportedClients(Boolean supportedClients) { this.supportedClients = supportedClients; }

    public String getErrorSeverityLevel() { return errorSeverityLevel; }
    public void setErrorSeverityLevel(String errorSeverityLevel) { this.errorSeverityLevel = errorSeverityLevel; }

    public Boolean getRetryMechanismEnabled() { return retryMechanismEnabled; }
    public void setRetryMechanismEnabled(Boolean retryMechanismEnabled) { this.retryMechanismEnabled = retryMechanismEnabled; }

    public String getApiDocumentationName() { return apiDocumentationName; }
    public void setApiDocumentationName(String apiDocumentationName) { this.apiDocumentationName = apiDocumentationName; }

    public String getRelatedRequirementIds() { return relatedRequirementIds; }
    public void setRelatedRequirementIds(String relatedRequirementIds) { this.relatedRequirementIds = relatedRequirementIds; }

    public String getRelatedModuleIds() { return relatedModuleIds; }
    public void setRelatedModuleIds(String relatedModuleIds) { this.relatedModuleIds = relatedModuleIds; }

    public String getApiLifecycleStatus() { return apiLifecycleStatus; }
    public void setApiLifecycleStatus(String apiLifecycleStatus) { this.apiLifecycleStatus = apiLifecycleStatus; }

    public Boolean getTestingRequired() { return testingRequired; }
    public void setTestingRequired(Boolean testingRequired) { this.testingRequired = testingRequired; }

    public Boolean getThirdPartyIntegration() { return thirdPartyIntegration; }
    public void setThirdPartyIntegration(Boolean thirdPartyIntegration) { this.thirdPartyIntegration = thirdPartyIntegration; }
}