package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "requirement_tasks")
public class RequirementTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "requirement_id")
    private String requirementId;

    @Column(name = "requirement_name")
    private String requirementName;

    @Column(name = "requirement_title")
    private String requirementTitle;

    @Column(name = "requirement_category")
    private String requirementCategory;

    @Column(name = "requirement_type")
    private String requirementType;

    @Column(name = "requirement_source")
    private String requirementSource;

    @Column(name = "stakeholder_name")
    private String stakeholderName;

    @Column(name = "user_class")
    private String userClass;

    @Column(name = "requirement_description", length = 2000)
    private String requirementDescription;

    @Column(name = "business_objective", length = 2000)
    private String businessObjective;

    @Column(name = "business_value", length = 2000)
    private String businessValue;

    @Column(name = "problem_statement", length = 2000)
    private String problemStatement;

    @Column(name = "requirement_rationale", length = 2000)
    private String requirementRationale;

    @Column(name = "expected_benefit", length = 2000)
    private String expectedBenefit;

    @Column(name = "priority")
    private String priority;

    @Column(name = "risk_level")
    private String riskLevel;

    @Column(name = "complexity_level")
    private String complexityLevel = "1";

    @Column(name = "status")
    private String status;

    @Column(name = "requirement_status")
    private String requirementStatus = "ACTIVE";

    @Column(name = "trigger_event")
    private String triggerEvent;

    @Column(name = "preconditions", length = 2000)
    private String preconditions;

    @Column(name = "postconditions", length = 2000)
    private String postconditions;

    @Column(name = "input_data", length = 2000)
    private String inputData;

    @Column(name = "output_data", length = 2000)
    private String outputData;

    @Column(name = "processing_rules", length = 2000)
    private String processingRules;

    @Column(name = "dependencies", length = 2000)
    private String dependencies;

    @Column(name = "assumptions", length = 2000)
    private String assumptions;

    @Column(name = "constraints", length = 2000)
    private String constraints;

    @Column(name = "verification_method")
    private String verificationMethod;

    @Column(name = "acceptance_criteria", length = 2000)
    private String acceptanceCriteria;

    @Column(name = "additional_notes", length = 2000)
    private String additionalNotes;

    @Column(name = "approved")
    private Boolean approved = false;

    @Column(name = "estimated_effort_hours")
    private Double estimatedEffortHours = 0.0;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRequirementId() { return requirementId; }
    public void setRequirementId(String requirementId) { this.requirementId = requirementId; }

    public String getRequirementName() { return requirementName; }
    public void setRequirementName(String requirementName) { this.requirementName = requirementName; }

    public String getRequirementTitle() { return requirementTitle; }
    public void setRequirementTitle(String requirementTitle) { this.requirementTitle = requirementTitle; }

    public String getRequirementCategory() { return requirementCategory; }
    public void setRequirementCategory(String requirementCategory) { this.requirementCategory = requirementCategory; }

    public String getRequirementType() { return requirementType; }
    public void setRequirementType(String requirementType) { this.requirementType = requirementType; }

    public String getRequirementSource() { return requirementSource; }
    public void setRequirementSource(String requirementSource) { this.requirementSource = requirementSource; }

    public String getStakeholderName() { return stakeholderName; }
    public void setStakeholderName(String stakeholderName) { this.stakeholderName = stakeholderName; }

    public String getUserClass() { return userClass; }
    public void setUserClass(String userClass) { this.userClass = userClass; }

    public String getRequirementDescription() { return requirementDescription; }
    public void setRequirementDescription(String requirementDescription) { this.requirementDescription = requirementDescription; }

    public String getBusinessObjective() { return businessObjective; }
    public void setBusinessObjective(String businessObjective) { this.businessObjective = businessObjective; }

    public String getBusinessValue() { return businessValue; }
    public void setBusinessValue(String businessValue) { this.businessValue = businessValue; }

    public String getProblemStatement() { return problemStatement; }
    public void setProblemStatement(String problemStatement) { this.problemStatement = problemStatement; }

    public String getRequirementRationale() { return requirementRationale; }
    public void setRequirementRationale(String requirementRationale) { this.requirementRationale = requirementRationale; }

    public String getExpectedBenefit() { return expectedBenefit; }
    public void setExpectedBenefit(String expectedBenefit) { this.expectedBenefit = expectedBenefit; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

    public String getComplexityLevel() { return complexityLevel; }
    public void setComplexityLevel(String complexityLevel) { this.complexityLevel = complexityLevel; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRequirementStatus() { return requirementStatus; }
    public void setRequirementStatus(String requirementStatus) { this.requirementStatus = requirementStatus; }

    public String getTriggerEvent() { return triggerEvent; }
    public void setTriggerEvent(String triggerEvent) { this.triggerEvent = triggerEvent; }

    public String getPreconditions() { return preconditions; }
    public void setPreconditions(String preconditions) { this.preconditions = preconditions; }

    public String getPostconditions() { return postconditions; }
    public void setPostconditions(String postconditions) { this.postconditions = postconditions; }

    public String getInputData() { return inputData; }
    public void setInputData(String inputData) { this.inputData = inputData; }

    public String getOutputData() { return outputData; }
    public void setOutputData(String outputData) { this.outputData = outputData; }

    public String getProcessingRules() { return processingRules; }
    public void setProcessingRules(String processingRules) { this.processingRules = processingRules; }

    public String getDependencies() { return dependencies; }
    public void setDependencies(String dependencies) { this.dependencies = dependencies; }

    public String getAssumptions() { return assumptions; }
    public void setAssumptions(String assumptions) { this.assumptions = assumptions; }

    public String getConstraints() { return constraints; }
    public void setConstraints(String constraints) { this.constraints = constraints; }

    public String getVerificationMethod() { return verificationMethod; }
    public void setVerificationMethod(String verificationMethod) { this.verificationMethod = verificationMethod; }

    public String getAcceptanceCriteria() { return acceptanceCriteria; }
    public void setAcceptanceCriteria(String acceptanceCriteria) { this.acceptanceCriteria = acceptanceCriteria; }

    public String getAdditionalNotes() { return additionalNotes; }
    public void setAdditionalNotes(String additionalNotes) { this.additionalNotes = additionalNotes; }

    public Boolean getApproved() { return approved; }
    public void setApproved(Boolean approved) { this.approved = approved; }

    public Double getEstimatedEffortHours() { return estimatedEffortHours; }
    public void setEstimatedEffortHours(Double estimatedEffortHours) { this.estimatedEffortHours = estimatedEffortHours; }
}