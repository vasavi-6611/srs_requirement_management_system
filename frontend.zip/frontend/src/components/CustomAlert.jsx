import React from "react";
import Alert from "@mui/material/Alert";
export default function CustomAlert({
  severity = "success",
  message,
  icon,
  variant = "standard",
}) {
  return (
    <Alert
      severity={severity}
      icon={icon}
      variant={variant}
    >
      {message}
    </Alert>
  );
}