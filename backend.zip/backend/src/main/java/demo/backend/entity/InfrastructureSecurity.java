package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "infrastructure_security")
public class InfrastructureSecurity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cicd_pipeline_integration")
    private Boolean cicdPipelineIntegration = false;

    @Column(name = "security_penetration_testing", length = 2000)
    private String securityPenetrationTesting = "";

    @Column(name = "test_environment_requirements", length = 2000)
    private String testEnvironmentRequirements = "";

    @Column(name = "test_data_sanitization_required")
    private Boolean testDataSanitizationRequired = false;

    @Column(name = "test_plan_document_name")
    private String testPlanDocumentName = "";

    @Column(name = "compliance_standard_requirement")
    private String complianceStandardRequirement = "";

    @Column(name = "vulnerability_scan_frequency")
    private String vulnerabilityScanFrequency = "";

    @Column(name = "max_allowed_sev1_defects")
    private Integer maxAllowedSev1Defects = 0;

    @Column(name = "max_allowed_sev2_defects")
    private Integer maxAllowedSev2Defects = 2;

    @Column(name = "ssl_cert_expiration_alert_days")
    private Integer sslCertExpirationAlertDays = 30;

    @Column(name = "sandbox_instance_count")
    private Integer sandboxInstanceCount = 1;

    @Column(name = "environment_ttl_days")
    private Integer environmentTtlDays = 7;

    @Column(name = "iam_access_review_cycle")
    private String iamAccessReviewCycle = "QUARTERLY";

    @Column(name = "encryption_algorithm_static")
    private String encryptionAlgorithmStatic = "AES_256";

    @Column(name = "static_code_analysis_tool")
    private String staticCodeAnalysisTool = "";

    @Column(name = "penetration_report_artifact_name")
    private String penetrationReportArtifactName = "";

    @Column(name = "infrastructure_deployment_yaml_name")
    private String infrastructureDeploymentYamlName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Boolean getCicdPipelineIntegration() { return cicdPipelineIntegration; }
    public void setCicdPipelineIntegration(Boolean cicdPipelineIntegration) { this.cicdPipelineIntegration = cicdPipelineIntegration; }

    public String getSecurityPenetrationTesting() { return securityPenetrationTesting; }
    public void setSecurityPenetrationTesting(String securityPenetrationTesting) { this.securityPenetrationTesting = securityPenetrationTesting; }

    public String getTestEnvironmentRequirements() { return testEnvironmentRequirements; }
    public void setTestEnvironmentRequirements(String testEnvironmentRequirements) { this.testEnvironmentRequirements = testEnvironmentRequirements; }

    public Boolean getTestDataSanitizationRequired() { return testDataSanitizationRequired; }
    public void setTestDataSanitizationRequired(Boolean testDataSanitizationRequired) { this.testDataSanitizationRequired = testDataSanitizationRequired; }

    public String getTestPlanDocumentName() { return testPlanDocumentName; }
    public void setTestPlanDocumentName(String testPlanDocumentName) { this.testPlanDocumentName = testPlanDocumentName; }

    public String getComplianceStandardRequirement() { return complianceStandardRequirement; }
    public void setComplianceStandardRequirement(String complianceStandardRequirement) { this.complianceStandardRequirement = complianceStandardRequirement; }

    public String getVulnerabilityScanFrequency() { return vulnerabilityScanFrequency; }
    public void setVulnerabilityScanFrequency(String vulnerabilityScanFrequency) { this.vulnerabilityScanFrequency = vulnerabilityScanFrequency; }

    public Integer getMaxAllowedSev1Defects() { return maxAllowedSev1Defects; }
    public void setMaxAllowedSev1Defects(Integer maxAllowedSev1Defects) { this.maxAllowedSev1Defects = maxAllowedSev1Defects; }

    public Integer getMaxAllowedSev2Defects() { return maxAllowedSev2Defects; }
    public void setMaxAllowedSev2Defects(Integer maxAllowedSev2Defects) { this.maxAllowedSev2Defects = maxAllowedSev2Defects; }

    public Integer getSslCertExpirationAlertDays() { return sslCertExpirationAlertDays; }
    public void setSslCertExpirationAlertDays(Integer sslCertExpirationAlertDays) { this.sslCertExpirationAlertDays = sslCertExpirationAlertDays; }

    public Integer getSandboxInstanceCount() { return sandboxInstanceCount; }
    public void setSandboxInstanceCount(Integer sandboxInstanceCount) { this.sandboxInstanceCount = sandboxInstanceCount; }

    public Integer getEnvironmentTtlDays() { return environmentTtlDays; }
    public void setEnvironmentTtlDays(Integer environmentTtlDays) { this.environmentTtlDays = environmentTtlDays; }

    public String getIamAccessReviewCycle() { return iamAccessReviewCycle; }
    public void setIamAccessReviewCycle(String iamAccessReviewCycle) { this.iamAccessReviewCycle = iamAccessReviewCycle; }

    public String getEncryptionAlgorithmStatic() { return encryptionAlgorithmStatic; }
    public void setEncryptionAlgorithmStatic(String encryptionAlgorithmStatic) { this.encryptionAlgorithmStatic = encryptionAlgorithmStatic; }

    public String getStaticCodeAnalysisTool() { return staticCodeAnalysisTool; }
    public void setStaticCodeAnalysisTool(String staticCodeAnalysisTool) { this.staticCodeAnalysisTool = staticCodeAnalysisTool; }

    public String getPenetrationReportArtifactName() { return penetrationReportArtifactName; }
    public void setPenetrationReportArtifactName(String penetrationReportArtifactName) { this.penetrationReportArtifactName = penetrationReportArtifactName; }

    public String getInfrastructureDeploymentYamlName() { return infrastructureDeploymentYamlName; }
    public void setInfrastructureDeploymentYamlName(String infrastructureDeploymentYamlName) { this.infrastructureDeploymentYamlName = infrastructureDeploymentYamlName; }
}