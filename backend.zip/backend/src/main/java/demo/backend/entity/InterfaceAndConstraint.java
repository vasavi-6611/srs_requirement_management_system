package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "interface_constraints")
public class InterfaceAndConstraint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_interface_standards")
    private String userInterfaceStandards = "";

    @Column(name = "supported_screen_resolutions")
    private String supportedScreenResolutions = "";

    @Column(name = "supported_languages")
    private String supportedLanguages = "";

    @Column(name = "accessibility_requirements")
    private Boolean accessibilityRequirements = false;

    @Column(name = "hardware_requirements", length = 2000)
    private String hardwareRequirements = "";

    @Column(name = "device_compatibility")
    private Boolean deviceCompatibility = false;

    @Column(name = "peripheral_device_support")
    private Boolean peripheralDeviceSupport = false;

    @Column(name = "operating_system_requirements")
    private Boolean operatingSystemRequirements = false;

    @Column(name = "browser_compatibility")
    private Boolean browserCompatibility = false;

    @Column(name = "external_software_dependencies", length = 2000)
    private String externalSoftwareDependencies = "";

    @Column(name = "middleware_requirements", length = 2000)
    private String middlewareRequirements = "";

    @Column(name = "communication_protocol")
    private String communicationProtocol = "";

    @Column(name = "bandwidth_requirements")
    private String bandwidthRequirements = "";

    @Column(name = "api_authentication_method")
    private String apiAuthenticationMethod = "";

    @Column(name = "network_requirements", length = 2000)
    private String networkRequirements = "";

    @Column(name = "regulatory_constraints", length = 2000)
    private String regulatoryConstraints = "";

    @Column(name = "legal_constraints", length = 2000)
    private String legalConstraints = "";

    @Column(name = "security_constraints", length = 2000)
    private String securityConstraints = "";

    @Column(name = "performance_constraints", length = 2000)
    private String performanceConstraints = "";

    @Column(name = "technology_constraints", length = 2000)
    private String technologyConstraints = "";

    @Column(name = "business_assumptions", length = 2000)
    private String businessAssumptions = "";

    @Column(name = "technical_assumptions", length = 2000)
    private String technicalAssumptions = "";

    @Column(name = "external_dependencies", length = 2000)
    private String externalDependencies = "";

    @Column(name = "vendor_dependencies", length = 2000)
    private String vendorDependencies = "";

    @Column(name = "compliance_standards")
    private String complianceStandards = "";

    @Column(name = "reference_documents_name")
    private String referenceDocumentsName = "";

    @Column(name = "supporting_artifacts_name")
    private String supportingArtifactsName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getUserInterfaceStandards() { return userInterfaceStandards; }
    public void setUserInterfaceStandards(String userInterfaceStandards) { this.userInterfaceStandards = userInterfaceStandards; }
    public String getSupportedScreenResolutions() { return supportedScreenResolutions; }
    public void setSupportedScreenResolutions(String supportedScreenResolutions) { this.supportedScreenResolutions = supportedScreenResolutions; }
    public String getSupportedLanguages() { return supportedLanguages; }
    public void setSupportedLanguages(String supportedLanguages) { this.supportedLanguages = supportedLanguages; }
    public Boolean getAccessibilityRequirements() { return accessibilityRequirements; }
    public void setAccessibilityRequirements(Boolean accessibilityRequirements) { this.accessibilityRequirements = accessibilityRequirements; }
    public String getHardwareRequirements() { return hardwareRequirements; }
    public void setHardwareRequirements(String hardwareRequirements) { this.hardwareRequirements = hardwareRequirements; }
    public Boolean getDeviceCompatibility() { return deviceCompatibility; }
    public void setDeviceCompatibility(Boolean deviceCompatibility) { this.deviceCompatibility = deviceCompatibility; }
    public Boolean getPeripheralDeviceSupport() { return peripheralDeviceSupport; }
    public void setPeripheralDeviceSupport(Boolean peripheralDeviceSupport) { this.peripheralDeviceSupport = peripheralDeviceSupport; }
    public Boolean getOperatingSystemRequirements() { return operatingSystemRequirements; }
    public void setOperatingSystemRequirements(Boolean operatingSystemRequirements) { this.operatingSystemRequirements = operatingSystemRequirements; }
    public Boolean getBrowserCompatibility() { return browserCompatibility; }
    public void setBrowserCompatibility(Boolean browserCompatibility) { this.browserCompatibility = browserCompatibility; }
    public String getExternalSoftwareDependencies() { return externalSoftwareDependencies; }
    public void setExternalSoftwareDependencies(String externalSoftwareDependencies) { this.externalSoftwareDependencies = externalSoftwareDependencies; }
    public String getMiddlewareRequirements() { return middlewareRequirements; }
    public void setMiddlewareRequirements(String middlewareRequirements) { this.middlewareRequirements = middlewareRequirements; }
    public String getCommunicationProtocol() { return communicationProtocol; }
    public void setCommunicationProtocol(String communicationProtocol) { this.communicationProtocol = communicationProtocol; }
    public String getBandwidthRequirements() { return bandwidthRequirements; }
    public void setBandwidthRequirements(String bandwidthRequirements) { this.bandwidthRequirements = bandwidthRequirements; }
    public String getApiAuthenticationMethod() { return apiAuthenticationMethod; }
    public void setApiAuthenticationMethod(String apiAuthenticationMethod) { this.apiAuthenticationMethod = apiAuthenticationMethod; }
    public String getNetworkRequirements() { return networkRequirements; }
    public void setNetworkRequirements(String networkRequirements) { this.networkRequirements = networkRequirements; }
    public String getRegulatoryConstraints() { return regulatoryConstraints; }
    public void setRegulatoryConstraints(String regulatoryConstraints) { this.regulatoryConstraints = regulatoryConstraints; }
    public String getLegalConstraints() { return legalConstraints; }
    public void setLegalConstraints(String legalConstraints) { this.legalConstraints = legalConstraints; }
    public String getSecurityConstraints() { return securityConstraints; }
    public void setSecurityConstraints(String securityConstraints) { this.securityConstraints = securityConstraints; }
    public String getPerformanceConstraints() { return performanceConstraints; }
    public void setPerformanceConstraints(String performanceConstraints) { this.performanceConstraints = performanceConstraints; }
    public String getTechnologyConstraints() { return technologyConstraints; }
    public void setTechnologyConstraints(String technologyConstraints) { this.technologyConstraints = technologyConstraints; }
    public String getBusinessAssumptions() { return businessAssumptions; }
    public void setBusinessAssumptions(String businessAssumptions) { this.businessAssumptions = businessAssumptions; }
    public String getTechnicalAssumptions() { return technicalAssumptions; }
    public void setTechnicalAssumptions(String technicalAssumptions) { this.technicalAssumptions = technicalAssumptions; }
    public String getExternalDependencies() { return externalDependencies; }
    public void setExternalDependencies(String externalDependencies) { this.externalDependencies = externalDependencies; }
    public String getVendorDependencies() { return vendorDependencies; }
    public void setVendorDependencies(String vendorDependencies) { this.vendorDependencies = vendorDependencies; }
    public String getComplianceStandards() { return complianceStandards; }
    public void setComplianceStandards(String complianceStandards) { this.complianceStandards = complianceStandards; }
    public String getReferenceDocumentsName() { return referenceDocumentsName; }
    public void setReferenceDocumentsName(String referenceDocumentsName) { this.referenceDocumentsName = referenceDocumentsName; }
    public String getSupportingArtifactsName() { return supportingArtifactsName; }
    public void setSupportingArtifactsName(String supportingArtifactsName) { this.supportingArtifactsName = supportingArtifactsName; }
}