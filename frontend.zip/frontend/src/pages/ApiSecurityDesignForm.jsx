import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomChip from "../components/CustomChip";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomSlider from "../components/CustomSlider";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";

export default function ApiSecurityDesignForm() {
  const [viewMode, setViewMode] = useState("LIST"); // Modes: "LIST", "FORM", "VIEW_DETAILS"
  const [step, setStep] = useState(1);
  const [apiDesignsList, setApiDesignsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedDesign, setSelectedDesign] = useState(null);

  const emptyForm = {
    apiId: "",
    apiName: "",
    apiVersion: "v1.0.0",
    apiCategory: "",
    apiStatus: "DRAFT",
    httpMethod: "GET",
    authenticationRequired: false,
    encryptionRequired: false,
    auditLoggingRequired: false,
    rateLimitingRequired: false,
    userRolesAllowed: "",
    authorizationMethod: "",
    communicationProtocol: "",
    contentType: "",
    responseTimeTarget: 200,
    sessionTimeout: "",
    maxRequestsPerMinute: "",
    securityLevel: "",
    supportedEnvironments: false,
    supportedClients: false,
    errorSeverityLevel: "",
    retryMechanismEnabled: false,
    apiDocumentationName: "",
    relatedRequirementIds: "",
    relatedModuleIds: "",
    apiLifecycleStatus: "ACTIVE",
    testingRequired: false,
    thirdPartyIntegration: false,
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchApiDesigns();
  }, []);

  const fetchApiDesigns = async () => {
    try {
      const response = await api.get("/api/api-security-designs");
      const designs = Array.isArray(response.data) ? response.data : response.data.content || [];
      setApiDesignsList(designs);
    } catch (error) {
      console.error("Error fetching API Security Designs", error);
      setApiDesignsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prev) => prev + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prev) => prev - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (design) => {
    setFormData(design);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (design) => {
    setSelectedDesign(design);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing) {
        await api.put(`/api/api-security-designs/${formData.id}`, formData);
        alert("API Security Design Model Updated Successfully!");
      } else {
        await api.post("/api/api-security-designs", formData);
        alert("API & Security Design Parameters Saved Successfully!");
      }
      await fetchApiDesigns();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to sync backend server endpoints parameters metadata!");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to delete this API security configuration?")) {
      try {
        await api.delete(`/api/api-security-designs/${id}`);
        alert("Configuration Record Deleted Successfully!");
        fetchApiDesigns();
      } catch (error) {
        console.error(error);
        alert("Failed to delete records metadata system references.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value, isBoolean = false }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      {isBoolean ? (
        <span style={{ color: value ? "#16a34a" : "#991b1b", fontWeight: "700", fontSize: "14px" }}>
          {value ? "✅ ENABLED / TRUE" : "❌ DISABLED / FALSE"}
        </span>
      ) : (
        <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>{value ? String(value) : "—"}</span>
      )}
    </div>
  );

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              API & Security Design Registry
            </h2>
            <CustomButton text="+ Add New Configuration" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>API ID</th>
                <th style={{ padding: "14px" }}>API Name</th>
                <th style={{ padding: "14px" }}>Version</th>
                <th style={{ padding: "14px" }}>HTTP Method</th>
                <th style={{ padding: "14px" }}>Status</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Actions System Matrix</th>
              </tr>
            </thead>
            <tbody>
              {apiDesignsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No API security configurations found. Click configuration button to create layout rules.</td>
                </tr>
              ) : (
                apiDesignsList.map((design, idx) => (
                  <tr key={design.id || idx} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{design.apiId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#0f172a" }}>{design.apiName || "—"}</td>
                    <td style={{ padding: "14px" }}>{design.apiVersion || "—"}</td>
                    <td style={{ padding: "14px" }}>
                      <span style={{ background: design.httpMethod === "POST" ? "#fef3c7" : "#e0f2fe", color: design.httpMethod === "POST" ? "#d97706" : "#0369a1", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "700" }}>
                        {design.httpMethod || "GET"}
                      </span>
                    </td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "4px 8px", borderRadius: "4px", fontSize: "12px" }}>{design.apiStatus || "DRAFT"}</span></td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button title="View Full Design Specifications" onClick={() => handleViewClick(design)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View</button>
                        <button title="Modify Fields Record" onClick={() => handleEditClick(design)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button title="Delete Meta Target Mapping" onClick={() => handleDeleteClick(design.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container api-security-design-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>{isEditing ? "Modify API Security Design Model" : "API & Security Designs Wizard Registration"}</h2>
            <CustomButton text="Cancel Matrix Layout" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
            {["1. API Identity & Protocol", "2. Security & Authorization", "3. SLA Targets & Lineage"].map((title, index) => {
              const stepNum = index + 1;
              const isActive = step === stepNum;
              return (
                <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                    {step > stepNum ? "✓" : stepNum}
                  </span>
                  <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
                </div>
              );
            })}
          </div>

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="API ID" fullWidth value={formData.apiId} onChange={(e) => handleChange("apiId", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="API Name" fullWidth value={formData.apiName} onChange={(e) => handleChange("apiName", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="API Version" fullWidth value={formData.apiVersion} onChange={(e) => handleChange("apiVersion", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomSelect label="API Category" value={formData.apiCategory} onChange={(e) => handleChange("apiCategory", e.target.value)} options={[{ label: "Core Enterprise Services", value: "CORE" }, { label: "Reporting & Bulk Data Analytics", value: "ANALYTICS" }, { label: "External Gateway Open Integrations", value: "INTEGRATION" }]} /></div>
                
                <div style={{ ...halfWidthItem, display: "flex", alignItems: "center", gap: "10px" }}>
                  <label style={{ fontSize: "14px", color: "#555", fontWeight: "600" }}>API Configuration Status:</label>
                  <CustomChip label={formData.apiStatus} color="primary" />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", alignItems: "center", gap: "10px" }}>
                  <label style={{ fontSize: "14px", color: "#555", fontWeight: "600" }}>API Lifecycle Registry Status:</label>
                  <CustomChip label={formData.apiLifecycleStatus} color="secondary" />
                </div>

                <div style={fullWidthItem}><CustomRadioGroup label="HTTP Method Type Trigger" row={true} value={formData.httpMethod} onChange={(e) => handleChange("httpMethod", e.target.value)} options={[{ label: "GET (Fetch Schema Resources)", value: "GET" }, { label: "POST (Commit Endpoint Payloads)", value: "POST" }, { label: "PUT (Update State Definitions)", value: "PUT" }, { label: "DELETE (Logical Removal Triggers)", value: "DELETE" }]} /></div>
                <div style={fullWidthItem}><CustomRadioGroup label="Communication Protocol Architecture Style" row={true} value={formData.communicationProtocol} onChange={(e) => handleChange("communicationProtocol", e.target.value)} options={[{ label: "REST Architecture Protocol (HTTP/JSON)", value: "REST" }, { label: "gRPC Binary Remote Call Stream Pipelines", value: "GRPC" }, { label: "GraphQL Dynamic Unified Endpoint Broker", value: "GRAPHQL" }]} /></div>
                
                <div style={halfWidthItem}><CustomSelect label="Content Type Format System" value={formData.contentType} onChange={(e) => handleChange("contentType", e.target.value)} options={[{ label: "application/json Baseline Encodings", value: "JSON" }, { label: "application/x-protobuf Stream Blocks", value: "PROTOBUF" }, { label: "multipart/form-data Attachments Streaming", value: "MULTIPART" }]} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Session Timeout Duration Boundaries (Seconds)" fullWidth={true} min={30} value={formData.sessionTimeout} onChange={(e) => handleChange("sessionTimeout", e.target.value)} /></div>
                
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Supported Deployment Environments Check" checked={formData.supportedEnvironments} onChange={(e) => handleChange("supportedEnvironments", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Supported Clients Protocols Check" checked={formData.supportedClients} onChange={(e) => handleChange("supportedClients", e.target.checked)} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Secure Endpoint Identity Authentication Required" checked={formData.authenticationRequired} onChange={(e) => handleChange("authenticationRequired", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Force Hardware Cryptographic Key Payload Encryption" checked={formData.encryptionRequired} onChange={(e) => handleChange("encryptionRequired", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Enforce Immutable Security Audit Logging Registers Streams" checked={formData.auditLoggingRequired} onChange={(e) => handleChange("auditLoggingRequired", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Elastic Rate Limiting Protection Required On Proxy Instances" checked={formData.rateLimitingRequired} onChange={(e) => handleChange("rateLimitingRequired", e.target.checked)} /></div>
                
                <div style={halfWidthItem}><CustomNumberField label="Maximum Rate Limit Bandwidth (Requests Per Minute)" fullWidth={true} min={1} value={formData.maxRequestsPerMinute} onChange={(e) => handleChange("maxRequestsPerMinute", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomSelect label="Target Security Level Classification" value={formData.securityLevel} onChange={(e) => handleChange("securityLevel", e.target.value)} options={[{ label: "Level 1: Public Base Sandbox Unrestricted", value: "PUBLIC_L1" }, { label: "Level 2: Internal Encrypted Network Bounds", value: "INTERNAL_L2" }, { label: "Level 3: Hardened Compliance Financial Vault", value: "VAULT_L3" }]} /></div>
                <div style={halfWidthItem}><CustomSelect label="Authorization Security Access Control Framework" value={formData.authorizationMethod} onChange={(e) => handleChange("authorizationMethod", e.target.value)} options={[{ label: "Stateless Symmetric Cryptographic JWT Bearer Validation", value: "JWT_BEARER" }, { label: "Role-Based Access Control (RBAC System Matrix Filters)", value: "RBAC" }, { label: "Attribute-Based Dynamic Context Access Rules (ABAC)", value: "ABAC" }]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Allowed Access User Roles Selection" width="100%" value={formData.userRolesAllowed} onChange={(nv) => handleChange("userRolesAllowed", nv)} options={["System Administrator Tier", "Business Operations Executive", "Sovereign Third-Party Application Adapter"]} /></div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", gap: "8px", padding: "10px 0" }}>
                  <label style={{ fontSize: "14px", color: "#334155", fontWeight: "600" }}>Response Time Target Performance Window: <strong>{formData.responseTimeTarget} ms</strong> Max Processing SLA</label>
                  <CustomSlider value={formData.responseTimeTarget} min={50} max={2000} step={50} width="100%" onChange={(e, nv) => handleChange("responseTimeTarget", nv)} />
                </div>

                <div style={halfWidthItem}><CustomSelect label="Default Runtime Error Severity Level" value={formData.errorSeverityLevel} onChange={(e) => handleChange("errorSeverityLevel", e.target.value)} options={[{ label: "Severity 1: Critical System Panic Failure", value: "CRITICAL" }, { label: "Severity 2: Recoverable Operational Warning Alerts", value: "WARNING" }, { label: "Severity 3: Standard Information Diagnosis Trace", value: "INFO" }]} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Automatic Ingress Request Retry Mechanism Enabled on Gateway" checked={formData.retryMechanismEnabled} onChange={(e) => handleChange("retryMechanismEnabled", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Third-Party Remote REST / SOAP Core Integration Endpoint Support" checked={formData.thirdPartyIntegration} onChange={(e) => handleChange("thirdPartyIntegration", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Formal Automation Validation Code Testing Required Before Main Merge" checked={formData.testingRequired} onChange={(e) => handleChange("testingRequired", e.target.checked)} /></div>
                
                <div style={halfWidthItem}><CustomAutocomplete label="Traceable Mapped Requirement ID Links" width="100%" value={formData.relatedRequirementIds} onChange={(nv) => handleChange("relatedRequirementIds", nv)} options={["REQ-F-001 CORE ACCESS", "REQ-NFR-04 AVAILABILITY RULES"]} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Traceable Mapped Module ID Design Connections" width="100%" value={formData.relatedModuleIds} onChange={(nv) => handleChange("relatedModuleIds", nv)} options={["MOD-001 CONTROLLER CORE", "AUTH-SEC-02 SECURITY BLOCK"]} /></div>
                
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555", fontWeight: "600" }}>API Documentation Schema Blueprint Attachment:</label>
                  <CustomFileUpload buttonText="Upload OpenAPI/Swagger Specification" fileName={formData.apiDocumentationName} onChange={(e) => handleFileChange("apiDocumentationName", e)} accept=".json,.yaml,.yml,.pdf" />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Model Configuration" : "Save API Security Design Model"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedDesign && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Full API Specification Audit Inspector View</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Reference: ID-{selectedDesign.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. API Identity & Protocol Properties</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="API ID" value={selectedDesign.apiId} />
            <DataField label="API Name" value={selectedDesign.apiName} />
            <DataField label="API Version" value={selectedDesign.apiVersion} />
            <DataField label="API Category" value={selectedDesign.apiCategory} />
            <DataField label="Configuration Status" value={selectedDesign.apiStatus} />
            <DataField label="Lifecycle Registry Status" value={selectedDesign.apiLifecycleStatus} />
            <DataField label="HTTP Method" value={selectedDesign.httpMethod} />
            <DataField label="Communication Style" value={selectedDesign.communicationProtocol} />
            <DataField label="Content Type Format" value={selectedDesign.contentType} />
            <DataField label="Session Timeout (Sec)" value={selectedDesign.sessionTimeout} />
            <DataField label="Deployment Environments Verified" value={selectedDesign.supportedEnvironments} isBoolean />
            <DataField label="Supported Client Profiles Matrix" value={selectedDesign.supportedClients} isBoolean />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Security & Token Gateway Guards</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="Identity Authentication Required" value={selectedDesign.authenticationRequired} isBoolean />
            <DataField label="Hardware Key Payload Encryption" value={selectedDesign.encryptionRequired} isBoolean />
            <DataField label="Immutable Security Audit Logging" value={selectedDesign.auditLoggingRequired} isBoolean />
            <DataField label="Elastic Rate Limiting Protection" value={selectedDesign.rateLimitingRequired} isBoolean />
            <DataField label="Maximum Rate Limit Threshold" value={selectedDesign.maxRequestsPerMinute} />
            <DataField label="Security Level Classification" value={selectedDesign.securityLevel} />
            <DataField label="Access Control Framework Method" value={selectedDesign.authorizationMethod} />
            <DataField label="Allowed Access Active User Roles" value={selectedDesign.userRolesAllowed} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. SLA Threshold Targets & Lineage Traceability</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px" }}>
            <DataField label="Response Time Processing SLA Window" value={`${selectedDesign.responseTimeTarget} ms`} />
            <DataField label="Default Runtime Error Severity" value={selectedDesign.errorSeverityLevel} />
            <DataField label="Gateway Request Retry Engine Enabled" value={selectedDesign.retryMechanismEnabled} isBoolean />
            <DataField label="Third Party Core Integration Endpoint" value={selectedDesign.thirdPartyIntegration} isBoolean />
            <DataField label="Formal Automation Testing Required" value={selectedDesign.testingRequired} isBoolean />
            <DataField label="Mapped Requirement ID Trace links" value={selectedDesign.relatedRequirementIds} />
            <DataField label="Mapped Module ID Design Matrix" value={selectedDesign.relatedModuleIds} />
            <DataField label="OpenAPI/Swagger Schema Blueprint" value={selectedDesign.apiDocumentationName} />
          </div>
        </div>
      )}
    </div>
  );
}