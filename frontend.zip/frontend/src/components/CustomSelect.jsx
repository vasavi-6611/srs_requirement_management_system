import React from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

export default function CustomSelect({
  label,
  value,
  onChange,
  options = [],
  fullWidth = true,
  minWidth = 120,
}) {
  return (
    <Box sx={{ minWidth }}>
      <FormControl fullWidth={fullWidth}>
        <InputLabel>{label}</InputLabel>

        <Select
          value={value}
          label={label}
          onChange={onChange}
        >
          {options.map((option, index) => (
            <MenuItem
              key={index}
              value={option.value}
            >
              {option.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}