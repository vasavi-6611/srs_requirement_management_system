import React from "react";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";

export default function CustomList({
  items = [],
  width = "100%",
  maxWidth = 360,
}) {
  return (
    <Box
      sx={{
        width,
        maxWidth,
        bgcolor: "background.paper",
      }}
    >
      <List>
        {items.map((item, index) => (
          <React.Fragment key={index}>
            
            <ListItem disablePadding>
              <ListItemButton
                component={item.href ? "a" : "button"}
                href={item.href}
                onClick={item.onClick}
              >
                {item.icon && (
                  <ListItemIcon>
                    {item.icon}
                  </ListItemIcon>
                )}

                <ListItemText primary={item.primary} />
              </ListItemButton>
            </ListItem>

            {item.divider && <Divider />}
            
          </React.Fragment>
        ))}
      </List>
    </Box>
  );
}