package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "project_information")
public class ProjectInformation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "project_id")
    private String projectId;

    @Column(name = "project_name")
    private String projectName;

    @Column(name = "project_acronym")
    private String projectAcronym;

    @Column(name = "project_version")
    private String projectVersion;

    @Column(name = "start_date")
    private String startDate;

    @Column(name = "expected_end_date")
    private String expectedEndDate;

    @Column(name = "estimated_budget")
    private String estimatedBudget;

    @Column(name = "project_type")
    private String projectType;

    @Column(name = "project_category")
    private String projectCategory;

    @Column(name = "project_priority")
    private String projectPriority;

    @Column(name = "project_status")
    private String projectStatus;

    @Column(name = "user_classes")
    private String userClasses;

    @Column(name = "business_domain")
    private String businessDomain;

    @Column(name = "operating_environment")
    private String operatingEnvironment;

    @Column(name = "standards_followed")
    private String standardsFollowed;

    @Column(name = "project_sponsor")
    private String projectSponsor;

    @Column(name = "project_manager")
    private String projectManager;

    @Column(name = "stakeholders", length = 1000)
    private String stakeholders;

    @Column(name = "intended_users", length = 1000)
    private String intendedUsers;

    @Column(name = "supporting_document_name")
    private String supportingDocumentName;

    @Column(name = "project_description", length = 3000)
    private String projectDescription;

    @Column(name = "business_need", length = 3000)
    private String businessNeed;

    @Column(name = "project_objective", length = 3000)
    private String projectObjective;

    @Column(name = "project_scope", length = 3000)
    private String projectScope;

    @Column(name = "project_vision", length = 3000)
    private String projectVision;

    @Column(name = "project_background", length = 3000)
    private String projectBackground;

    @Column(name = "project_justification", length = 3000)
    private String projectJustification;

    @Column(name = "assumptions", length = 3000)
    private String assumptions;

    @Column(name = "constraints", length = 3000)
    private String constraints;

    @Column(name = "dependencies", length = 3000)
    private String dependencies;

    @Column(name = "success_criteria", length = 3000)
    private String successCriteria;

    @Column(name = "acceptance_criteria", length = 3000)
    private String acceptanceCriteria;

    @Column(name = "risks", length = 3000)
    private String risks;

    @Column(name = "regulatory_requirements", length = 3000)
    private String regulatoryRequirements;

    @Column(name = "additional_notes", length = 3000)
    private String additionalNotes;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectAcronym() {
        return projectAcronym;
    }

    public void setProjectAcronym(String projectAcronym) {
        this.projectAcronym = projectAcronym;
    }

    public String getProjectVersion() {
        return projectVersion;
    }

    public void setProjectVersion(String projectVersion) {
        this.projectVersion = projectVersion;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getExpectedEndDate() {
        return expectedEndDate;
    }

    public void setExpectedEndDate(String expectedEndDate) {
        this.expectedEndDate = expectedEndDate;
    }

    public String getEstimatedBudget() {
        return estimatedBudget;
    }

    public void setEstimatedBudget(String estimatedBudget) {
        this.estimatedBudget = estimatedBudget;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    public String getProjectCategory() {
        return projectCategory;
    }

    public void setProjectCategory(String projectCategory) {
        this.projectCategory = projectCategory;
    }

    public String getProjectPriority() {
        return projectPriority;
    }

    public void setProjectPriority(String projectPriority) {
        this.projectPriority = projectPriority;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public String getUserClasses() {
        return userClasses;
    }

    public void setUserClasses(String userClasses) {
        this.userClasses = userClasses;
    }

    public String getBusinessDomain() {
        return businessDomain;
    }

    public void setBusinessDomain(String businessDomain) {
        this.businessDomain = businessDomain;
    }

    public String getOperatingEnvironment() {
        return operatingEnvironment;
    }

    public void setOperatingEnvironment(String operatingEnvironment) {
        this.operatingEnvironment = operatingEnvironment;
    }

    public String getStandardsFollowed() {
        return standardsFollowed;
    }

    public void setStandardsFollowed(String standardsFollowed) {
        this.standardsFollowed = standardsFollowed;
    }

    public String getProjectSponsor() {
        return projectSponsor;
    }

    public void setProjectSponsor(String projectSponsor) {
        this.projectSponsor = projectSponsor;
    }

    public String getProjectManager() {
        return projectManager;
    }

    public void setProjectManager(String projectManager) {
        this.projectManager = projectManager;
    }

    public String getStakeholders() {
        return stakeholders;
    }

    public void setStakeholders(String stakeholders) {
        this.stakeholders = stakeholders;
    }

    public String getIntendedUsers() {
        return intendedUsers;
    }

    public void setIntendedUsers(String intendedUsers) {
        this.intendedUsers = intendedUsers;
    }

    public String getSupportingDocumentName() {
        return supportingDocumentName;
    }

    public void setSupportingDocumentName(String supportingDocumentName) {
        this.supportingDocumentName = supportingDocumentName;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public String getBusinessNeed() {
        return businessNeed;
    }

    public void setBusinessNeed(String businessNeed) {
        this.businessNeed = businessNeed;
    }

    public String getProjectObjective() {
        return projectObjective;
    }

    public void setProjectObjective(String projectObjective) {
        this.projectObjective = projectObjective;
    }

    public String getProjectScope() {
        return projectScope;
    }

    public void setProjectScope(String projectScope) {
        this.projectScope = projectScope;
    }

    public String getProjectVision() {
        return projectVision;
    }

    public void setProjectVision(String projectVision) {
        this.projectVision = projectVision;
    }

    public String getProjectBackground() {
        return projectBackground;
    }

    public void setProjectBackground(String projectBackground) {
        this.projectBackground = projectBackground;
    }

    public String getProjectJustification() {
        return projectJustification;
    }

    public void setProjectJustification(String projectJustification) {
        this.projectJustification = projectJustification;
    }

    public String getAssumptions() {
        return assumptions;
    }

    public void setAssumptions(String assumptions) {
        this.assumptions = assumptions;
    }

    public String getConstraints() {
        return constraints;
    }

    public void setConstraints(String constraints) {
        this.constraints = constraints;
    }

    public String getDependencies() {
        return dependencies;
    }

    public void setDependencies(String dependencies) {
        this.dependencies = dependencies;
    }

    public String getSuccessCriteria() {
        return successCriteria;
    }

    public void setSuccessCriteria(String successCriteria) {
        this.successCriteria = successCriteria;
    }

    public String getAcceptanceCriteria() {
        return acceptanceCriteria;
    }

    public void setAcceptanceCriteria(String acceptanceCriteria) {
        this.acceptanceCriteria = acceptanceCriteria;
    }

    public String getRisks() {
        return risks;
    }

    public void setRisks(String risks) {
        this.risks = risks;
    }

    public String getRegulatoryRequirements() {
        return regulatoryRequirements;
    }

    public void setRegulatoryRequirements(String regulatoryRequirements) {
        this.regulatoryRequirements = regulatoryRequirements;
    }

    public String getAdditionalNotes() {
        return additionalNotes;
    }

    public void setAdditionalNotes(String additionalNotes) {
        this.additionalNotes = additionalNotes;
    }
}