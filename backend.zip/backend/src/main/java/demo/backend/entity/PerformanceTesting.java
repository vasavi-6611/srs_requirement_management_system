package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "performance_testing")
public class PerformanceTesting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "performance_testing_tools")
    private String performanceTestingTools = "";

    @Column(name = "peak_load_test_benchmark")
    private String peakLoadTestBenchmark = "";

    @Lob
    @Column(name = "regression_testing_scope")
    private String regressionTestingScope = "";

    @Column(name = "concurrent_users_target")
    private Integer concurrentUsersTarget = 100;

    @Column(name = "ramp_up_period_minutes")
    private Integer rampUpPeriodMinutes = 5;

    @Column(name = "test_duration_minutes")
    private Integer testDurationMinutes = 60;

    @Column(name = "max_response_time_threshold")
    private Integer maxResponseTimeThreshold = 2000;

    @Column(name = "error_rate_tolerance_percent")
    private Double errorRateTolerancePercent = 1.0;

    @Column(name = "throughput_target_rps")
    private Integer throughputTargetRps = 500;

    @Column(name = "cpu_utilization_limit")
    private Integer cpuUtilizationLimit = 80;

    @Column(name = "memory_utilization_limit")
    private Integer memoryUtilizationLimit = 85;

    @Column(name = "network_bandwidth_cap_mbps")
    private Integer networkBandwidthCapMbps = 1000;

    @Column(name = "database_connection_timeout_ms")
    private Integer databaseConnectionTimeoutMs = 5000;

    @Column(name = "cache_hit_ratio_target")
    private Integer cacheHitRatioTarget = 90;

    @Column(name = "auto_scaling_trigger_verification")
    private Boolean autoScalingTriggerVerification = false;

    @Column(name = "soak_test_duration_hours")
    private Integer soakTestDurationHours = 24;

    @Column(name = "performance_script_artifact_name")
    private String performanceScriptArtifactName = "";

    @Column(name = "infrastructure_metrics_plan_name")
    private String infrastructureMetricsPlanName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPerformanceTestingTools() { return performanceTestingTools; }
    public void setPerformanceTestingTools(String performanceTestingTools) { this.performanceTestingTools = performanceTestingTools; }

    public String getPeakLoadTestBenchmark() { return peakLoadTestBenchmark; }
    public void setPeakLoadTestBenchmark(String peakLoadTestBenchmark) { this.peakLoadTestBenchmark = peakLoadTestBenchmark; }

    public String getRegressionTestingScope() { return regressionTestingScope; }
    public void setRegressionTestingScope(String regressionTestingScope) { this.regressionTestingScope = regressionTestingScope; }

    public Integer getConcurrentUsersTarget() { return concurrentUsersTarget; }
    public void setConcurrentUsersTarget(Integer concurrentUsersTarget) { this.concurrentUsersTarget = concurrentUsersTarget; }

    public Integer getRampUpPeriodMinutes() { return rampUpPeriodMinutes; }
    public void setRampUpPeriodMinutes(Integer rampUpPeriodMinutes) { this.rampUpPeriodMinutes = rampUpPeriodMinutes; }

    public Integer getTestDurationMinutes() { return testDurationMinutes; }
    public void setTestDurationMinutes(Integer testDurationMinutes) { this.testDurationMinutes = testDurationMinutes; }

    public Integer getMaxResponseTimeThreshold() { return maxResponseTimeThreshold; }
    public void setMaxResponseTimeThreshold(Integer maxResponseTimeThreshold) { this.maxResponseTimeThreshold = maxResponseTimeThreshold; }

    public Double getErrorRateTolerancePercent() { return errorRateTolerancePercent; }
    public void setErrorRateTolerancePercent(Double errorRateTolerancePercent) { this.errorRateTolerancePercent = errorRateTolerancePercent; }

    public Integer getThroughputTargetRps() { return throughputTargetRps; }
    public void setThroughputTargetRps(Integer throughputTargetRps) { this.throughputTargetRps = throughputTargetRps; }

    public Integer getCpuUtilizationLimit() { return cpuUtilizationLimit; }
    public void setCpuUtilizationLimit(Integer cpuUtilizationLimit) { this.cpuUtilizationLimit = cpuUtilizationLimit; }

    public Integer getMemoryUtilizationLimit() { return memoryUtilizationLimit; }
    public void setMemoryUtilizationLimit(Integer memoryUtilizationLimit) { this.memoryUtilizationLimit = memoryUtilizationLimit; }

    public Integer getNetworkBandwidthCapMbps() { return networkBandwidthCapMbps; }
    public void setNetworkBandwidthCapMbps(Integer networkBandwidthCapMbps) { this.networkBandwidthCapMbps = networkBandwidthCapMbps; }

    public Integer getDatabaseConnectionTimeoutMs() { return databaseConnectionTimeoutMs; }
    public void setDatabaseConnectionTimeoutMs(Integer databaseConnectionTimeoutMs) { this.databaseConnectionTimeoutMs = databaseConnectionTimeoutMs; }

    public Integer getCacheHitRatioTarget() { return cacheHitRatioTarget; }
    public void setCacheHitRatioTarget(Integer cacheHitRatioTarget) { this.cacheHitRatioTarget = cacheHitRatioTarget; }

    public Boolean getAutoScalingTriggerVerification() { return autoScalingTriggerVerification; }
    public void setAutoScalingTriggerVerification(Boolean autoScalingTriggerVerification) { this.autoScalingTriggerVerification = autoScalingTriggerVerification; }

    public Integer getSoakTestDurationHours() { return soakTestDurationHours; }
    public void setSoakTestDurationHours(Integer soakTestDurationHours) { this.soakTestDurationHours = soakTestDurationHours; }

    public String getPerformanceScriptArtifactName() { return performanceScriptArtifactName; }
    public void setPerformanceScriptArtifactName(String performanceScriptArtifactName) { this.performanceScriptArtifactName = performanceScriptArtifactName; }

    public String getInfrastructureMetricsPlanName() { return infrastructureMetricsPlanName; }
    public void setInfrastructureMetricsPlanName(String infrastructureMetricsPlanName) { this.infrastructureMetricsPlanName = infrastructureMetricsPlanName; }
}