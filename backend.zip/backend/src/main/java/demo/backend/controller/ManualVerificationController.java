package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.ManualVerification;
import demo.backend.repository.ManualVerificationRepository;

@RestController
@RequestMapping("/api/testing/manual")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ManualVerificationController {

    @Autowired
    private ManualVerificationRepository repository;

    @GetMapping({"", "/"})
    public List<ManualVerification> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ManualVerification> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<ManualVerification> saveRecord(@RequestBody ManualVerification record) {
        ManualVerification saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ManualVerification> updateRecord(@PathVariable Long id, @RequestBody ManualVerification details) {
        return repository.findById(id).map(record -> {
            record.setUatCriteria(details.getUatCriteria());
            record.setManualTestingProcedures(details.getManualTestingProcedures());
            record.setDefectSeverityMatrix(details.getDefectSeverityMatrix());
            record.setCrossDeviceTestingMatrix(details.getCrossDeviceTestingMatrix());
            record.setQaTeamSizeAllocated(details.getQaTeamSizeAllocated());
            record.setTargetBrowsersList(details.getTargetBrowsersList());
            record.setMobileOsRequirements(details.getMobileOsRequirements());
            record.setRegressionCycleFrequency(details.getRegressionCycleFrequency());
            record.setExploratoryTestingHours(details.getExploratoryTestingHours());
            record.setBugTrackingToolIntegration(details.getBugTrackingToolIntegration());
            record.setAccessibilityComplianceRequired(details.getAccessibilityComplianceRequired());
            record.setLocalizationTestingRequired(details.getLocalizationTestingRequired());
            record.setManualRegressionArtifactName(details.getManualRegressionArtifactName());
            record.setUatSignOffTemplateName(details.getUatSignOffTemplateName());

            ManualVerification updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}