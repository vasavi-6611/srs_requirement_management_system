import React from "react";
import TextField from "@mui/material/TextField";

export default function CustomTextarea({
  label,
  value,
  onChange,
  placeholder,
  fullWidth = true,
  variant = "outlined",
  disabled = false,
  error = false,
  helperText = "",
  ...rest
}) {
  return (
    <TextField
      label={label}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      multiline
      minRows={2}   
      fullWidth={fullWidth}
      variant={variant}
      disabled={disabled}
      error={error}
      helperText={helperText}
      {...rest}
    />
  );
}