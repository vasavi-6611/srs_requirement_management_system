package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "db_class_designs")
public class DatabaseClassDesign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "table_class_id")
    private String tableClassId = "";

    @Column(name = "table_class_name", nullable = false)
    private String tableClassName = "";

    @Column(name = "entity_type")
    private String entityType = "";

    @Column(name = "version")
    private String version = "1.0";

    @Column(name = "description", length = 2000)
    private String description = "";

    @Column(name = "attributes_columns", length = 2500)
    private String attributesColumns = "";

    @Column(name = "data_types", length = 2000)
    private String dataTypes = "";

    @Column(name = "column_constraints", length = 2000)
    private String columnConstraints = "";

    @Column(name = "default_values", length = 2000)
    private String defaultValues = "";

    @Column(name = "nullable_fields", length = 2000)
    private String nullableFields = "";

    @Column(name = "primary_key_type")
    private String primaryKeyType = "IDENTITY";

    @Column(name = "primary_key_column")
    private String primaryKeyColumn = "";

    @Column(name = "composite_key_details", length = 2000)
    private String compositeKeyDetails = "";

    @Column(name = "has_foreign_key")
    private Boolean hasForeignKey = false;

    @Column(name = "foreign_key_details", length = 2000)
    private String foreignKeyDetails = "";

    @Column(name = "referenced_table")
    private String referencedTable = "";

    @Column(name = "referenced_column")
    private String referencedColumn = "";

    @Column(name = "relationships")
    private String relationships = "";

    @Column(name = "relationship_description", length = 2000)
    private String relationshipDescription = "";

    @Column(name = "cardinality_rules", length = 2000)
    private String cardinalityRules = "";

    @Column(name = "entity_purpose", length = 2000)
    private String entityPurpose = "";

    @Column(name = "business_rules", length = 2000)
    private String businessRules = "";

    @Column(name = "validation_rules", length = 2000)
    private String validationRules = "";

    @Column(name = "data_integrity_rules", length = 2000)
    private String dataIntegrityRules = "";

    @Column(name = "methods")
    private String methods = "";

    @Column(name = "method_descriptions", length = 2000)
    private String methodDescriptions = "";

    @Column(name = "crud_supported")
    private Boolean crudSupported = false;

    @Column(name = "indexing_strategy")
    private String indexingStrategy = "";

    @Column(name = "database_schema_name")
    private String databaseSchemaName = "";

    @Column(name = "estimated_record_volume")
    private Integer estimatedRecordVolume = 0;

    @Column(name = "unique_constraints", length = 2000)
    private String uniqueConstraints = "";

    @Column(name = "check_constraints", length = 2000)
    private String checkConstraints = "";

    @Column(name = "tablespace_storage_details", length = 2000)
    private String tablespaceStorageDetails = "";

    @Column(name = "orm_framework")
    private String ormFramework = "";

    @Column(name = "entity_mapping_strategy")
    private String entityMappingStrategy = "";

    @Column(name = "cascade_operations")
    private String cascadeOperations = "";

    @Column(name = "audit_columns_required")
    private Boolean auditColumnsRequired = false;

    @Column(name = "soft_delete_supported")
    private Boolean softDeleteSupported = false;

    @Column(name = "security_requirements", length = 2000)
    private String securityRequirements = "";

    @Column(name = "design_notes", length = 2000)
    private String designNotes = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTableClassId() { return tableClassId; }
    public void setTableClassId(String tableClassId) { this.tableClassId = tableClassId; }

    public String getTableClassName() { return tableClassName; }
    public void setTableClassName(String tableClassName) { this.tableClassName = tableClassName; }

    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) { this.entityType = entityType; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAttributesColumns() { return attributesColumns; }
    public void setAttributesColumns(String attributesColumns) { this.attributesColumns = attributesColumns; }

    public String getDataTypes() { return dataTypes; }
    public void setDataTypes(String dataTypes) { this.dataTypes = dataTypes; }

    public String getColumnConstraints() { return columnConstraints; }
    public void setColumnConstraints(String columnConstraints) { this.columnConstraints = columnConstraints; }

    public String getDefaultValues() { return defaultValues; }
    public void setDefaultValues(String defaultValues) { this.defaultValues = defaultValues; }

    public String getNullableFields() { return nullableFields; }
    public void setNullableFields(String nullableFields) { this.nullableFields = nullableFields; }

    public String getPrimaryKeyType() { return primaryKeyType; }
    public void setPrimaryKeyType(String primaryKeyType) { this.primaryKeyType = primaryKeyType; }

    public String getPrimaryKeyColumn() { return primaryKeyColumn; }
    public void setPrimaryKeyColumn(String primaryKeyColumn) { this.primaryKeyColumn = primaryKeyColumn; }

    public String getCompositeKeyDetails() { return compositeKeyDetails; }
    public void setCompositeKeyDetails(String compositeKeyDetails) { this.compositeKeyDetails = compositeKeyDetails; }

    public Boolean getHasForeignKey() { return hasForeignKey; }
    public void setHasForeignKey(Boolean hasForeignKey) { this.hasForeignKey = hasForeignKey; }

    public String getForeignKeyDetails() { return foreignKeyDetails; }
    public void setForeignKeyDetails(String foreignKeyDetails) { this.foreignKeyDetails = foreignKeyDetails; }

    public String getReferencedTable() { return referencedTable; }
    public void setReferencedTable(String referencedTable) { this.referencedTable = referencedTable; }

    public String getReferencedColumn() { return referencedColumn; }
    public void setReferencedColumn(String referencedColumn) { this.referencedColumn = referencedColumn; }

    public String getRelationships() { return relationships; }
    public void setRelationships(String relationships) { this.relationships = relationships; }

    public String getRelationshipDescription() { return relationshipDescription; }
    public void setRelationshipDescription(String relationshipDescription) { this.relationshipDescription = relationshipDescription; }

    public String getCardinalityRules() { return cardinalityRules; }
    public void setCardinalityRules(String cardinalityRules) { this.cardinalityRules = cardinalityRules; }

    public String getEntityPurpose() { return entityPurpose; }
    public void setEntityPurpose(String entityPurpose) { this.entityPurpose = entityPurpose; }

    public String getBusinessRules() { return businessRules; }
    public void setBusinessRules(String businessRules) { this.businessRules = businessRules; }

    public String getValidationRules() { return validationRules; }
    public void setValidationRules(String validationRules) { this.validationRules = validationRules; }

    public String getDataIntegrityRules() { return dataIntegrityRules; }
    public void setDataIntegrityRules(String dataIntegrityRules) { this.dataIntegrityRules = dataIntegrityRules; }

    public String getMethods() { return methods; }
    public void setMethods(String methods) { this.methods = methods; }

    public String getMethodDescriptions() { return methodDescriptions; }
    public void setMethodDescriptions(String methodDescriptions) { this.methodDescriptions = methodDescriptions; }

    public Boolean getCrudSupported() { return crudSupported; }
    public void setCrudSupported(Boolean crudSupported) { this.crudSupported = crudSupported; }

    public String getIndexingStrategy() { return indexingStrategy; }
    public void setIndexingStrategy(String indexingStrategy) { this.indexingStrategy = indexingStrategy; }

    public String getDatabaseSchemaName() { return databaseSchemaName; }
    public void setDatabaseSchemaName(String databaseSchemaName) { this.databaseSchemaName = databaseSchemaName; }

    public Integer getEstimatedRecordVolume() { return estimatedRecordVolume; }
    public void setEstimatedRecordVolume(Integer estimatedRecordVolume) { this.estimatedRecordVolume = estimatedRecordVolume; }

    public String getUniqueConstraints() { return uniqueConstraints; }
    public void setUniqueConstraints(String uniqueConstraints) { this.uniqueConstraints = uniqueConstraints; }

    public String getCheckConstraints() { return checkConstraints; }
    public void setCheckConstraints(String checkConstraints) { this.checkConstraints = checkConstraints; }

    public String getTablespaceStorageDetails() { return tablespaceStorageDetails; }
    public void setTablespaceStorageDetails(String tablespaceStorageDetails) { this.tablespaceStorageDetails = tablespaceStorageDetails; }

    public String getOrmFramework() { return ormFramework; }
    public void setOrmFramework(String ormFramework) { this.ormFramework = ormFramework; }

    public String getEntityMappingStrategy() { return entityMappingStrategy; }
    public void setEntityMappingStrategy(String entityMappingStrategy) { this.entityMappingStrategy = entityMappingStrategy; }

    public String getCascadeOperations() { return cascadeOperations; }
    public void setCascadeOperations(String cascadeOperations) { this.cascadeOperations = cascadeOperations; }

    public Boolean getAuditColumnsRequired() { return auditColumnsRequired; }
    public void setAuditColumnsRequired(Boolean auditColumnsRequired) { this.auditColumnsRequired = auditColumnsRequired; }

    public Boolean getSoftDeleteSupported() { return softDeleteSupported; }
    public void setSoftDeleteSupported(Boolean softDeleteSupported) { this.softDeleteSupported = softDeleteSupported; }

    public String getSecurityRequirements() { return securityRequirements; }
    public void setSecurityRequirements(String securityRequirements) { this.securityRequirements = securityRequirements; }

    public String getDesignNotes() { return designNotes; }
    public void setDesignNotes(String designNotes) { this.designNotes = designNotes; }
}