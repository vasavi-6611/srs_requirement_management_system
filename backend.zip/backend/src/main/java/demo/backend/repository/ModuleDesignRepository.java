package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.ModuleDesign;

@Repository
public interface ModuleDesignRepository extends JpaRepository<ModuleDesign, Long> {
}