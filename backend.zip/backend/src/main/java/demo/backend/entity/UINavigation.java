package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "ui_navigation")
public class UINavigation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "navigation_id")
    private String navigationId = "";

    @Column(name = "navigation_name")
    private String navigationName = "";

    @Column(name = "navigation_path")
    private String navigationPath = "";

    @Column(name = "navigation_category")
    private String navigationCategory = "";

    @Column(name = "navigation_type")
    private String navigationType = "";

    @Column(name = "navigation_status")
    private String navigationStatus = "";

    @Lob
    @Column(name = "navigation_description")
    private String navigationDescription = "";

    @Column(name = "navigation_label")
    private String navigationLabel = "";

    @Column(name = "icon_class")
    private String iconClass = "";

    @Column(name = "target_window")
    private String targetWindow = "_self";

    @Column(name = "display_order")
    private String displayOrder = "";

    @Column(name = "parent_navigation_id")
    private String parentNavigationId = "";

    @Column(name = "rbac_roles_allowed")
    private String rbacRolesAllowed = "";

    @Column(name = "feature_flags_required")
    private String featureFlagsRequired = "";

    @Column(name = "responsive_visibility")
    private String responsiveVisibility = "";

    @Column(name = "related_route_component")
    private String relatedRouteComponent = "";

    @Lob
    @Column(name = "url_parameters")
    private String urlParameters = "";

    @Lob
    @Column(name = "query_parameters")
    private String queryParameters = "";

    @Column(name = "bread_crumb_label")
    private String breadCrumbLabel = "";

    @Column(name = "analytics_event_name")
    private String analyticsEventName = "";

    @Column(name = "is_external_link")
    private Boolean isExternalLink = false;

    @Column(name = "requires_authentication")
    private Boolean requiresAuthentication = true;

    @Column(name = "requires_subscription")
    private Boolean requiresSubscription = false;

    @Column(name = "badge_text")
    private String badgeText = "";

    @Column(name = "badge_color")
    private String badgeColor = "";

    @Column(name = "localization_key")
    private String localizationKey = "";

    @Lob
    @Column(name = "assumptions")
    private String assumptions = "";

    @Lob
    @Column(name = "\"constraints\"")
    private String constraints = "";

    @Lob
    @Column(name = "design_notes")
    private String designNotes = "";

    @Column(name = "supporting_documents_name")
    private String supportingDocumentsName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNavigationId() { return navigationId; }
    public void setNavigationId(String navigationId) { this.navigationId = navigationId; }

    public String getNavigationName() { return navigationName; }
    public void setNavigationName(String navigationName) { this.navigationName = navigationName; }

    public String getNavigationPath() { return navigationPath; }
    public void setNavigationPath(String navigationPath) { this.navigationPath = navigationPath; }

    public String getNavigationCategory() { return navigationCategory; }
    public void setNavigationCategory(String navigationCategory) { this.navigationCategory = navigationCategory; }

    public String getNavigationType() { return navigationType; }
    public void setNavigationType(String navigationType) { this.navigationType = navigationType; }

    public String getNavigationStatus() { return navigationStatus; }
    public void setNavigationStatus(String navigationStatus) { this.navigationStatus = navigationStatus; }

    public String getNavigationDescription() { return navigationDescription; }
    public void setNavigationDescription(String navigationDescription) { this.navigationDescription = navigationDescription; }

    public String getNavigationLabel() { return navigationLabel; }
    public void setNavigationLabel(String navigationLabel) { this.navigationLabel = navigationLabel; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getTargetWindow() { return targetWindow; }
    public void setTargetWindow(String targetWindow) { this.targetWindow = targetWindow; }

    public String getDisplayOrder() { return displayOrder; }
    public void setDisplayOrder(String displayOrder) { this.displayOrder = displayOrder; }

    public String getParentNavigationId() { return parentNavigationId; }
    public void setParentNavigationId(String parentNavigationId) { this.parentNavigationId = parentNavigationId; }

    public String getRbacRolesAllowed() { return rbacRolesAllowed; }
    public void setRbacRolesAllowed(String rbacRolesAllowed) { this.rbacRolesAllowed = rbacRolesAllowed; }

    public String getFeatureFlagsRequired() { return featureFlagsRequired; }
    public void setFeatureFlagsRequired(String featureFlagsRequired) { this.featureFlagsRequired = featureFlagsRequired; }

    public String getResponsiveVisibility() { return responsiveVisibility; }
    public void setResponsiveVisibility(String responsiveVisibility) { this.responsiveVisibility = responsiveVisibility; }

    public String getRelatedRouteComponent() { return relatedRouteComponent; }
    public void setRelatedRouteComponent(String relatedRouteComponent) { this.relatedRouteComponent = relatedRouteComponent; }

    public String getUrlParameters() { return urlParameters; }
    public void setUrlParameters(String urlParameters) { this.urlParameters = urlParameters; }

    public String getQueryParameters() { return queryParameters; }
    public void setQueryParameters(String queryParameters) { this.queryParameters = queryParameters; }

    public String getBreadCrumbLabel() { return breadCrumbLabel; }
    public void setBreadCrumbLabel(String breadCrumbLabel) { this.breadCrumbLabel = breadCrumbLabel; }

    public String getAnalyticsEventName() { return analyticsEventName; }
    public void setAnalyticsEventName(String analyticsEventName) { this.analyticsEventName = analyticsEventName; }

    public Boolean getIsExternalLink() { return isExternalLink; }
    public void setIsExternalLink(Boolean isExternalLink) { this.isExternalLink = isExternalLink; }

    public Boolean getRequiresAuthentication() { return requiresAuthentication; }
    public void setRequiresAuthentication(Boolean requiresAuthentication) { this.requiresAuthentication = requiresAuthentication; }

    public Boolean getRequiresSubscription() { return requiresSubscription; }
    public void setRequiresSubscription(Boolean requiresSubscription) { this.requiresSubscription = requiresSubscription; }

    public String getBadgeText() { return badgeText; }
    public void setBadgeText(String badgeText) { this.badgeText = badgeText; }

    public String getBadgeColor() { return badgeColor; }
    public void setBadgeColor(String badgeColor) { this.badgeColor = badgeColor; }

    public String getLocalizationKey() { return localizationKey; }
    public void setLocalizationKey(String localizationKey) { this.localizationKey = localizationKey; }

    public String getAssumptions() { return assumptions; }
    public void setAssumptions(String assumptions) { this.assumptions = assumptions; }

    public String getConstraints() { return constraints; }
    public void setConstraints(String constraints) { this.constraints = constraints; }

    public String getDesignNotes() { return designNotes; }
    public void setDesignNotes(String designNotes) { this.designNotes = designNotes; }

    public String getSupportingDocumentsName() { return supportingDocumentsName; }
    public void setSupportingDocumentsName(String supportingDocumentsName) { this.supportingDocumentsName = supportingDocumentsName; }
}