package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "system_architectures")
public class SystemArchitecture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "architecture_id")
    private String architectureId = "";

    @Column(name = "architecture_name")
    private String architectureName = "";

    @Column(name = "architecture_version")
    private String architectureVersion = "1.0";

    @Column(name = "architecture_type")
    private String architectureType = "MICROSERVICES";

    @Column(name = "architecture_description", length = 2500)
    private String architectureDescription = "";

    @Column(name = "architecture_objectives", length = 2500)
    private String architectureObjectives = "";

    @Column(name = "design_principles", length = 2500)
    private String designPrinciples = "";

    @Column(name = "business_goals_supported", length = 2500)
    private String businessGoalsSupported = "";

    @Column(name = "quality_attributes", length = 2500)
    private String qualityAttributes = "";

    @Column(name = "design_constraints", length = 2500)
    private String designConstraints = "";

    @Column(name = "core_components")
    private String coreComponents = "";

    @Column(name = "component_responsibilities", length = 2500)
    private String componentResponsibilities = "";

    @Column(name = "component_interactions", length = 2500)
    private String componentInteractions = "";

    @Column(name = "component_dependencies", length = 2500)
    private String componentDependencies = "";

    @Column(name = "external_components", length = 2500)
    private String externalComponents = "";

    @Column(name = "presentation_layer_description", length = 2500)
    private String presentationLayerDescription = "";

    @Column(name = "business_layer_description", length = 2500)
    private String businessLayerDescription = "";

    @Column(name = "data_access_layer_description", length = 2500)
    private String dataAccessLayerDescription = "";

    @Column(name = "integration_layer_description", length = 2500)
    private String integrationLayerDescription = "";

    @Column(name = "communication_protocols")
    private String communicationProtocols = "";

    @Column(name = "communication_interfaces", length = 2500)
    private String communicationInterfaces = "";

    @Column(name = "api_gateway_required")
    private Boolean apiGatewayRequired = false;

    @Column(name = "message_queue_required")
    private Boolean messageQueueRequired = false;

    @Column(name = "service_discovery_required")
    private Boolean serviceDiscoveryRequired = false;

    @Column(name = "deployment_model")
    private String deploymentModel = "";

    @Column(name = "hosting_environment")
    private String hostingEnvironment = "";

    @Column(name = "cloud_provider")
    private String cloudProvider = "";

    @Column(name = "containerization_strategy")
    private String containerizationStrategy = "";

    @Column(name = "load_balancer_required")
    private Boolean loadBalancerRequired = false;

    @Column(name = "authentication_architecture")
    private String authenticationArchitecture = "";

    @Column(name = "authorization_architecture")
    private String authorizationArchitecture = "";

    @Column(name = "is_https_secure")
    private Boolean isHttpsSecure = true;

    @Column(name = "encryption_strategy", length = 2500)
    private String encryptionStrategy = "";

    @Column(name = "audit_logging_strategy", length = 2500)
    private String auditLoggingStrategy = "";

    @Column(name = "scalability_strategy", length = 2500)
    private String scalabilityStrategy = "";

    @Column(name = "high_availability_strategy", length = 2500)
    private String highAvailabilityStrategy = "";

    @Column(name = "fault_tolerance_strategy", length = 2500)
    private String faultToleranceStrategy = "";

    @Column(name = "performance_targets", length = 2500)
    private String performanceTargets = "";

    @Column(name = "architecture_diagram_name")
    private String architectureDiagramName = "";

    @Column(name = "additional_notes", length = 2500)
    private String additionalNotes = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getArchitectureId() { return architectureId; }
    public void setArchitectureId(String architectureId) { this.architectureId = architectureId; }

    public String getArchitectureName() { return architectureName; }
    public void setArchitectureName(String architectureName) { this.architectureName = architectureName; }

    public String getArchitectureVersion() { return architectureVersion; }
    public void setArchitectureVersion(String architectureVersion) { this.architectureVersion = architectureVersion; }

    public String getArchitectureType() { return architectureType; }
    public void setArchitectureType(String architectureType) { this.architectureType = architectureType; }

    public String getArchitectureDescription() { return architectureDescription; }
    public void setArchitectureDescription(String architectureDescription) { this.architectureDescription = architectureDescription; }

    public String getArchitectureObjectives() { return architectureObjectives; }
    public void setArchitectureObjectives(String architectureObjectives) { this.architectureObjectives = architectureObjectives; }

    public String getDesignPrinciples() { return designPrinciples; }
    public void setDesignPrinciples(String designPrinciples) { this.designPrinciples = designPrinciples; }

    public String getBusinessGoalsSupported() { return businessGoalsSupported; }
    public void setBusinessGoalsSupported(String businessGoalsSupported) { this.businessGoalsSupported = businessGoalsSupported; }

    public String getQualityAttributes() { return qualityAttributes; }
    public void setQualityAttributes(String qualityAttributes) { this.qualityAttributes = qualityAttributes; }

    public String getDesignConstraints() { return designConstraints; }
    public void setDesignConstraints(String designConstraints) { this.designConstraints = designConstraints; }

    public String getCoreComponents() { return coreComponents; }
    public void setCoreComponents(String coreComponents) { this.coreComponents = coreComponents; }

    public String getComponentResponsibilities() { return componentResponsibilities; }
    public void setComponentResponsibilities(String componentResponsibilities) { this.componentResponsibilities = componentResponsibilities; }

    public String getComponentInteractions() { return componentInteractions; }
    public void setComponentInteractions(String componentInteractions) { this.componentInteractions = componentInteractions; }

    public String getComponentDependencies() { return componentDependencies; }
    public void setComponentDependencies(String componentDependencies) { this.componentDependencies = componentDependencies; }

    public String getExternalComponents() { return externalComponents; }
    public void setExternalComponents(String externalComponents) { this.externalComponents = externalComponents; }

    public String getPresentationLayerDescription() { return presentationLayerDescription; }
    public void setPresentationLayerDescription(String presentationLayerDescription) { this.presentationLayerDescription = presentationLayerDescription; }

    public String getBusinessLayerDescription() { return businessLayerDescription; }
    public void setBusinessLayerDescription(String businessLayerDescription) { this.businessLayerDescription = businessLayerDescription; }

    public String getDataAccessLayerDescription() { return dataAccessLayerDescription; }
    public void setDataAccessLayerDescription(String dataAccessLayerDescription) { this.dataAccessLayerDescription = dataAccessLayerDescription; }

    public String getIntegrationLayerDescription() { return integrationLayerDescription; }
    public void setIntegrationLayerDescription(String integrationLayerDescription) { this.integrationLayerDescription = integrationLayerDescription; }

    public String getCommunicationProtocols() { return communicationProtocols; }
    public void setCommunicationProtocols(String communicationProtocols) { this.communicationProtocols = communicationProtocols; }

    public String getCommunicationInterfaces() { return communicationInterfaces; }
    public void setCommunicationInterfaces(String communicationInterfaces) { this.communicationInterfaces = communicationInterfaces; }

    public Boolean getApiGatewayRequired() { return apiGatewayRequired; }
    public void setApiGatewayRequired(Boolean apiGatewayRequired) { this.apiGatewayRequired = apiGatewayRequired; }

    public Boolean getMessageQueueRequired() { return messageQueueRequired; }
    public void setMessageQueueRequired(Boolean messageQueueRequired) { this.messageQueueRequired = messageQueueRequired; }

    public Boolean getServiceDiscoveryRequired() { return serviceDiscoveryRequired; }
    public void setServiceDiscoveryRequired(Boolean serviceDiscoveryRequired) { this.serviceDiscoveryRequired = serviceDiscoveryRequired; }

    public String getDeploymentModel() { return deploymentModel; }
    public void setDeploymentModel(String deploymentModel) { this.deploymentModel = deploymentModel; }

    public String getHostingEnvironment() { return hostingEnvironment; }
    public void setHostingEnvironment(String hostingEnvironment) { this.hostingEnvironment = hostingEnvironment; }

    public String getCloudProvider() { return cloudProvider; }
    public void setCloudProvider(String cloudProvider) { this.cloudProvider = cloudProvider; }

    public String getContainerizationStrategy() { return containerizationStrategy; }
    public void setContainerizationStrategy(String containerizationStrategy) { this.containerizationStrategy = containerizationStrategy; }

    public Boolean getLoadBalancerRequired() { return loadBalancerRequired; }
    public void setLoadBalancerRequired(Boolean loadBalancerRequired) { this.loadBalancerRequired = loadBalancerRequired; }

    public String getAuthenticationArchitecture() { return authenticationArchitecture; }
    public void setAuthenticationArchitecture(String authenticationArchitecture) { this.authenticationArchitecture = authenticationArchitecture; }

    public String getAuthorizationArchitecture() { return authorizationArchitecture; }
    public void setAuthorizationArchitecture(String authorizationArchitecture) { this.authorizationArchitecture = authorizationArchitecture; }

    public Boolean getIsHttpsSecure() { return isHttpsSecure; }
    public void setIsHttpsSecure(Boolean isHttpsSecure) { this.isHttpsSecure = isHttpsSecure; }

    public String getEncryptionStrategy() { return encryptionStrategy; }
    public void setEncryptionStrategy(String encryptionStrategy) { this.encryptionStrategy = encryptionStrategy; }

    public String getAuditLoggingStrategy() { return auditLoggingStrategy; }
    public void setAuditLoggingStrategy(String auditLoggingStrategy) { this.auditLoggingStrategy = auditLoggingStrategy; }

    public String getScalabilityStrategy() { return scalabilityStrategy; }
    public void setScalabilityStrategy(String scalabilityStrategy) { this.scalabilityStrategy = scalabilityStrategy; }

    public String getHighAvailabilityStrategy() { return highAvailabilityStrategy; }
    public void setHighAvailabilityStrategy(String highAvailabilityStrategy) { this.highAvailabilityStrategy = highAvailabilityStrategy; }

    public String getFaultToleranceStrategy() { return faultToleranceStrategy; }
    public void setFaultToleranceStrategy(String faultToleranceStrategy) { this.faultToleranceStrategy = faultToleranceStrategy; }

    public String getPerformanceTargets() { return performanceTargets; }
    public void setPerformanceTargets(String performanceTargets) { this.performanceTargets = performanceTargets; }

    public String getArchitectureDiagramName() { return architectureDiagramName; }
    public void setArchitectureDiagramName(String architectureDiagramName) { this.architectureDiagramName = architectureDiagramName; }

    public String getAdditionalNotes() { return additionalNotes; }
    public void setAdditionalNotes(String additionalNotes) { this.additionalNotes = additionalNotes; }
}