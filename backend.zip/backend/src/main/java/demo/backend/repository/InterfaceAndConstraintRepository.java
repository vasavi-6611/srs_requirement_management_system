package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.InterfaceAndConstraint;

@Repository
public interface InterfaceAndConstraintRepository 
        extends JpaRepository<InterfaceAndConstraint, Long> {
}