import React from "react";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";

export default function CustomAvatar({
  avatars = [],
  direction = "row",
  spacing = 2,
}) {
  return (
    <Stack direction={direction} spacing={spacing}>
      {avatars.map((avatar, index) => (
        <Avatar
          key={index}
          alt={avatar.alt}
          src={avatar.src}
        />
      ))}
    </Stack>
  );
}