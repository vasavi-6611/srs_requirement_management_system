package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.AutomationUnitTest;
import demo.backend.repository.AutomationUnitTestRepository;

@RestController
@RequestMapping("/api/automation-unit-tests")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class AutomationUnitTestController {

    @Autowired
    private AutomationUnitTestRepository repository;

    @GetMapping({"", "/"})
    public List<AutomationUnitTest> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AutomationUnitTest> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<AutomationUnitTest> saveRecord(@RequestBody AutomationUnitTest record) {
        AutomationUnitTest saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AutomationUnitTest> updateRecord(@PathVariable Long id, @RequestBody AutomationUnitTest details) {
        return repository.findById(id).map(record -> {
            record.setTestCaseId(details.getTestCaseId());
            record.setTestCaseName(details.getTestCaseName());
            record.setTargetClassOrMethod(details.getTargetClassOrMethod());
            record.setTestingFramework(details.getTestingFramework());
            record.setAssertionStrategy(details.getAssertionStrategy());
            record.setTestStatus(details.getTestStatus());
            record.setTestDescription(details.getTestDescription());
            record.setExecutionRunnerEnv(details.getExecutionRunnerEnv());
            record.setAssignedDeveloper(details.getAssignedDeveloper());
            record.setTimeoutThresholdMs(details.getTimeoutThresholdMs());
            record.setAssociatedUserStoryId(details.getAssociatedUserStoryId());
            record.setMockedDependencies(details.getMockedDependencies());
            record.setFixturesRequired(details.getFixturesRequired());
            record.setCodeCoverageTargetPct(details.getCodeCoverageTargetPct());
            record.setExpectedExceptionPattern(details.getExpectedExceptionPattern());
            record.setInputArgumentsMockup(details.getInputArgumentsMockup());
            record.setOutputResultMockup(details.getOutputResultMockup());
            record.setIsFlakyTest(details.getIsFlakyTest());
            record.setRequiresDatabaseSandbox(details.getRequiresDatabaseSandbox());
            record.setRequiresNetworkIsolation(details.getRequiresNetworkIsolation());
            record.setMemoryFootprintLimitMb(details.getMemoryFootprintLimitMb());
            record.setLogSeverityFilter(details.getLogSeverityFilter());
            record.setJiraIssueKey(details.getJiraIssueKey());
            record.setPreconditions(details.getPreconditions());
            record.setSideEffects(details.getSideEffects());
            record.setRefactoringNotes(details.getRefactoringNotes());
            record.setTestArtifactName(details.getTestArtifactName());

            AutomationUnitTest updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}