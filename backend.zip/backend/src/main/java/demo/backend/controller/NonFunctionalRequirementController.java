package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.NonFunctionalRequirement;
import demo.backend.repository.NonFunctionalRequirementRepository;

@RestController
@RequestMapping("/api/nfr")
@CrossOrigin(origins = {"*"})
public class NonFunctionalRequirementController {

    @Autowired
    private NonFunctionalRequirementRepository repository;

    @GetMapping
    public List<NonFunctionalRequirement> getAllNFRs() {
        return repository.findAll();
    }

    @PostMapping({"", "/"})
    public ResponseEntity<NonFunctionalRequirement> saveNFR(@RequestBody NonFunctionalRequirement nfr) {
        NonFunctionalRequirement saved = repository.save(nfr);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<NonFunctionalRequirement> updateNFR(@PathVariable Long id, @RequestBody NonFunctionalRequirement nfrDetails) {
        return repository.findById(id).map(nfr -> {
            nfr.setPerformanceSpecs(nfrDetails.getPerformanceSpecs());
            nfr.setMaxResponseTime(nfrDetails.getMaxResponseTime());
            nfr.setAvgResponseTime(nfrDetails.getAvgResponseTime());
            nfr.setTransactionProcessingTime(nfrDetails.getTransactionProcessingTime());
            nfr.setMaxConcurrentUsers(nfrDetails.getMaxConcurrentUsers());
            nfr.setThroughputRequirements(nfrDetails.getThroughputRequirements());
            nfr.setPeakLoadCapacity(nfrDetails.getPeakLoadCapacity());
            nfr.setSecurityLevel(nfrDetails.getSecurityLevel());
            nfr.setAuthenticationMethod(nfrDetails.getAuthenticationMethod());
            nfr.setAuthorizationMethod(nfrDetails.getAuthorizationMethod());
            nfr.setPasswordPolicy(nfrDetails.getPasswordPolicy());
            nfr.setDataEncryptionRequired(nfrDetails.getDataEncryptionRequired());
            nfr.setAuditLoggingRequired(nfrDetails.getAuditLoggingRequired());
            nfr.setSessionTimeoutDuration(nfrDetails.getSessionTimeoutDuration());
            nfr.setAvailabilityPercentage(nfrDetails.getAvailabilityPercentage());
            nfr.setMaintenanceWindow(nfrDetails.getMaintenanceWindow());
            nfr.setDisasterRecoveryTime(nfrDetails.getDisasterRecoveryTime());
            nfr.setRpo(nfrDetails.getRpo());
            nfr.setRto(nfrDetails.getRto());
            nfr.setBackupReliability(nfrDetails.getBackupReliability());
            nfr.setFaultToleranceLevel(nfrDetails.getFaultToleranceLevel());
            nfr.setDataIntegrityRequirements(nfrDetails.getDataIntegrityRequirements());
            nfr.setSystemStabilityRequirements(nfrDetails.getSystemStabilityRequirements());
            nfr.setFutureUserGrowthExpectation(nfrDetails.getFutureUserGrowthExpectation());
            nfr.setStorageScalabilityRequirement(nfrDetails.getStorageScalabilityRequirement());
            nfr.setHorizontalScalingSupportRequired(nfrDetails.getHorizontalScalingSupportRequired());
            nfr.setEaseOfUseLevel(nfrDetails.getEaseOfUseLevel());
            nfr.setUserTrainingRequirement(nfrDetails.getUserTrainingRequirement());
            nfr.setAccessibilityCompliance(nfrDetails.getAccessibilityCompliance());
            nfr.setSupportedLanguages(nfrDetails.getSupportedLanguages());
            nfr.setSupportedBrowsers(nfrDetails.getSupportedBrowsers());
            nfr.setSupportedOperatingSystems(nfrDetails.getSupportedOperatingSystems());
            nfr.setMobileDeviceSupport(nfrDetails.getMobileDeviceSupport());
            nfr.setThirdPartyIntegrationSupport(nfrDetails.getThirdPartyIntegrationSupport());
            nfr.setCodeMaintainabilityLevel(nfrDetails.getCodeMaintainabilityLevel());
            nfr.setDocumentationRequirement(nfrDetails.getDocumentationRequirement());
            nfr.setMonitoringRequirement(nfrDetails.getMonitoringRequirement());
            nfr.setLoggingRequirement(nfrDetails.getLoggingRequirement());
            nfr.setRegulatoryCompliance(nfrDetails.getRegulatoryCompliance());
            nfr.setIndustryStandardsCompliance(nfrDetails.getIndustryStandardsCompliance());

            NonFunctionalRequirement updated = repository.save(nfr);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNFR(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}