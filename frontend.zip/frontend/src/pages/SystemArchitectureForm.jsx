import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function SystemArchitectureForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [architectureList, setArchitectureList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedArch, setSelectedArch] = useState(null);

  const emptyForm = {
    architectureId: "",
    architectureName: "",
    architectureVersion: "1.0",
    architectureType: "MICROSERVICES",
    architectureDescription: "",
    architectureObjectives: "",
    designPrinciples: "",
    businessGoalsSupported: "",
    qualityAttributes: "",
    designConstraints: "",
    coreComponents: "",
    componentResponsibilities: "",
    componentInteractions: "",
    componentDependencies: "",
    externalComponents: "",
    presentationLayerDescription: "",
    businessLayerDescription: "",
    dataAccessLayerDescription: "",
    integrationLayerDescription: "",
    communicationProtocols: "",
    communicationInterfaces: "",
    apiGatewayRequired: false,
    messageQueueRequired: false,
    serviceDiscoveryRequired: false,
    deploymentModel: "",
    hostingEnvironment: "",
    cloudProvider: "",
    containerizationStrategy: "",
    loadBalancerRequired: false,
    authenticationArchitecture: "",
    authorizationArchitecture: "",
    isHttpsSecure: true,
    encryptionStrategy: "",
    auditLoggingStrategy: "",
    scalabilityStrategy: "",
    highAvailabilityStrategy: "",
    faultToleranceStrategy: "",
    performanceTargets: "",
    architectureDiagramName: "",
    additionalNotes: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchArchitectureRecords();
  }, []);

  const fetchArchitectureRecords = async () => {
    try {
      const response = await api.get("/api/architecture");
      setArchitectureList(response.data || []);
    } catch (error) {
      console.error("Error fetching system architecture registry:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, event) => {
    const file = event.target.files?.[0];
    if (file) {
      handleChange(field, file.name);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedArch(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      console.log("Sending System Architecture Payload:", formData);
      if (isEditing) {
        await api.put(`/api/architecture/${formData.id}`, formData);
        alert("System Architecture Design Blueprint Updated Successfully!");
      } else {
        await api.post("/api/architecture", formData);
        alert("System Architecture Information Saved Successfully!");
      }
      fetchArchitectureRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Architecture Topology Details.");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this system architecture configuration profile?")) {
      try {
        await api.delete(`/api/architecture/${id}`);
        alert("Architecture Schema Entry Dropped Successfully!");
        fetchArchitectureRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entity mapping.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = ["1. Profile & Components", "2. Interface Layers & Infra", "3. Security & Scalability"];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              System Architecture
            </h2>
            <CustomButton text="+ Design New System Setup" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Architecture ID</th>
                <th style={{ padding: "14px" }}>Topology Name</th>
                <th style={{ padding: "14px" }}>Release Version</th>
                <th style={{ padding: "14px" }}>Framework Paradigm</th>
                <th style={{ padding: "14px" }}>Cloud Infrastructure</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {architectureList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No system blueprints found. Configure an architectural design baseline instance.</td>
                </tr>
              ) : (
                architectureList.map((arch, index) => (
                  <tr key={arch.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0284c7" }}>{arch.architectureId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{arch.architectureName || "Unnamed Architecture"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px" }}>{arch.architectureVersion || "—"}</span></td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#eff6ff", color: "#2563eb", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{arch.architectureType}</span></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{arch.cloudProvider || "N/A"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(arch)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Blueprint</button>
                        <button onClick={() => handleEditClick(arch)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(arch.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container architecture-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>System Architecture Designs</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="Architecture ID" fullWidth={true} value={formData.architectureId} onChange={(e) => handleChange("architectureId", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Architecture Name" fullWidth={true} value={formData.architectureName} onChange={(e) => handleChange("architectureName", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomTextField label="Architecture Version" fullWidth={true} value={formData.architectureVersion} onChange={(e) => handleChange("architectureVersion", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomAutocomplete label="Core Components Selection" width="100%" value={formData.coreComponents} onChange={(newValue) => handleChange("coreComponents", newValue)} options={["React Web Client Frontend", "Spring Boot Backend Api Gateway", "Oracle Relational Database Engine Instance", "Kafka Message Streaming Broker"]} /></div>
                <div style={fullWidthItem}>
                  <CustomRadioGroup label="Architecture Paradigm Design Framework" row={true} value={formData.architectureType} onChange={(e) => handleChange("architectureType", e.target.value)}
                    options={[
                      { label: "Monolithic Architecture (Single Package)", value: "MONOLITHIC" },
                      { label: "Microservices Framework (Distributed Services)", value: "MICROSERVICES" },
                      { label: "Event-Driven Layout (Kafka Streams Pipeline)", value: "EVENT_DRIVEN" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Architecture Description" value={formData.architectureDescription} onChange={(e) => handleChange("architectureDescription", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Architecture Objectives" value={formData.architectureObjectives} onChange={(e) => handleChange("architectureObjectives", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Design Principles" value={formData.designPrinciples} onChange={(e) => handleChange("designPrinciples", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Business Goals Supported" value={formData.businessGoalsSupported} onChange={(e) => handleChange("businessGoalsSupported", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Component Responsibilities" value={formData.componentResponsibilities} onChange={(e) => handleChange("componentResponsibilities", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Component Interactions" value={formData.componentInteractions} onChange={(e) => handleChange("componentInteractions", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Component Dependencies" value={formData.componentDependencies} onChange={(e) => handleChange("componentDependencies", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="External Components" value={formData.externalComponents} onChange={(e) => handleChange("externalComponents", e.target.value)} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={fullWidthItem}><CustomTextarea label="Presentation Layer Description" value={formData.presentationLayerDescription} onChange={(e) => handleChange("presentationLayerDescription", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Business Layer Description" value={formData.businessLayerDescription} onChange={(e) => handleChange("businessLayerDescription", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Data Access Layer Description" value={formData.dataAccessLayerDescription} onChange={(e) => handleChange("dataAccessLayerDescription", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Integration Layer Description" value={formData.integrationLayerDescription} onChange={(e) => handleChange("integrationLayerDescription", e.target.value)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Communication Protocols" value={formData.communicationProtocols} onChange={(e) => handleChange("communicationProtocols", e.target.value)}
                    options={[
                      { label: "HTTP/2 RESTful State Channels", value: "HTTP_REST" },
                      { label: "gRPC Binary Stream Pipelines over HTTP/3", value: "GRPC" },
                      { label: "WebSocket Real-Time Full Duplex Links", value: "WEBSOCKET" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Deployment Model" value={formData.deploymentModel} onChange={(e) => handleChange("deploymentModel", e.target.value)}
                    options={[
                      { label: "Distributed Microservices Cluster Cloud Model", value: "CLOUD_DISTRIBUTED" },
                      { label: "On-Premises High Isolation Server Stack", value: "ON_PREM" },
                      { label: "Hybrid Bridge Mesh Deployment Structure", value: "HYBRID" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Hosting Environment" value={formData.hostingEnvironment} onChange={(e) => handleChange("hostingEnvironment", e.target.value)}
                    options={[
                      { label: "Serverless Container Computing Infrastructure", value: "SERVERLESS" },
                      { label: "Managed Kubernetes Cluster Nodes Group", value: "KUBERNETES" },
                      { label: "Dedicated Virtual Private Server Instances", value: "VPS" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Cloud Provider" value={formData.cloudProvider} onChange={(e) => handleChange("cloudProvider", e.target.value)}
                    options={[
                      { label: "Amazon Web Services (AWS Instance Group)", value: "AWS" },
                      { label: "Microsoft Azure Enterprise Cloud Suite", value: "AZURE" },
                      { label: "Google Cloud Platform Distributed Systems", value: "GCP" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Containerization Strategy" value={formData.containerizationStrategy} onChange={(e) => handleChange("containerizationStrategy", e.target.value)}
                    options={[
                      { label: "Docker Multi-Stage Core Image Assembly", value: "DOCKER" },
                      { label: "Podman Daemonless Secure Containers Group", value: "PODMAN" },
                      { label: "No Containerization Bare-Metal Direct Execution", value: "NONE" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Communication Interfaces" value={formData.communicationInterfaces} onChange={(e) => handleChange("communicationInterfaces", e.target.value)} /></div>
                <div style={{ ...fullWidthItem, display: "flex", flexWrap: "wrap", gap: "15px", padding: "10px 0" }}>
                  <CustomSwitch label="API Gateway Required (Reverse Proxy Routing)" checked={formData.apiGatewayRequired} onChange={(e) => handleChange("apiGatewayRequired", e.target.checked)} />
                  <CustomSwitch label="Message Queue Required (Asynchronous Event Broker)" checked={formData.messageQueueRequired} onChange={(e) => handleChange("messageQueueRequired", e.target.checked)} />
                  <CustomSwitch label="Service Discovery Registry Required (Eureka Dashboard)" checked={formData.serviceDiscoveryRequired} onChange={(e) => handleChange("serviceDiscoveryRequired", e.target.checked)} />
                  <CustomSwitch label="Load Balancer Required (Dynamic Ingress Traffic Steering)" checked={formData.loadBalancerRequired} onChange={(e) => handleChange("loadBalancerRequired", e.target.checked)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Authentication Architecture" value={formData.authenticationArchitecture} onChange={(e) => handleChange("authenticationArchitecture", e.target.value)}
                    options={[
                      { label: "Centralized OAuth2 Single Sign-On Server (SSO)", value: "OAUTH2_SSO" },
                      { label: "Stateless Symmetric Cryptographic JWT Bearer Tokens", value: "JWT_STATELESS" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Authorization Architecture" value={formData.authorizationArchitecture} onChange={(e) => handleChange("authorizationArchitecture", e.target.value)}
                    options={[
                      { label: "Role-Based Access Control (RBAC Permission Matrix)", value: "RBAC" },
                      { label: "Attribute-Based Dynamic Context Access Control (ABAC)", value: "ABAC" },
                    ]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="HTTPS Secure Communication Channels Enforced (TLS 1.3 Minimum)" checked={formData.isHttpsSecure} onChange={(e) => handleChange("isHttpsSecure", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Architecture Diagram Upload Repository Reference:</label>
                  <CustomFileUpload buttonText="Upload Architecture Diagram" fileName={formData.architectureDiagramName} onChange={(e) => handleFileChange("architectureDiagramName", e)} accept=".pdf,.png,.jpg,.jpeg" />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Quality Attributes" value={formData.qualityAttributes} onChange={(e) => handleChange("qualityAttributes", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Design Constraints" value={formData.designConstraints} onChange={(e) => handleChange("designConstraints", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Encryption Strategy" value={formData.encryptionStrategy} onChange={(e) => handleChange("encryptionStrategy", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Audit Logging Strategy" value={formData.auditLoggingStrategy} onChange={(e) => handleChange("auditLoggingStrategy", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Scalability Strategy" value={formData.scalabilityStrategy} onChange={(e) => handleChange("scalabilityStrategy", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="High Availability Strategy" value={formData.highAvailabilityStrategy} onChange={(e) => handleChange("highAvailabilityStrategy", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Fault Tolerance Strategy" value={formData.faultToleranceStrategy} onChange={(e) => handleChange("faultToleranceStrategy", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Performance Targets" value={formData.performanceTargets} onChange={(e) => handleChange("performanceTargets", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Additional Notes" value={formData.additionalNotes} onChange={(e) => handleChange("additionalNotes", e.target.value)} /></div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update System Architecture Blueprint" : "Save System Architecture Designs"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedArch && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Architecture System Blueprint Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Unique Database Identity Sequence Ref Key: ID-{selectedArch.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Baseline Structural Profile & Component Matrix</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Architecture ID" value={selectedArch.architectureId} />
            <DataField label="Architecture Name" value={selectedArch.architectureName} />
            <DataField label="Architecture Version" value={selectedArch.architectureVersion} />
            <DataField label="Paradigm Type Framework" value={selectedArch.architectureType} />
            <DataField label="Core Components Selection" value={selectedArch.coreComponents} />
            <DataField label="Uploaded Topology File Asset" value={selectedArch.architectureDiagramName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Architecture Description" value={selectedArch.architectureDescription} />
            <DataField label="Architecture Objectives" value={selectedArch.architectureObjectives} />
            <DataField label="Design Principles" value={selectedArch.designPrinciples} />
            <DataField label="Business Goals Supported" value={selectedArch.businessGoalsSupported} />
            <DataField label="Component Responsibilities" value={selectedArch.componentResponsibilities} />
            <DataField label="Component Interactions" value={selectedArch.componentInteractions} />
            <DataField label="Component Dependencies" value={selectedArch.componentDependencies} />
            <DataField label="External System Component Integration Map" value={selectedArch.externalComponents} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Modular Layers, Interface Engineering & Orchestration</h4>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "20px" }}>
            <DataField label="Presentation Layer Blueprint" value={selectedArch.presentationLayerDescription} />
            <DataField label="Business Layer Logic Flow" value={selectedArch.businessLayerDescription} />
            <DataField label="Data Access Layer Configuration Mapping" value={selectedArch.dataAccessLayerDescription} />
            <DataField label="Integration Layer Adaptors Description" value={selectedArch.integrationLayerDescription} />
            <DataField label="Communication Interfaces" value={selectedArch.communicationInterfaces} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Communication Protocols" value={selectedArch.communicationProtocols} />
            <DataField label="Deployment Model Strategy" value={selectedArch.deploymentModel} />
            <DataField label="Hosting Environment Structure" value={selectedArch.hostingEnvironment} />
            <DataField label="Cloud Provider Integration" value={selectedArch.cloudProvider} />
            <DataField label="Containerization Strategy Model" value={selectedArch.containerizationStrategy} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "16px", marginBottom: "30px" }}>
            <DataField label="Reverse Proxy Routing Gateway Required" value={selectedArch.apiGatewayRequired} />
            <DataField label="Message Queue Event Broker Required" value={selectedArch.messageQueueRequired} />
            <DataField label="Dynamic Service Registry Dashboard Required" value={selectedArch.serviceDiscoveryRequired} />
            <DataField label="Dynamic Ingress Load Balancing Required" value={selectedArch.loadBalancerRequired} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Security Standards, System Resilience & Infrastructure Targets</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Authentication Identity Scheme" value={selectedArch.authenticationArchitecture} />
            <DataField label="Authorization Matrix Control" value={selectedArch.authorizationArchitecture} />
            <DataField label="HTTPS Channels Enforced (TLS 1.3)" value={selectedArch.isHttpsSecure} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Cryptographic Encryption Strategy" value={selectedArch.encryptionStrategy} />
            <DataField label="Immutable Security Audit Logging Plan" value={selectedArch.auditLoggingStrategy} />
            <DataField label="Quality System Attributes Matrix" value={selectedArch.qualityAttributes} />
            <DataField label="Design Hard Constraints Matrix" value={selectedArch.designConstraints} />
            <DataField label="Scalability Dynamic Strategy" value={selectedArch.scalabilityStrategy} />
            <DataField label="High Availability Failure Isolation Scheme" value={selectedArch.highAvailabilityStrategy} />
            <DataField label="Fault Tolerance Strategies" value={selectedArch.faultToleranceStrategy} />
            <DataField label="Execution SLA & Performance Targets" value={selectedArch.performanceTargets} />
            <DataField label="Additional Blueprint Notes" value={selectedArch.additionalNotes} />
          </div>
        </div>
      )}
    </div>
  );
}