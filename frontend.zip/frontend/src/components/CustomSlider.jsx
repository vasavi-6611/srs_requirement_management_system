import React from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Slider from "@mui/material/Slider";

export default function CustomSlider({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  disabled = false,
  startIcon,
  endIcon,
  width = 200,
}) {
  return (
    <Box sx={{ width }}>
      <Stack
        spacing={2}
        direction="row"
        sx={{ alignItems: "center", mb: 1 }}
      >
        {startIcon}

        <Slider
          value={value}
          onChange={onChange}
          min={min}
          max={max}
          step={step}
          disabled={disabled}
        />

        {endIcon}
      </Stack>
    </Box>
  );
}