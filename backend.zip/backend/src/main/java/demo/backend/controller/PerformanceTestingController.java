package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.PerformanceTesting;
import demo.backend.repository.PerformanceTestingRepository;

@RestController
@RequestMapping("/api/testing/performance")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class PerformanceTestingController {

    @Autowired
    private PerformanceTestingRepository repository;

    @GetMapping({"", "/"})
    public List<PerformanceTesting> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PerformanceTesting> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<PerformanceTesting> saveRecord(@RequestBody PerformanceTesting record) {
        PerformanceTesting saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PerformanceTesting> updateRecord(@PathVariable Long id, @RequestBody PerformanceTesting details) {
        return repository.findById(id).map(record -> {
            record.setPerformanceTestingTools(details.getPerformanceTestingTools());
            record.setPeakLoadTestBenchmark(details.getPeakLoadTestBenchmark());
            record.setRegressionTestingScope(details.getRegressionTestingScope());
            record.setConcurrentUsersTarget(details.getConcurrentUsersTarget());
            record.setRampUpPeriodMinutes(details.getRampUpPeriodMinutes());
            record.setTestDurationMinutes(details.getTestDurationMinutes());
            record.setMaxResponseTimeThreshold(details.getMaxResponseTimeThreshold());
            record.setErrorRateTolerancePercent(details.getErrorRateTolerancePercent());
            record.setThroughputTargetRps(details.getThroughputTargetRps());
            record.setCpuUtilizationLimit(details.getCpuUtilizationLimit());
            record.setMemoryUtilizationLimit(details.getMemoryUtilizationLimit());
            record.setNetworkBandwidthCapMbps(details.getNetworkBandwidthCapMbps());
            record.setDatabaseConnectionTimeoutMs(details.getDatabaseConnectionTimeoutMs());
            record.setCacheHitRatioTarget(details.getCacheHitRatioTarget());
            record.setAutoScalingTriggerVerification(details.getAutoScalingTriggerVerification());
            record.setSoakTestDurationHours(details.getSoakTestDurationHours());
            record.setPerformanceScriptArtifactName(details.getPerformanceScriptArtifactName());
            record.setInfrastructureMetricsPlanName(details.getInfrastructureMetricsPlanName());

            PerformanceTesting updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}