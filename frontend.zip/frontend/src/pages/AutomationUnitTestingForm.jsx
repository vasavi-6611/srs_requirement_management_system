import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomFileUpload from "../components/CustomFileUpload";
import CustomNumberField from "../components/CustomNumberField";
import CustomSelect from "../components/CustomSelect";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function AutomationUnitTestForm() {
  const [viewMode, setViewMode] = useState("LIST");
  const [step, setStep] = useState(1);
  const [recordsList, setRecordsList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const emptyForm = {
    testCaseId: "",
    testCaseName: "",
    targetClassOrMethod: "",
    testingFramework: "",
    assertionStrategy: "",
    testStatus: "",
    testDescription: "",
    executionRunnerEnv: "",
    assignedDeveloper: "",
    timeoutThresholdMs: "",
    associatedUserStoryId: "",
    mockedDependencies: "",
    fixturesRequired: "",
    codeCoverageTargetPct: "",
    expectedExceptionPattern: "",
    inputArgumentsMockup: "",
    outputResultMockup: "",
    isFlakyTest: false,
    requiresDatabaseSandbox: false,
    requiresNetworkIsolation: false,
    memoryFootprintLimitMb: "",
    logSeverityFilter: "",
    jiraIssueKey: "",
    preconditions: "",
    sideEffects: "",
    refactoringNotes: "",
    testArtifactName: "",
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchFormRecords();
  }, []);

  const fetchFormRecords = async () => {
    try {
      const response = await api.get("/api/automation-unit-tests");
      const records = Array.isArray(response.data) ? response.data : response.data.content || [];
      setRecordsList(records);
    } catch (error) {
      console.error("Error fetching automation unit test registry:", error);
      setRecordsList([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileChange = (field, e) => {
    const file = e?.target?.files?.[0] || e?.file || e;
    if (file && file.name) {
      handleChange(field, file.name);
    } else if (typeof e === "string") {
      handleChange(field, e);
    }
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (record) => {
    setFormData(record);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (record) => {
    setSelectedRecord(record);
    setViewMode("VIEW_DETAILS");
  };

  const handleSubmit = async () => {
    try {
      if (isEditing) {
        await api.put(`/api/automation-unit-tests/${formData.id}`, formData);
        alert("Automation Unit Test Specification Updated Successfully!");
      } else {
        await api.post("/api/automation-unit-tests", formData);
        alert("Automation Unit Test Configuration Saved Successfully!");
      }
      await fetchFormRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error);
      alert("Failed to Save Automation Unit Test Data");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this automation unit test specification configuration?")) {
      try {
        await api.delete(`/api/automation-unit-tests/${id}`);
        alert("Automation Unit Test Dropped Successfully!");
        fetchFormRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entry.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Enforced / Enabled" : "❌ Disabled / Optional") : (value ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = [
      "1. Test Metadata & Target Scope",
      "2. Data Mocking & Runtime Environments",
      "3. Assertions & Execution Constraints",
    ];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0", overflowX: "auto" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45, whiteSpace: "nowrap", marginRight: "10px" }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#6366f1" : step > stepNum ? "#10b981" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#4f46e5" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Automation Unit Testing
            </h2>
            <CustomButton text="+ Configure New Unit Test Case" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#6366f1" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Test Case ID</th>
                <th style={{ padding: "14px" }}>Test Case Name</th>
                <th style={{ padding: "14px" }}>Target Class / Method</th>
                <th style={{ padding: "14px" }}>Testing Framework</th>
                <th style={{ padding: "14px" }}>Assertion Strategy</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {recordsList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No active unit tests or configuration logs found. Initialize an engine instance.</td>
                </tr>
              ) : (
                recordsList.map((record, index) => (
                  <tr key={record.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#6366f1" }}>{record.testCaseId || "—"}</td>
                    <td style={{ padding: "14px", fontWeight: "600", color: "#334155" }}>{record.testCaseName || "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f1f5f9", padding: "3px 8px", borderRadius: "4px", fontSize: "13px", fontFamily: "monospace" }}>{record.targetClassOrMethod || "—"}</span></td>
                    <td style={{ padding: "14px" }}><code style={{ background: "#e0e7ff", color: "#4338ca", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{record.testingFramework || "—"}</code></td>
                    <td style={{ padding: "14px", fontWeight: "500" }}>{record.assertionStrategy || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(record)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Details</button>
                        <button onClick={() => handleEditClick(record)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(record.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container unit-testing-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>Automation Unit Test Design Specification</h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}>
                  <CustomTextField label="Test Case Specification ID" fullWidth={true} value={formData.testCaseId} onChange={(e) => handleChange("testCaseId", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Test Suite Functional Scope Action" width="100%" value={formData.testCaseName} onChange={(newValue) => handleChange("testCaseName", newValue)}
                    options={[
                      "Cryptographic Handshake Cipher Match Verification",
                      "Distributed Memory Cache Eviction Threshold Test",
                      "Parallel Array Concurrency Overflow Verification",
                      "SQL Injection Payload Filtering Sanity Test",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Target Namespace / Class / Method Signature" fullWidth={true} value={formData.targetClassOrMethod} onChange={(e) => handleChange("targetClassOrMethod", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Unit Testing Execution Framework Engine" value={formData.testingFramework} onChange={(e) => handleChange("testingFramework", e.target.value)}
                    options={[
                      { label: "Jest Ecosystem (JavaScript / TypeScript)", value: "JEST" },
                      { label: "JUnit Platform Core (Java Framework)", value: "JUNIT" },
                      { label: "PyTest Functional Automation (Python Suite)", value: "PYTEST" },
                      { label: "Mocha Engine & Chai Assertions (NodeJS)", value: "MOCHA" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Primary Rule Assertion Core Strategy" value={formData.assertionStrategy} onChange={(e) => handleChange("assertionStrategy", e.target.value)}
                    options={[
                      { label: "State Validation (Deep Property Matching)", value: "STATE_VALIDATION" },
                      { label: "Behavior Mocking (Spy Interception Routines)", value: "BEHAVIOR_MOCKING" },
                      { label: "Exception Expectation Sandbox Handlers", value: "EXCEPTION_EXPECTATION" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Test Script Engine Lifecycle Status" value={formData.testStatus} onChange={(e) => handleChange("testStatus", e.target.value)}
                    options={[
                      { label: "Draft Initial Code Baseline", value: "DRAFT" },
                      { label: "Active Evaluation Matrix Included", value: "ACTIVE" },
                      { label: "Skipped Routine Execution Matrix Block", value: "SKIPPED" },
                      { label: "Deprecated Structural Logic Fragment", value: "DEPRECATED" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Unit Test Intended Code Coverage Description" value={formData.testDescription} onChange={(e) => handleChange("testDescription", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Target Execution Runner Sandbox Environment" fullWidth={true} value={formData.executionRunnerEnv} onChange={(e) => handleChange("executionRunnerEnv", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Lead Assigned Core Software Developer" fullWidth={true} value={formData.assignedDeveloper} onChange={(e) => handleChange("assignedDeveloper", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomNumberField label="Execution Speed Timeout Constraint Threshold (ms)" fullWidth={true} min={10} value={formData.timeoutThresholdMs} onChange={(e) => handleChange("timeoutThresholdMs", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomAutocomplete label="Parent Product Specification / User Story ID Mapping" width="100%" value={formData.associatedUserStoryId} onChange={(newValue) => handleChange("associatedUserStoryId", newValue)}
                    options={["None - Independent Core Module Testing Framework", "STORY-101 (Distributed Cache Engine)", "STORY-205 (Stripe Gateway Hook Integration)"]}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Target Intercepted Mock Dependencies Matrix" width="100%" value={formData.mockedDependencies} onChange={(newValue) => handleChange("mockedDependencies", newValue)}
                    options={[
                      "External REST Communication Gateway Proxy",
                      "Relational Database Driver Adapter Layer",
                      "Distributed Redundancy Memory Cluster Cluster",
                      "Cryptographic HSM Core Hardware Token Node",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomAutocomplete label="Required Infrastructure Sandbox Injection Fixtures" width="100%" value={formData.fixturesRequired} onChange={(newValue) => handleChange("fixturesRequired", newValue)}
                    options={[
                      "Clean Database Transaction Baseline Context",
                      "Mock Auth Access Token Scope Authorization Vector",
                      "JSON Schema Serialization Protocol Templates",
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Target Code Coverage Boundary Floor Metric (%)" fullWidth={true} value={formData.codeCoverageTargetPct} onChange={(e) => handleChange("codeCoverageTargetPct", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Expected Error Handling / Exception Match Patterns" fullWidth={true} value={formData.expectedExceptionPattern} onChange={(e) => handleChange("expectedExceptionPattern", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Mock Input Parameter Setup Datasets (JSON Arguments Array)" value={formData.inputArgumentsMockup} onChange={(e) => handleChange("inputArgumentsMockup", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Expected Output Simulation Pattern Matching (JSON Assert Return Template)" value={formData.outputResultMockup} onChange={(e) => handleChange("outputResultMockup", e.target.value)} />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Test Is Categorized As Flaky (Intermittent Time-Sensitive Execution Risks)" checked={formData.isFlakyTest} onChange={(e) => handleChange("isFlakyTest", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce Dedicated Relational Database Isolation Sandbox Container" checked={formData.requiresDatabaseSandbox} onChange={(e) => handleChange("requiresDatabaseSandbox", e.target.checked)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <CustomSwitch label="Enforce Total Network Stack Isolation (Block External I/O Interfaces)" checked={formData.requiresNetworkIsolation} onChange={(e) => handleChange("requiresNetworkIsolation", e.target.checked)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Max Allocatable Execution Memory Footprint Cap (MB)" fullWidth={true} value={formData.memoryFootprintLimitMb} onChange={(e) => handleChange("memoryFootprintLimitMb", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Console Logger Trapping Minimum Severity Stream Level Filter" fullWidth={true} value={formData.logSeverityFilter} onChange={(e) => handleChange("logSeverityFilter", e.target.value)} />
                </div>
                <div style={halfWidthItem}>
                  <CustomTextField label="Bi-Directional Atlassian Jira Tracking Reference Issue Key" fullWidth={true} value={formData.jiraIssueKey} onChange={(e) => handleChange("jiraIssueKey", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Required Engine Method Structural Preconditions" value={formData.preconditions} onChange={(e) => handleChange("preconditions", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Monitored Subsystem State Changes & Mutation Side Effects" value={formData.sideEffects} onChange={(e) => handleChange("sideEffects", e.target.value)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomTextarea label="Legacy Technical Debt Mitigation / Refactoring Target Notes" value={formData.refactoringNotes} onChange={(e) => handleChange("refactoringNotes", e.target.value)} />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Supporting Log File Attachments / Test Execution Vector Mock Logs:</label>
                  <CustomFileUpload buttonText="Upload Unit Test Mock Vector Resource" fileName={formData.testArtifactName} onChange={(e) => handleFileChange("testArtifactName", e)} accept=".json,.yaml,.xml,.txt,.bin" />
                </div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update Unit Test Specification" : "Save Test Automation Node"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#10b981" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedRecord && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>Automation Unit Test Execution Blueprint Specification</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Identity Entry Database Reference: UT-CORE-ID-{selectedRecord.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#6366f1" }} />
          </div>

          <h4 style={{ color: "#6366f1", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Test Metadata & Target Scope</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Test Case ID" value={selectedRecord.testCaseId} />
            <DataField label="Test Case Name" value={selectedRecord.testCaseName} />
            <DataField label="Target Method/Class Signature" value={selectedRecord.targetClassOrMethod} />
            <DataField label="Testing Framework Engine" value={selectedRecord.testingFramework} />
            <DataField label="Assertion Rule Strategy" value={selectedRecord.assertionStrategy} />
            <DataField label="Test Script LifeCycle Status" value={selectedRecord.testStatus} />
            <DataField label="Execution Sandbox Container" value={selectedRecord.executionRunnerEnv} />
            <DataField label="Lead Core Developer" value={selectedRecord.assignedDeveloper} />
            <DataField label="Execution Timeout Limit (ms)" value={selectedRecord.timeoutThresholdMs} />
            <DataField label="Mapped Parent User Story ID" value={selectedRecord.associatedUserStoryId} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Unit Test Intended Code Coverage Description" value={selectedRecord.testDescription} />
          </div>

          <h4 style={{ color: "#6366f1", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Data Mocking & Runtime Environments</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Intercepted Mock Dependencies" value={selectedRecord.mockedDependencies} />
            <DataField label="Injected Context Sandbox Fixtures" value={selectedRecord.fixturesRequired} />
            <DataField label="Target Coverage Floor Metric (%)" value={selectedRecord.codeCoverageTargetPct} />
            <DataField label="Expected Error Handling Patterns" value={selectedRecord.expectedExceptionPattern} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "30px" }}>
            <DataField label="Mock Input Parameter Setup Datasets (JSON)" value={selectedRecord.inputArgumentsMockup} />
            <DataField label="Expected Output Simulation Verification Pattern" value={selectedRecord.outputResultMockup} />
          </div>

          <h4 style={{ color: "#6366f1", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Assertions & Execution Constraints</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Flagged As Intermittent Flaky Test" value={selectedRecord.isFlakyTest} />
            <DataField label="Requires Isolated Database Instance" value={selectedRecord.requiresDatabaseSandbox} />
            <DataField label="Enforces Complete Network I/O Block" value={selectedRecord.requiresNetworkIsolation} />
            <DataField label="Max Memory Footprint Allocation (MB)" value={selectedRecord.memoryFootprintLimitMb} />
            <DataField label="Logger System Min Severity Stream" value={selectedRecord.logSeverityFilter} />
            <DataField label="Atlassian Jira Issue Tracking Key" value={selectedRecord.jiraIssueKey} />
            <DataField label="Supporting Log File Artifact" value={selectedRecord.testArtifactName} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <DataField label="Required Method Structural Preconditions" value={selectedRecord.preconditions} />
            <DataField label="Monitored Subsystem State Mutation Side Effects" value={selectedRecord.sideEffects} />
            <DataField label="Refactoring Technical Debt Action Notes" value={selectedRecord.refactoringNotes} />
          </div>
        </div>
      )}
    </div>
  );
}