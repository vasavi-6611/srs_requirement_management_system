import { useEffect, useState } from "react";
import api from "../axiosConfig";
import CustomAutocomplete from "../components/CustomAutocomplete";
import CustomButton from "../components/CustomButton";
import CustomCheckbox from "../components/CustomCheckbox";
import CustomNumberField from "../components/CustomNumberField";
import CustomRadioGroup from "../components/CustomRadioGroup";
import CustomSelect from "../components/CustomSelect";
import CustomSlider from "../components/CustomSlider";
import CustomSwitch from "../components/CustomSwitch";
import CustomTextField from "../components/CustomTextField";
import CustomTextarea from "../components/CustomTextarea";

export default function NonFunctionalRequirementForm() {
  const [viewMode, setViewMode] = useState("LIST"); // Modes: "LIST", "FORM", "VIEW_DETAILS"
  const [step, setStep] = useState(1);
  const [nfrList, setNfrList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedNfr, setSelectedNfr] = useState(null);

  const emptyForm = {
    performanceSpecs: "", maxResponseTime: "", avgResponseTime: "", transactionProcessingTime: "",
    maxConcurrentUsers: "", throughputRequirements: "", peakLoadCapacity: "", securityLevel: "BASIC",
    authenticationMethod: "", authorizationMethod: "", passwordPolicy: "", dataEncryptionRequired: false,
    auditLoggingRequired: false, sessionTimeoutDuration: "", availabilityPercentage: 95.0, 
    maintenanceWindow: "", disasterRecoveryTime: "", rpo: "", rto: "", backupReliability: "",
    faultToleranceLevel: "", dataIntegrityRequirements: "", systemStabilityRequirements: "",
    futureUserGrowthExpectation: "", storageScalabilityRequirement: "", horizontalScalingSupportRequired: false,
    easeOfUseLevel: "", userTrainingRequirement: false, accessibilityCompliance: false, supportedLanguages: "",
    supportedBrowsers: false, supportedOperatingSystems: false, mobileDeviceSupport: false,
    thirdPartyIntegrationSupport: false, codeMaintainabilityLevel: "", documentationRequirement: false,
    monitoringRequirement: false, loggingRequirement: false, regulatoryCompliance: "", industryStandardsCompliance: "",
  };
  
  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    fetchNfrRecords();
  }, []);

  const fetchNfrRecords = async () => {
    try {
      const response = await api.get("/api/nfr");
      setNfrList(response.data || []);
    } catch (error) {
      console.error("Error fetching NFR database registry:", error);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStep((prevStep) => prevStep - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleAddNew = () => {
    setFormData(emptyForm);
    setIsEditing(false);
    setStep(1);
    setViewMode("FORM");
  };

  const handleEditClick = (nfrRecord) => {
    setFormData(nfrRecord);
    setIsEditing(true);
    setStep(1);
    setViewMode("FORM");
  };

  const handleViewClick = (nfrRecord) => {
    setSelectedNfr(nfrRecord);
    setViewMode("VIEW_DETAILS");
  };

  // Clean and sanitize payload to match backend numeric types safely
  const handleSubmit = async () => {
    try {
      const sanitizedPayload = {
        ...formData,
        maxResponseTime: formData.maxResponseTime === "" ? 0 : parseInt(formData.maxResponseTime, 10),
        avgResponseTime: formData.avgResponseTime === "" ? 0 : parseInt(formData.avgResponseTime, 10),
        transactionProcessingTime: formData.transactionProcessingTime === "" ? 0 : parseInt(formData.transactionProcessingTime, 10),
        maxConcurrentUsers: formData.maxConcurrentUsers === "" ? 0 : parseInt(formData.maxConcurrentUsers, 10),
        throughputRequirements: formData.throughputRequirements === "" ? 0 : parseInt(formData.throughputRequirements, 10),
        peakLoadCapacity: formData.peakLoadCapacity === "" ? 0.0 : parseFloat(formData.peakLoadCapacity),
        sessionTimeoutDuration: formData.sessionTimeoutDuration === "" ? 30 : parseInt(formData.sessionTimeoutDuration, 10),
        availabilityPercentage: formData.availabilityPercentage === "" ? 95.0 : parseFloat(formData.availabilityPercentage),
        disasterRecoveryTime: formData.disasterRecoveryTime === "" ? 0 : parseInt(formData.disasterRecoveryTime, 10),
        rpo: formData.rpo === "" ? 0 : parseInt(formData.rpo, 10),
        rto: formData.rto === "" ? 0 : parseInt(formData.rto, 10),
        futureUserGrowthExpectation: formData.futureUserGrowthExpectation === "" ? 0.0 : parseFloat(formData.futureUserGrowthExpectation),
        storageScalabilityRequirement: formData.storageScalabilityRequirement === "" ? 0.0 : parseFloat(formData.storageScalabilityRequirement),
      };

      console.log("Sending Sanitized NFR Payload:", sanitizedPayload);

      if (isEditing) {
        await api.put(`/api/nfr/${formData.id}`, sanitizedPayload);
        alert("Non-Functional Requirements Baseline Updated Successfully!");
      } else {
        await api.post("/api/nfr", sanitizedPayload);
        alert("NFR Information Saved Successfully!");
      }
      
      await fetchNfrRecords();
      setViewMode("LIST");
    } catch (error) {
      console.error("Submission Failure Error Stack:", error.response || error);
      alert("Failed to Save NFR Architecture Metrics. Check console for details.");
    }
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this Non-Functional Requirement profile?")) {
      try {
        await api.delete(`/api/nfr/${id}`);
        alert("NFR Specification Instance Dropped Successfully!");
        fetchNfrRecords();
      } catch (error) {
        console.error(error);
        alert("Failed to drop selected database register entity mapping.");
      }
    }
  };

  const gridContainerStyle = { display: "flex", flexWrap: "wrap", gap: "20px 24px", width: "100%" };
  const halfWidthItem = { flex: "1 1 calc(50% - 12px)", minWidth: "280px" };
  const fullWidthItem = { flex: "1 1 100%" };

  const DataField = ({ label, value }) => (
    <div style={{ background: "#f8fafc", padding: "12px 16px", borderRadius: "6px", border: "1px solid #edf2f7" }}>
      <strong style={{ color: "#64748b", fontSize: "12px", display: "block", marginBottom: "4px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</strong>
      <span style={{ color: "#1e293b", fontWeight: "600", fontSize: "15px", wordBreak: "break-word" }}>
        {typeof value === "boolean" ? (value ? "✅ Yes / Enabled" : "❌ No / Disabled") : (value !== null && value !== undefined && value !== "" ? String(value) : "—")}
      </span>
    </div>
  );

  const renderStepperHUD = () => {
    const stepsTitle = ["1. Performance & Speed", "2. Security & Identity", "3. Availability, Usability & Compliance"];
    return (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: "35px", background: "#f8fafc", padding: "15px 25px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
        {stepsTitle.map((title, index) => {
          const stepNum = index + 1;
          const isActive = step === stepNum;
          return (
            <div key={stepNum} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: step >= stepNum ? 1 : 0.45 }}>
              <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "30px", height: "30px", borderRadius: "50%", background: isActive ? "#0284c7" : step > stepNum ? "#16a34a" : "#64748b", color: "#ffffff", fontWeight: "700", fontSize: "14px" }}>
                {step > stepNum ? "✓" : stepNum}
              </span>
              <span style={{ fontSize: "15px", fontWeight: isActive ? "700" : "500", color: isActive ? "#0369a1" : "#334155" }}>{title}</span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "0 auto", fontFamily: "sans-serif" }}>
      {viewMode === "LIST" && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700", fontSize: "24px" }}>
              Non-Functional Requirements
            </h2>
            <CustomButton text="+ Add New NFR Profile" variant="contained" onClick={handleAddNew} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderRadius: "8px", overflow: "hidden" }}>
            <thead>
              <tr style={{ background: "#f1f5f9", textAlign: "left", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "14px" }}>Record Scope Reference</th>
                <th style={{ padding: "14px" }}>Max Response Latency</th>
                <th style={{ padding: "14px" }}>Security Tier</th>
                <th style={{ padding: "14px" }}>Uptime SLA</th>
                <th style={{ padding: "14px" }}>Architecture Framework</th>
                <th style={{ padding: "14px", textAlign: "center" }}>Operations Matrix</th>
              </tr>
            </thead>
            <tbody>
              {nfrList.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center", padding: "30px", color: "#64748b" }}>No architecture matrix defined. Configure a baseline profile entity.</td>
                </tr>
              ) : (
                nfrList.map((nfr, index) => (
                  <tr key={nfr.id || index} style={{ borderBottom: "1px solid #e2e8f0" }}>
                    <td style={{ padding: "14px", fontWeight: "700", color: "#0f172a" }}>{nfr.performanceSpecs || `NFR-Profile-${nfr.id || index + 1}`}</td>
                    <td style={{ padding: "14px" }}>{nfr.maxResponseTime ? `${nfr.maxResponseTime} ms` : "—"}</td>
                    <td style={{ padding: "14px" }}><span style={{ background: "#f0fdf4", color: "#16a34a", padding: "4px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: "600" }}>{nfr.securityLevel || "NOT_SET"}</span></td>
                    <td style={{ padding: "14px", fontWeight: "600" }}>{nfr.availabilityPercentage}%</td>
                    <td style={{ padding: "14px" }}>{nfr.industryStandardsCompliance || "—"}</td>
                    <td style={{ padding: "14px", textAlign: "center" }}>
                      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                        <button onClick={() => handleViewClick(nfr)} style={{ border: "none", backgroundColor: "#f8fafc", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>👁️ View Blueprint</button>
                        <button onClick={() => handleEditClick(nfr)} style={{ border: "none", backgroundColor: "#fef9c3", color: "#854d0e", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>✏️ Edit</button>
                        <button onClick={() => handleDeleteClick(nfr.id)} style={{ border: "none", backgroundColor: "#fee2e2", color: "#991b1b", padding: "6px 12px", cursor: "pointer", borderRadius: "4px", fontWeight: "600", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}>🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewMode === "FORM" && (
        <div className="form-container nfr-specs-theme" style={{ display: "flex", flexDirection: "column", gap: "25px", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ color: "#1e293b", margin: 0, fontWeight: "700" }}>
              {isEditing ? "Modify NFR Metrics Baseline Specs" : "Non-Functional Requirements Specification Setup"}
            </h2>
            <CustomButton text="Cancel Form" variant="outlined" onClick={() => setViewMode("LIST")} />
          </div>

          {renderStepperHUD()}

          <div style={gridContainerStyle}>
            {step === 1 && (
              <>
                <div style={halfWidthItem}><CustomNumberField label="Maximum Allowed Response Time (ms)" fullWidth={true} min={0} value={formData.maxResponseTime} onChange={(e) => handleChange("maxResponseTime", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Average Target Response Time (ms)" fullWidth={true} min={0} value={formData.avgResponseTime} onChange={(e) => handleChange("avgResponseTime", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Transaction Processing Time (ms)" fullWidth={true} min={0} value={formData.transactionProcessingTime} onChange={(e) => handleChange("transactionProcessingTime", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Maximum Concurrent Active Users Limit" fullWidth={true} min={0} value={formData.maxConcurrentUsers} onChange={(e) => handleChange("maxConcurrentUsers", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Throughput Requirements (Transactions/sec)" fullWidth={true} min={0} value={formData.throughputRequirements} onChange={(e) => handleChange("throughputRequirements", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Peak Load Multiplier Capacity Factor" fullWidth={true} min={0} value={formData.peakLoadCapacity} onChange={(e) => handleChange("peakLoadCapacity", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Performance Specifications (General Architecture Execution Scope)" value={formData.performanceSpecs} onChange={(e) => handleChange("performanceSpecs", e.target.value)} /></div>
              </>
            )}

            {step === 2 && (
              <>
                <div style={halfWidthItem}>
                  <CustomSelect label="Security Compliance Level Tier" value={formData.securityLevel} onChange={(e) => handleChange("securityLevel", e.target.value)}
                    options={[
                      { label: "Basic Tier (HTTPS Infrastructure)", value: "BASIC" },
                      { label: "Medium Tier (RBAC + DB Encryptions)", value: "MEDIUM" },
                      { label: "High Isolation Tier (MFA + Audits Matrix)", value: "HIGH" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Identity Authentication Method Scheme" value={formData.authenticationMethod} onChange={(e) => handleChange("authenticationMethod", e.target.value)}
                    options={[
                      { label: "OAuth2 Single-Sign-On (SSO / OpenID Connect)", value: "OAUTH2_SSO" },
                      { label: "JWT Token-Based Authentication", value: "JWT_BEARER" },
                      { label: "Multi-Factor Authentication (MFA TOTP Link)", value: "MFA_TOTP" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Resource Authorization Method" value={formData.authorizationMethod} onChange={(e) => handleChange("authorizationMethod", e.target.value)}
                    options={[
                      { label: "Role-Based Access Control (RBAC System Matrix)", value: "RBAC" },
                      { label: "Attribute-Based Dynamic Clearance (ABAC Scheme)", value: "ABAC" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}><CustomNumberField label="Session Automatic Timeout Duration Limit (Minutes)" fullWidth={true} min={1} value={formData.sessionTimeoutDuration} onChange={(e) => handleChange("sessionTimeoutDuration", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Global User Password Compliance Policy Specifications" value={formData.passwordPolicy} onChange={(e) => handleChange("passwordPolicy", e.target.value)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Mandatory Cryptographic Encryption Required" checked={formData.dataEncryptionRequired} onChange={(e) => handleChange("dataEncryptionRequired", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Immutable Security Audit Logging Required" checked={formData.auditLoggingRequired} onChange={(e) => handleChange("auditLoggingRequired", e.target.checked)} /></div>
              </>
            )}

            {step === 3 && (
              <>
                <div style={halfWidthItem}><CustomTextField label="Permitted System Maintenance Window Schedule Interval" fullWidth={true} value={formData.maintenanceWindow} onChange={(e) => handleChange("maintenanceWindow", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Disaster Recovery Execution Time Boundary (Minutes)" fullWidth={true} min={0} value={formData.disasterRecoveryTime} onChange={(e) => handleChange("disasterRecoveryTime", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Recovery Point Objective (RPO Value Max Hours Allowed)" fullWidth={true} min={0} value={formData.rpo} onChange={(e) => handleChange("rpo", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Recovery Time Objective (RTO Value Max Hours Target)" fullWidth={true} min={0} value={formData.rto} onChange={(e) => handleChange("rto", e.target.value)} /></div>
                <div style={{ ...fullWidthItem, display: "flex", flexDirection: "column", gap: "8px", padding: "10px 0" }}>
                  <label style={{ fontSize: "14px", color: "#555" }}>Target Infrastructure Availability Metric: <strong>{formData.availabilityPercentage}%</strong> Continuous System Uptime SLA</label>
                  <CustomSlider value={formData.availabilityPercentage} min={95} max={100} step={0.1} width="100%" onChange={(e, newValue) => handleChange("availabilityPercentage", newValue)} />
                </div>
                <div style={fullWidthItem}>
                  <CustomRadioGroup label="Storage Snapshot & Data Backup Policy Strategy Frequency" row={true} value={formData.backupReliability} onChange={(e) => handleChange("backupReliability", e.target.value)}
                    options={[
                      { label: "Hourly High-Frequency Redundancy", value: "HOURLY" },
                      { label: "Daily System Synchronizations", value: "DAILY" },
                      { label: "Weekly Immutable Tape Archival Layout", value: "WEEKLY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Fault Tolerance Level Tolerance Layer" value={formData.faultToleranceLevel} onChange={(e) => handleChange("faultToleranceLevel", e.target.value)}
                    options={[
                      { label: "Zero Downtime Active-Active Mirror (Hot Standby)", value: "HOT_STANDBY" },
                      { label: "Graceful Performance Degradation Recovery Model", value: "GRACEFUL_DEGRADATION" },
                      { label: "Cold Backup Cold Recovery Restart Blueprint", value: "COLD_RECOVERY" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}><CustomNumberField label="Future User Base Compound Annual Growth Expectation (%)" fullWidth={true} min={0} value={formData.futureUserGrowthExpectation} onChange={(e) => handleChange("futureUserGrowthExpectation", e.target.value)} /></div>
                <div style={halfWidthItem}><CustomNumberField label="Storage Scalability Elastic Growth Margin (TB Capacity Projection)" fullWidth={true} min={0} value={formData.storageScalabilityRequirement} onChange={(e) => handleChange("storageScalabilityRequirement", e.target.value)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Dynamic Horizontal Scaling Load Balancer Integration Required" checked={formData.horizontalScalingSupportRequired} onChange={(e) => handleChange("horizontalScalingSupportRequired", e.target.checked)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="Data Integrity Control Requirements" value={formData.dataIntegrityRequirements} onChange={(e) => handleChange("dataIntegrityRequirements", e.target.value)} /></div>
                <div style={fullWidthItem}><CustomTextarea label="System Infrastructure Stability & Error Isolation Requirements" value={formData.systemStabilityRequirements} onChange={(e) => handleChange("systemStabilityRequirements", e.target.value)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Target Ease of Use Operations Classification" value={formData.easeOfUseLevel} onChange={(e) => handleChange("easeOfUseLevel", e.target.value)}
                    options={[
                      { label: "Intuitive Consumer Grade UX", value: "INTUITIVE" },
                      { label: "Professional Expert Tooling", value: "EXPERT_INTERFACE" },
                    ]}
                  />
                </div>
                <div style={halfWidthItem}><CustomTextField label="Global Supported Languages Framework" fullWidth={true} value={formData.supportedLanguages} onChange={(e) => handleChange("supportedLanguages", e.target.value)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Mandatory Multi-Tier User Technical Training Required" checked={formData.userTrainingRequirement} onChange={(e) => handleChange("userTrainingRequirement", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Verify Accessibility Compliance Layout Rules (WCAG 2.1 AA Checklist)" checked={formData.accessibilityCompliance} onChange={(e) => handleChange("accessibilityCompliance", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Enforce Multi-Browser Cross Compatibility Matrix" checked={formData.supportedBrowsers} onChange={(e) => handleChange("supportedBrowsers", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomCheckbox label="Cross Operating System Binary Portability Validation" checked={formData.supportedOperatingSystems} onChange={(e) => handleChange("supportedOperatingSystems", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Responsive Mobile Engine Adaptive Native Viewport Access Support Required" checked={formData.mobileDeviceSupport} onChange={(e) => handleChange("mobileDeviceSupport", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Third-Party REST/SOAP Integration Adapter Infrastructure Extension Support" checked={formData.thirdPartyIntegrationSupport} onChange={(e) => handleChange("thirdPartyIntegrationSupport", e.target.checked)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Target Cyclomatic/Code Maintainability Index Level" value={formData.codeMaintainabilityLevel} onChange={(e) => handleChange("codeMaintainabilityLevel", e.target.value)}
                    options={[
                      { label: "High Index Tier (Clean Architecture Patterns)", value: "HIGH_INDEX" },
                      { label: "Standard Functional Modularity Refactor Paths", value: "STANDARD_MODULARITY" },
                    ]}
                  />
                </div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Technical Component API / Architecture Schema Documentation Generation Support" checked={formData.documentationRequirement} onChange={(e) => handleChange("documentationRequirement", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Active Microservices Telemetry Performance Monitoring Required" checked={formData.monitoringRequirement} onChange={(e) => handleChange("monitoringRequirement", e.target.checked)} /></div>
                <div style={{ ...halfWidthItem, display: "flex", flexDirection: "column", justifyContent: "center" }}><CustomSwitch label="Centralized Log Execution Aggregation Stream Pipelines Required" checked={formData.loggingRequirement} onChange={(e) => handleChange("loggingRequirement", e.target.checked)} /></div>
                <div style={halfWidthItem}>
                  <CustomSelect label="Industry Standards Architecture Framework Followed" value={formData.industryStandardsCompliance} onChange={(e) => handleChange("industryStandardsCompliance", e.target.value)}
                    options={[
                      { label: "ISO/IEC 27001 Security Management Certification Guidelines", value: "ISO_27001" },
                      { label: "IEEE 730 Software Quality Assurance Implementation Baseline", value: "IEEE_730" },
                      { label: "IEEE 802.11ah Sub-GHz Telecommunication PHY Profile Rules", value: "IEEE_802_11AH" },
                    ]}
                  />
                </div>
                <div style={fullWidthItem}><CustomTextarea label="Regulatory Compliance Directives" value={formData.regulatoryCompliance} onChange={(e) => handleChange("regulatoryCompliance", e.target.value)} /></div>
              </>
            )}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "30px", width: "100%", gap: "20px" }}>
            {step > 1 ? <CustomButton text="← Previous Step" onClick={handleBack} variant="outlined" style={{ flex: "1" }} /> : <div style={{ flex: "1" }} />}
            {step < 3 ? <CustomButton text="Next Step →" onClick={handleNext} variant="contained" style={{ flex: "1" }} /> : <CustomButton text={isEditing ? "Update NFR Architecture Blueprint" : "Save NFR Requirements"} onClick={handleSubmit} variant="contained" style={{ flex: "1", backgroundColor: "#16a34a" }} />}
          </div>
        </div>
      )}

      {viewMode === "VIEW_DETAILS" && selectedNfr && (
        <div style={{ background: "#fff", padding: "30px", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.08)", textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "2px solid #e2e8f0", paddingBottom: "15px", marginBottom: "25px" }}>
            <div>
              <h3 style={{ margin: 0, color: "#0f172a", fontSize: "22px" }}>NFR Infrastructure Metrics Inspection Summary</h3>
              <p style={{ margin: "4px 0 0 0", color: "#64748b" }}>Registry Context Target Reference Code ID: NFR-{selectedNfr.id || "NEW"}</p>
            </div>
            <CustomButton text="Back to Dashboard" variant="contained" onClick={() => setViewMode("LIST")} style={{ backgroundColor: "#0284c7" }} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>1. Performance & Execution Scalability Specifications</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Max Allowed Response Time" value={`${selectedNfr.maxResponseTime} ms`} />
            <DataField label="Average Target Response Time" value={`${selectedNfr.avgResponseTime} ms`} />
            <DataField label="Transaction Processing Latency" value={`${selectedNfr.transactionProcessingTime} ms`} />
            <DataField label="Max Concurrent Active User Cap" value={selectedNfr.maxConcurrentUsers} />
            <DataField label="Throughput Requirement Matrix" value={selectedNfr.throughputRequirements} />
            <DataField label="Peak Load Multiplier Factor" value={selectedNfr.peakLoadCapacity} />
          </div>
          <div style={{ marginBottom: "30px" }}>
            <DataField label="General Architecture Execution Scope Details" value={selectedNfr.performanceSpecs} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>2. Cryptographic Security Framework & Identity Protocols</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Security Compliance Level Tier" value={selectedNfr.securityLevel} />
            <DataField label="Identity Authentication Scheme" value={selectedNfr.authenticationMethod} />
            <DataField label="Resource Authorization Engine" value={selectedNfr.authorizationMethod} />
            <DataField label="Session Timeout Window Duration" value={`${selectedNfr.sessionTimeoutDuration} Minutes`} />
            <DataField label="Data Storage & Transit Cryptography" value={selectedNfr.dataEncryptionRequired} />
            <DataField label="Immutable Security Audit Logs" value={selectedNfr.auditLoggingRequired} />
          </div>
          <div style={{ marginBottom: "30px" }}>
            <DataField label="Global Password Compliance Policy Rules" value={selectedNfr.passwordPolicy} />
          </div>

          <h4 style={{ color: "#0284c7", borderBottom: "1px solid #e2e8f0", paddingBottom: "6px", marginBottom: "16px" }}>3. Resilience SLA & Regulatory Compliance</h4>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px", marginBottom: "20px" }}>
            <DataField label="Target System Continuous Uptime SLA" value={`${selectedNfr.availabilityPercentage}%`} />
            <DataField label="Permitted System Maintenance Window" value={selectedNfr.maintenanceWindow} />
            <DataField label="Disaster Recovery Max Boundary" value={`${selectedNfr.disasterRecoveryTime} Mins`} />
            <DataField label="Recovery Point Objective (RPO)" value={`${selectedNfr.rpo} Hours`} />
            <DataField label="Recovery Time Objective (RTO)" value={`${selectedNfr.rto} Hours`} />
            <DataField label="Data Snapshot Backup Policy Scheme" value={selectedNfr.backupReliability} />
            <DataField label="Fault Tolerance Resilience Layer" value={selectedNfr.faultToleranceLevel} />
            <DataField label="Future User Base CAGR Growth Limit" value={`${selectedNfr.futureUserGrowthExpectation}%`} />
            <DataField label="Storage Scalability Projection Capacity" value={`${selectedNfr.storageScalabilityRequirement} TB`} />
            <DataField label="Horizontal Auto-Scaling Support" value={selectedNfr.horizontalScalingSupportRequired} />
          </div>
        </div>
      )}
    </div>
  );
}