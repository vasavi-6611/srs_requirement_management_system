import React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";

export default function CustomAutocomplete({
  label,
  options,
  width = 300,
  value,
  onChange,
}) {
  return (
    <Autocomplete
      disablePortal
      options={options}
      value={value}
      onChange={(event, newValue) => onChange(newValue)}
      sx={{ width }}
      renderInput={(params) => (
        <TextField {...params} label={label} />
      )}
    />
  );
}