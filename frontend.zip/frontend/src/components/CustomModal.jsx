import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";

export default function CustomModal({
  buttonText,
  title,
  description,
  open,
  handleOpen,
  handleClose,
  width = 400,
  children, // <-- 1. Dynamic child forms elements parameters wrapper prop code logic inject chesa bro
}) {
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width,
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    borderRadius: "12px", // Minor touch dashboard modern card rounding rules update matching setup
  };

  return (
    <div>
      {/* 2. ButtonText dynamic setup checks context rules */}
      {buttonText && (
        <Button onClick={handleOpen}>
          {buttonText}
        </Button>
      )}

      <Modal
        open={open}
        onClose={handleClose}
      >
        <Box sx={style}>

          <Typography
            variant="h6"
            component="h2"
          >
            {title}
          </Typography>

          {description && (
            <Typography sx={{ mt: 2 }}>
              {description}
            </Typography>
          )}

          {/* 3. Direct Slot Entry Layout Integration: Ee single target child block valla internal text views display full custom form load standard configurations direct trigger sets done! */}
          {children}

        </Box>
      </Modal>

    </div>
  );
}