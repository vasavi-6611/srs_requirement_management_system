package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.ManualVerification;

@Repository
public interface ManualVerificationRepository extends JpaRepository<ManualVerification, Long> {
}