package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.InfrastructureSecurity;
import demo.backend.repository.InfrastructureSecurityRepository;

@RestController
@RequestMapping("/api/testing/infrastructure")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class InfrastructureSecurityController {

    @Autowired
    private InfrastructureSecurityRepository repository;

    @GetMapping({"", "/"})
    public List<InfrastructureSecurity> getAllRecords() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InfrastructureSecurity> getRecordById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<InfrastructureSecurity> saveRecord(@RequestBody InfrastructureSecurity record) {
        InfrastructureSecurity saved = repository.save(record);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InfrastructureSecurity> updateRecord(@PathVariable Long id, @RequestBody InfrastructureSecurity details) {
        return repository.findById(id).map(record -> {
            record.setCicdPipelineIntegration(details.getCicdPipelineIntegration());
            record.setSecurityPenetrationTesting(details.getSecurityPenetrationTesting());
            record.setTestEnvironmentRequirements(details.getTestEnvironmentRequirements());
            record.setTestDataSanitizationRequired(details.getTestDataSanitizationRequired());
            record.setTestPlanDocumentName(details.getTestPlanDocumentName());
            record.setComplianceStandardRequirement(details.getComplianceStandardRequirement());
            record.setVulnerabilityScanFrequency(details.getVulnerabilityScanFrequency());
            record.setMaxAllowedSev1Defects(details.getMaxAllowedSev1Defects());
            record.setMaxAllowedSev2Defects(details.getMaxAllowedSev2Defects());
            record.setSslCertExpirationAlertDays(details.getSslCertExpirationAlertDays());
            record.setSandboxInstanceCount(details.getSandboxInstanceCount());
            record.setEnvironmentTtlDays(details.getEnvironmentTtlDays());
            record.setIamAccessReviewCycle(details.getIamAccessReviewCycle());
            record.setEncryptionAlgorithmStatic(details.getEncryptionAlgorithmStatic());
            record.setStaticCodeAnalysisTool(details.getStaticCodeAnalysisTool());
            record.setPenetrationReportArtifactName(details.getPenetrationReportArtifactName());
            record.setInfrastructureDeploymentYamlName(details.getInfrastructureDeploymentYamlName());

            InfrastructureSecurity updated = repository.save(record);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}