package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "testing_requirements")
public class TestingRequirement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "requirement_id")
    private String requirementId = "";

    @Column(name = "requirement_name")
    private String requirementName = "";

    @Column(name = "module_context")
    private String moduleContext = "";

    @Column(name = "priority_tier")
    private String priorityTier = "";

    @Column(name = "testing_type")
    private String testingType = "";

    @Column(name = "requirement_status")
    private String requirementStatus = "";

    @Lob
    @Column(name = "requirement_description")
    private String requirementDescription = "";

    @Column(name = "target_environment")
    private String targetEnvironment = "";

    @Column(name = "assigned_qa_engineer")
    private String assignedQAEngineer = "";

    @Column(name = "execution_order")
    private String executionOrder = "";

    @Column(name = "associated_user_story_id")
    private String associatedUserStoryId = "";

    @Column(name = "rbac_roles_targeted")
    private String rbacRolesTargeted = "";

    @Column(name = "feature_flags_targeted")
    private String featureFlagsTargeted = "";

    @Column(name = "hardware_device_constraints")
    private String hardwareDeviceConstraints = "";

    @Lob
    @Column(name = "expected_outcome_pattern")
    private String expectedOutcomePattern = "";

    @Lob
    @Column(name = "input_dataset_mockup")
    private String inputDatasetMockup = "";

    @Column(name = "automation_script_path")
    private String automationScriptPath = "";

    @Column(name = "analytics_tracking_key")
    private String analyticsTrackingKey = "";

    @Column(name = "is_regression_test")
    private Boolean isRegressionTest = true;

    @Column(name = "requires_manual_verification")
    private Boolean requiresManualVerification = false;

    @Column(name = "requires_third_party_sign_off")
    private Boolean requiresThirdPartySignOff = false;

    @Column(name = "sla_threshold_ms")
    private String slaThresholdMs = "";

    @Column(name = "sla_severity_color")
    private String slaSeverityColor = "";

    @Column(name = "jira_issue_key")
    private String jiraIssueKey = "";

    @Column(name = "target_window")
    private String targetWindow = "";

    @Lob
    @Column(name = "assumptions")
    private String assumptions = "";

    @Lob
    @Column(name = "\"constraints\"")
    private String constraints = "";

    @Lob
    @Column(name = "design_notes")
    private String designNotes = "";

    @Column(name = "supporting_documents_name")
    private String supportingDocumentsName = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRequirementId() { return requirementId; }
    public void setRequirementId(String requirementId) { this.requirementId = requirementId; }

    public String getRequirementName() { return requirementName; }
    public void setRequirementName(String requirementName) { this.requirementName = requirementName; }

    public String getModuleContext() { return moduleContext; }
    public void setModuleContext(String moduleContext) { this.moduleContext = moduleContext; }

    public String getPriorityTier() { return priorityTier; }
    public void setPriorityTier(String priorityTier) { this.priorityTier = priorityTier; }

    public String getTestingType() { return testingType; }
    public void setTestingType(String testingType) { this.testingType = testingType; }

    public String getRequirementStatus() { return requirementStatus; }
    public void setRequirementStatus(String requirementStatus) { this.requirementStatus = requirementStatus; }

    public String getRequirementDescription() { return requirementDescription; }
    public void setRequirementDescription(String requirementDescription) { this.requirementDescription = requirementDescription; }

    public String getTargetEnvironment() { return targetEnvironment; }
    public void setTargetEnvironment(String targetEnvironment) { this.targetEnvironment = targetEnvironment; }

    public String getAssignedQAEngineer() { return assignedQAEngineer; }
    public void setAssignedQAEngineer(String assignedQAEngineer) { this.assignedQAEngineer = assignedQAEngineer; }

    public String getExecutionOrder() { return executionOrder; }
    public void setExecutionOrder(String executionOrder) { this.executionOrder = executionOrder; }

    public String getAssociatedUserStoryId() { return associatedUserStoryId; }
    public void setAssociatedUserStoryId(String associatedUserStoryId) { this.associatedUserStoryId = associatedUserStoryId; }

    public String getRbacRolesTargeted() { return rbacRolesTargeted; }
    public void setRbacRolesTargeted(String rbacRolesTargeted) { this.rbacRolesTargeted = rbacRolesTargeted; }

    public String getFeatureFlagsTargeted() { return featureFlagsTargeted; }
    public void setFeatureFlagsTargeted(String featureFlagsTargeted) { this.featureFlagsTargeted = featureFlagsTargeted; }

    public String getHardwareDeviceConstraints() { return hardwareDeviceConstraints; }
    public void setHardwareDeviceConstraints(String hardwareDeviceConstraints) { this.hardwareDeviceConstraints = hardwareDeviceConstraints; }

    public String getExpectedOutcomePattern() { return expectedOutcomePattern; }
    public void setExpectedOutcomePattern(String expectedOutcomePattern) { this.expectedOutcomePattern = expectedOutcomePattern; }

    public String getInputDatasetMockup() { return inputDatasetMockup; }
    public void setInputDatasetMockup(String inputDatasetMockup) { this.inputDatasetMockup = inputDatasetMockup; }

    public String getAutomationScriptPath() { return automationScriptPath; }
    public void setAutomationScriptPath(String automationScriptPath) { this.automationScriptPath = automationScriptPath; }

    public String getAnalyticsTrackingKey() { return analyticsTrackingKey; }
    public void setAnalyticsTrackingKey(String analyticsTrackingKey) { this.analyticsTrackingKey = analyticsTrackingKey; }

    public Boolean getIsRegressionTest() { return isRegressionTest; }
    public void setIsRegressionTest(Boolean isRegressionTest) { this.isRegressionTest = isRegressionTest; }

    public Boolean getRequiresManualVerification() { return requiresManualVerification; }
    public void setRequiresManualVerification(Boolean requiresManualVerification) { this.requiresManualVerification = requiresManualVerification; }

    public Boolean getRequiresThirdPartySignOff() { return requiresThirdPartySignOff; }
    public void setRequiresThirdPartySignOff(Boolean requiresThirdPartySignOff) { this.requiresThirdPartySignOff = requiresThirdPartySignOff; }

    public String getSlaThresholdMs() { return slaThresholdMs; }
    public void setSlaThresholdMs(String slaThresholdMs) { this.slaThresholdMs = slaThresholdMs; }

    public String getSlaSeverityColor() { return slaSeverityColor; }
    public void setSlaSeverityColor(String slaSeverityColor) { this.slaSeverityColor = slaSeverityColor; }

    public String getJiraIssueKey() { return jiraIssueKey; }
    public void setJiraIssueKey(String jiraIssueKey) { this.jiraIssueKey = jiraIssueKey; }

    public String getTargetWindow() { return targetWindow; }
    public void setTargetWindow(String targetWindow) { this.targetWindow = targetWindow; }

    public String getAssumptions() { return assumptions; }
    public void setAssumptions(String assumptions) { this.assumptions = assumptions; }

    public String getConstraints() { return constraints; }
    public void setConstraints(String constraints) { this.constraints = constraints; }

    public String getDesignNotes() { return designNotes; }
    public void setDesignNotes(String designNotes) { this.designNotes = designNotes; }

    public String getSupportingDocumentsName() { return supportingDocumentsName; }
    public void setSupportingDocumentsName(String supportingDocumentsName) { this.supportingDocumentsName = supportingDocumentsName; }
}