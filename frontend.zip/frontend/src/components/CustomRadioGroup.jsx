import React from "react";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";

export default function CustomRadioGroup({
  label,
  options = [],
  value,
  onChange,
  row = false,
}) {
  const id = React.useId();

  return (
    <FormControl>
      <FormLabel id={`${id}-label`}>
        {label}
      </FormLabel>

      <RadioGroup
        row={row}
        aria-labelledby={`${id}-label`}
        value={value}
        onChange={onChange}
      >
        {options.map((option, index) => (
          <FormControlLabel
            key={index}
            value={option.value}
            control={<Radio />}
            label={option.label}
          />
        ))}
      </RadioGroup>
    </FormControl>
  );
}