package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.InfrastructureSecurity;

@Repository
public interface InfrastructureSecurityRepository extends JpaRepository<InfrastructureSecurity, Long> {
}