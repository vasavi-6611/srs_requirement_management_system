package demo.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "nfr_requirements")
public class NonFunctionalRequirement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "max_response_time")
    private Integer maxResponseTime = 0;

    @Column(name = "avg_response_time")
    private Integer avgResponseTime = 0;

    @Column(name = "transaction_processing_time")
    private Integer transactionProcessingTime = 0;

    @Column(name = "max_concurrent_users")
    private Integer maxConcurrentUsers = 0;

    @Column(name = "throughput_requirements")
    private Integer throughputRequirements = 0;

    @Column(name = "peak_load_capacity")
    private Double peakLoadCapacity = 0.0;

    @Column(name = "performance_specs", length = 2000)
    private String performanceSpecs = "";

    @Column(name = "security_level")
    private String securityLevel = "BASIC";

    @Column(name = "authentication_method")
    private String authenticationMethod = "";

    @Column(name = "authorization_method")
    private String authorizationMethod = "";

    @Column(name = "session_timeout_duration")
    private Integer sessionTimeoutDuration = 30;

    @Column(name = "data_encryption_required")
    private Boolean dataEncryptionRequired = false;

    @Column(name = "audit_logging_required")
    private Boolean auditLoggingRequired = false;

    @Column(name = "password_policy", length = 2000)
    private String passwordPolicy = "";

    @Column(name = "availability_percentage")
    private Double availabilityPercentage = 95.0;

    @Column(name = "maintenance_window")
    private String maintenanceWindow = "";

    @Column(name = "disaster_recovery_time")
    private Integer disasterRecoveryTime = 0;

    @Column(name = "rpo")
    private Integer rpo = 0;

    @Column(name = "rto")
    private Integer rto = 0;

    @Column(name = "backup_reliability")
    private String backupReliability = "";

    @Column(name = "fault_tolerance_level")
    private String faultToleranceLevel = "";

    @Column(name = "data_integrity_requirements", length = 2000)
    private String dataIntegrityRequirements = "";

    @Column(name = "system_stability_requirements", length = 2000)
    private String systemStabilityRequirements = "";

    @Column(name = "future_user_growth_expectation")
    private Double futureUserGrowthExpectation = 0.0;

    @Column(name = "storage_scalability_requirement")
    private Double storageScalabilityRequirement = 0.0;

    @Column(name = "horizontal_scaling_support_required")
    private Boolean horizontalScalingSupportRequired = false;

    @Column(name = "ease_of_use_level")
    private String easeOfUseLevel = "";

    @Column(name = "supported_languages")
    private String supportedLanguages = "";

    @Column(name = "user_training_requirement")
    private Boolean userTrainingRequirement = false;

    @Column(name = "accessibility_compliance")
    private Boolean accessibilityCompliance = false;

    @Column(name = "supported_browsers")
    private Boolean supportedBrowsers = false;

    @Column(name = "supported_operating_systems")
    private Boolean supportedOperatingSystems = false;

    @Column(name = "mobile_device_support")
    private Boolean mobileDeviceSupport = false;

    @Column(name = "third_party_integration_support")
    private Boolean thirdPartyIntegrationSupport = false;

    @Column(name = "code_maintainability_level")
    private String codeMaintainabilityLevel = "";

    @Column(name = "documentation_requirement")
    private Boolean documentationRequirement = false;

    @Column(name = "monitoring_requirement")
    private Boolean monitoringRequirement = false;

    @Column(name = "logging_requirement")
    private Boolean loggingRequirement = false;

    @Column(name = "industry_standards_compliance")
    private String industryStandardsCompliance = "";

    @Column(name = "regulatory_compliance", length = 2000)
    private String regulatoryCompliance = "";

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Integer getMaxResponseTime() { return maxResponseTime; }
    public void setMaxResponseTime(Integer maxResponseTime) { this.maxResponseTime = maxResponseTime; }

    public Integer getAvgResponseTime() { return avgResponseTime; }
    public void setAvgResponseTime(Integer avgResponseTime) { this.avgResponseTime = avgResponseTime; }

    public Integer getTransactionProcessingTime() { return transactionProcessingTime; }
    public void setTransactionProcessingTime(Integer transactionProcessingTime) { this.transactionProcessingTime = transactionProcessingTime; }

    public Integer getMaxConcurrentUsers() { return maxConcurrentUsers; }
    public void setMaxConcurrentUsers(Integer maxConcurrentUsers) { this.maxConcurrentUsers = maxConcurrentUsers; }

    public Integer getThroughputRequirements() { return throughputRequirements; }
    public void setThroughputRequirements(Integer throughputRequirements) { this.throughputRequirements = throughputRequirements; }

    public Double getPeakLoadCapacity() { return peakLoadCapacity; }
    public void setPeakLoadCapacity(Double peakLoadCapacity) { this.peakLoadCapacity = peakLoadCapacity; }

    public String getPerformanceSpecs() { return performanceSpecs; }
    public void setPerformanceSpecs(String performanceSpecs) { this.performanceSpecs = performanceSpecs; }

    public String getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(String securityLevel) { this.securityLevel = securityLevel; }

    public String getAuthenticationMethod() { return authenticationMethod; }
    public void setAuthenticationMethod(String authenticationMethod) { this.authenticationMethod = authenticationMethod; }

    public String getAuthorizationMethod() { return authorizationMethod; }
    public void setAuthorizationMethod(String authorizationMethod) { this.authorizationMethod = authorizationMethod; }

    public Integer getSessionTimeoutDuration() { return sessionTimeoutDuration; }
    public void setSessionTimeoutDuration(Integer sessionTimeoutDuration) { this.sessionTimeoutDuration = sessionTimeoutDuration; }

    public Boolean getDataEncryptionRequired() { return dataEncryptionRequired; }
    public void setDataEncryptionRequired(Boolean dataEncryptionRequired) { this.dataEncryptionRequired = dataEncryptionRequired; }

    public Boolean getAuditLoggingRequired() { return auditLoggingRequired; }
    public void setAuditLoggingRequired(Boolean auditLoggingRequired) { this.auditLoggingRequired = auditLoggingRequired; }

    public String getPasswordPolicy() { return passwordPolicy; }
    public void setPasswordPolicy(String passwordPolicy) { this.passwordPolicy = passwordPolicy; }

    public Double getAvailabilityPercentage() { return availabilityPercentage; }
    public void setAvailabilityPercentage(Double availabilityPercentage) { this.availabilityPercentage = availabilityPercentage; }

    public String getMaintenanceWindow() { return maintenanceWindow; }
    public void setMaintenanceWindow(String maintenanceWindow) { this.maintenanceWindow = maintenanceWindow; }

    public Integer getDisasterRecoveryTime() { return disasterRecoveryTime; }
    public void setDisasterRecoveryTime(Integer disasterRecoveryTime) { this.disasterRecoveryTime = disasterRecoveryTime; }

    public Integer getRpo() { return rpo; }
    public void setRpo(Integer rpo) { this.rpo = rpo; }

    public Integer getRto() { return rto; }
    public void setRto(Integer rto) { this.rto = rto; }

    public String getBackupReliability() { return backupReliability; }
    public void setBackupReliability(String backupReliability) { this.backupReliability = backupReliability; }

    public String getFaultToleranceLevel() { return faultToleranceLevel; }
    public void setFaultToleranceLevel(String faultToleranceLevel) { this.faultToleranceLevel = faultToleranceLevel; }

    public String getDataIntegrityRequirements() { return dataIntegrityRequirements; }
    public void setDataIntegrityRequirements(String dataIntegrityRequirements) { this.dataIntegrityRequirements = dataIntegrityRequirements; }

    public String getSystemStabilityRequirements() { return systemStabilityRequirements; }
    public void setSystemStabilityRequirements(String systemStabilityRequirements) { this.systemStabilityRequirements = systemStabilityRequirements; }

    public Double getFutureUserGrowthExpectation() { return futureUserGrowthExpectation; }
    public void setFutureUserGrowthExpectation(Double futureUserGrowthExpectation) { this.futureUserGrowthExpectation = futureUserGrowthExpectation; }

    public Double getStorageScalabilityRequirement() { return storageScalabilityRequirement; }
    public void setStorageScalabilityRequirement(Double storageScalabilityRequirement) { this.storageScalabilityRequirement = storageScalabilityRequirement; }

    public Boolean getHorizontalScalingSupportRequired() { return horizontalScalingSupportRequired; }
    public void setHorizontalScalingSupportRequired(Boolean horizontalScalingSupportRequired) { this.horizontalScalingSupportRequired = horizontalScalingSupportRequired; }

    public String getEaseOfUseLevel() { return easeOfUseLevel; }
    public void setEaseOfUseLevel(String easeOfUseLevel) { this.easeOfUseLevel = easeOfUseLevel; }

    public String getSupportedLanguages() { return supportedLanguages; }
    public void setSupportedLanguages(String supportedLanguages) { this.supportedLanguages = supportedLanguages; }

    public Boolean getUserTrainingRequirement() { return userTrainingRequirement; }
    public void setUserTrainingRequirement(Boolean userTrainingRequirement) { this.userTrainingRequirement = userTrainingRequirement; }

    public Boolean getAccessibilityCompliance() { return accessibilityCompliance; }
    public void setAccessibilityCompliance(Boolean accessibilityCompliance) { this.accessibilityCompliance = accessibilityCompliance; }

    public Boolean getSupportedBrowsers() { return supportedBrowsers; }
    public void setSupportedBrowsers(Boolean supportedBrowsers) { this.supportedBrowsers = supportedBrowsers; }

    public Boolean getSupportedOperatingSystems() { return supportedOperatingSystems; }
    public void setSupportedOperatingSystems(Boolean supportedOperatingSystems) { this.supportedOperatingSystems = supportedOperatingSystems; }

    public Boolean getMobileDeviceSupport() { return mobileDeviceSupport; }
    public void setMobileDeviceSupport(Boolean mobileDeviceSupport) { this.mobileDeviceSupport = mobileDeviceSupport; }

    public Boolean getThirdPartyIntegrationSupport() { return thirdPartyIntegrationSupport; }
    public void setThirdPartyIntegrationSupport(Boolean thirdPartyIntegrationSupport) { this.thirdPartyIntegrationSupport = thirdPartyIntegrationSupport; }

    public String getCodeMaintainabilityLevel() { return codeMaintainabilityLevel; }
    public void setCodeMaintainabilityLevel(String codeMaintainabilityLevel) { this.codeMaintainabilityLevel = codeMaintainabilityLevel; }

    public Boolean getDocumentationRequirement() { return documentationRequirement; }
    public void setDocumentationRequirement(Boolean documentationRequirement) { this.documentationRequirement = documentationRequirement; }

    public Boolean getMonitoringRequirement() { return monitoringRequirement; }
    public void setMonitoringRequirement(Boolean monitoringRequirement) { this.monitoringRequirement = monitoringRequirement; }

    public Boolean getLoggingRequirement() { return loggingRequirement; }
    public void setLoggingRequirement(Boolean loggingRequirement) { this.loggingRequirement = loggingRequirement; }

    public String getIndustryStandardsCompliance() { return industryStandardsCompliance; }
    public void setIndustryStandardsCompliance(String industryStandardsCompliance) { this.industryStandardsCompliance = industryStandardsCompliance; }

    public String getRegulatoryCompliance() { return regulatoryCompliance; }
    public void setRegulatoryCompliance(String regulatoryCompliance) { this.regulatoryCompliance = regulatoryCompliance; }
}