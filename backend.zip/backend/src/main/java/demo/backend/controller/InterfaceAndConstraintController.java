package demo.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import demo.backend.entity.InterfaceAndConstraint;
import demo.backend.repository.InterfaceAndConstraintRepository;

@RestController
@RequestMapping("/api/interfaces-constraints")
@CrossOrigin(origins = {"*"})
public class InterfaceAndConstraintController {

    @Autowired
    private InterfaceAndConstraintRepository repository;

    @GetMapping({"", "/"})
    public List<InterfaceAndConstraint> getAllSpecs() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InterfaceAndConstraint> getSpecById(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping({"", "/"})
    public ResponseEntity<InterfaceAndConstraint> saveSpecs(@RequestBody InterfaceAndConstraint data) {
        return ResponseEntity.ok(repository.save(data));
    }

    @PutMapping("/{id}")
    public ResponseEntity<InterfaceAndConstraint> updateSpecs(@PathVariable Long id, @RequestBody InterfaceAndConstraint details) {
        return repository.findById(id).map(record -> {
            record.setUserInterfaceStandards(details.getUserInterfaceStandards());
            record.setSupportedScreenResolutions(details.getSupportedScreenResolutions());
            record.setSupportedLanguages(details.getSupportedLanguages());
            record.setAccessibilityRequirements(details.getAccessibilityRequirements());
            record.setHardwareRequirements(details.getHardwareRequirements());
            record.setDeviceCompatibility(details.getDeviceCompatibility());
            record.setPeripheralDeviceSupport(details.getPeripheralDeviceSupport());
            record.setOperatingSystemRequirements(details.getOperatingSystemRequirements());
            record.setBrowserCompatibility(details.getBrowserCompatibility());
            record.setExternalSoftwareDependencies(details.getExternalSoftwareDependencies());
            record.setMiddlewareRequirements(details.getMiddlewareRequirements());
            record.setCommunicationProtocol(details.getCommunicationProtocol());
            record.setBandwidthRequirements(details.getBandwidthRequirements());
            record.setApiAuthenticationMethod(details.getApiAuthenticationMethod());
            record.setNetworkRequirements(details.getNetworkRequirements());
            record.setRegulatoryConstraints(details.getRegulatoryConstraints());
            record.setLegalConstraints(details.getLegalConstraints());
            record.setSecurityConstraints(details.getSecurityConstraints());
            record.setPerformanceConstraints(details.getPerformanceConstraints());
            record.setTechnologyConstraints(details.getTechnologyConstraints());
            record.setBusinessAssumptions(details.getBusinessAssumptions());
            record.setTechnicalAssumptions(details.getTechnicalAssumptions());
            record.setExternalDependencies(details.getExternalDependencies());
            record.setVendorDependencies(details.getVendorDependencies());
            record.setComplianceStandards(details.getComplianceStandards());
            record.setReferenceDocumentsName(details.getReferenceDocumentsName());
            record.setSupportingArtifactsName(details.getSupportingArtifactsName());

            return ResponseEntity.ok(repository.save(record));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSpecs(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}