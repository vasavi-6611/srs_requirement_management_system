package demo.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import demo.backend.entity.PerformanceTesting;

@Repository
public interface PerformanceTestingRepository extends JpaRepository<PerformanceTesting, Long> {
}