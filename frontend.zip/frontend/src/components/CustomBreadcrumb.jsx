import React from "react";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Link from "@mui/material/Link";
import Typography from "@mui/material/Typography";

export default function CustomBreadcrumb({
  links = [], // Array of objects: { label: 'Home', onClick: fn }
  currentLabel,
}) {
  return (
    <Breadcrumbs aria-label="breadcrumb">
      {links.map((link, index) => (
        <Link
          key={index}
          underline="hover"
          color="inherit"
          component="button"
          onClick={link.onClick}
          sx={{ cursor: "pointer", background: "none", border: "none", p: 0, font: "inherit" }}
        >
          {link.label}
        </Link>
      ))}
      <Typography sx={{ color: "text.primary" }}>{currentLabel}</Typography>
    </Breadcrumbs>
  );
}